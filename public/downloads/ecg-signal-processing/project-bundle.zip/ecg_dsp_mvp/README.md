# ECG Denoising, QRS Detection, and Signal-Quality Testbench

Educational mixed-noise ECG processing and verification in Python. This project is **not a diagnostic product**, is not validated for patient care, and must not be used to make medical decisions. Its purpose is to demonstrate reproducible DSP design, verification, and engineering communication.

## Verified result at a glance

The checked-in run used a 30 s, 250 Hz synthetic ECG with 35 known R peaks, two processing configurations, 5 requested SNR values, 4 artifact selections, and both 50 and 60 Hz interference: 80 experiments total. All metrics in `results/` are computed, not estimated. The aggressive configuration achieved mean F1 0.9898 and minimum F1 0.8947; the balanced configuration achieved mean F1 0.9693 and minimum F1 0.7576. These are **synthetic-testbench results only** and cannot be interpreted as clinical accuracy.

## System contract

| Item | Assumption |
|---|---|
| Input | One ECG-like channel as a one-dimensional numeric array |
| Units | Millivolts for waveform amplitude; seconds for time |
| Default sampling | 250 samples/s; Nyquist frequency 125 Hz |
| Synthetic duration | 30 s in the verified run |
| Intended use | Education, algorithm prototyping, regression testing, and portfolio demonstration |
| Output | Filtered waveform, R-peak sample indices, HR/RR summary, SQI, plots, CSV/XLSX tables |
| Explicit exclusion | Diagnosis, monitoring, alarms, treatment, or claims about real patients |

The implementation assumes the sample rate is known and constant. A real acquisition chain would also need electrode specifications, analog anti-alias filtering, ADC range/resolution, saturation flags, lead configuration, timestamp integrity, and calibration.

## ECG basics

At a high level, the P wave corresponds to atrial depolarization, the QRS complex to ventricular depolarization, and the T wave to ventricular repolarization. The QRS complex is usually the sharpest feature, so its R peak is a practical timing landmark for RR intervals and average heart rate. This project detects timing landmarks; it does not classify morphology or rhythm.

The synthetic generator adds Gaussian-shaped P, Q, R, S, and T components. That gives exact ground truth for timing and denoising metrics, but it is simpler than real anatomy and acquisition physics.

## Processing pipeline

1. **DC removal:** subtract the record mean, `x_dc[n] = x[n] - mean(x)`. This centers the trace but does not remove time-varying drift.
2. **Notch:** a second-order IIR notch suppresses 50 or 60 Hz. Its quality factor is `Q = f0 / bandwidth`; higher Q makes a narrower notch and longer ringing.
3. **Band-pass:** a Butterworth high-pass/low-pass cascade suppresses baseline wander below the passband and high-frequency noise above it. The balanced configuration is 0.5-35 Hz, order 4. The aggressive configuration is 1-25 Hz, order 6.
4. **Optional smoothing:** the aggressive path uses a 21 ms Savitzky-Golay smoother. It is mild at 250 Hz and preserves local shape better than a long moving average, but it can still attenuate sharp features.
5. **QRS detector:** derivative -> square -> 120 ms moving-window integration -> robust threshold -> 250 ms refractory period -> local R-peak refinement.
6. **Metrics:** SNR, RMSE, beat matching, timing error, precision, recall, F1, HR/RR, and a bounded heuristic SQI.

### Why these cutoffs

The 0.5 Hz high-pass rejects slow baseline motion while retaining more low-frequency morphology than 1 Hz. The 35 Hz low-pass keeps major QRS energy while rejecting broadband noise. The aggressive 1-25 Hz path is more detection-oriented and can distort low-frequency ST/T content; it should not be used for morphology claims. The notch frequency must match local mains contamination.

### Sampling and aliasing

At 250 Hz, Nyquist is 125 Hz. Frequencies above 125 Hz can fold into the recorded band unless analog filtering occurs **before** sampling. No digital filter can undo aliasing that already happened. Resampling also requires an anti-alias filter. The testbench generates data directly at 250 Hz, so it does not model an analog front end.

### Order, phase, delay, and edges

Higher order makes the transition steeper but increases sensitivity, ringing, and implementation complexity. Second-order sections improve numerical conditioning. Offline runs use forward-backward filtering (`filtfilt`/`sosfiltfilt`), which cancels phase shift and squares the magnitude response. It is noncausal and uses future samples, so it cannot represent real-time behavior. Set `zero_phase=False` for causal filtering; then characterize group delay before comparing timestamps. Both approaches have startup/end transients. Do not interpret beats near record boundaries without padding or exclusion rules.

## Explainable QRS detector

For filtered signal `x[n]`, the detector approximates a derivative, squares it to make slopes positive and emphasize QRS energy, then averages over `N = round(0.120 fs)` samples:

`m[n] = (1/N) sum(k=0..N-1) d[n-k]^2`.

The threshold is the median energy plus a configurable fraction of the difference between the 99th percentile and median. Candidate peaks must be separated by 250 ms (maximum implied rate 240 bpm). Each candidate is refined to the largest filtered sample within ±120 ms. This is Pan-Tompkins-inspired, not a reproduction of its original integer filters or adaptive state machine.

Heart rate is `60 / mean(RR seconds)`. SDNN is the sample standard deviation of RR intervals; RMSSD is the root mean square of consecutive RR differences. In this project they are timing diagnostics, not health indicators.

## Metrics

Where clean synthetic reference `s` exists, output SNR is `10 log10(sum(s^2)/sum((y-s)^2))` and RMSE is `sqrt(mean((y-s)^2))`. A detected peak matches at most one reference peak within ±100 ms. Precision is `TP/(TP+FP)`, recall is `TP/(TP+FN)`, and F1 is their harmonic mean. Timing error is reported only for matched peaks.

The SQI is a transparent 0-1 engineering heuristic combining plausible rate, RR consistency, sample-to-sample roughness, and a clipping proxy. It is useful for ranking test conditions but has no clinical threshold or validation.

## Configuration comparison

| Configuration | Filter | Detector threshold | Best use | Main risk |
|---|---|---:|---|---|
| balanced | 0.5-35 Hz, order 4 | 0.38 | More waveform bandwidth | More false or missed peaks in extreme noise |
| aggressive | 1-25 Hz, order 6 + 21 ms smoothing | 0.30 | Robust timing in this synthetic sweep | More morphology attenuation and higher order |

The benchmark favors the aggressive detector for F1. That does not prove it preserves diagnostically relevant waveform morphology, nor that it generalizes to real ECGs.

## Repository structure

```text
data/             generated clean waveform and exact reference peaks
src/              generator, artifacts, filters, QRS, metrics, public loader
tests/            deterministic unit and behavior tests
notebooks/        guided reproduction notebook
results/          detailed sweep, summary, manifest, and workbook
figures/          filter, waveform, performance, and failure plots
report/           technical report and experiment notes
portfolio/        case-study copy, summary, bullets, recruiter pitch, Q&A
laptop-handoff/   exact commands, MATLAB guide, and acceptance checklist
```

## Install and run

```bash
python -m venv .venv
# Windows: .venv\Scripts\activate
# macOS/Linux: source .venv/bin/activate
python -m pip install --upgrade pip
python -m pip install -r requirements.txt
python -m pip install -e .
pytest -q
python -m ecg_testbench.experiment --output-root . --duration 30 --seed 20260922
```

Expected verification: five tests pass, 80 sweep rows are written, and the manifest reports 35 reference beats. Small floating-point differences across SciPy/platform versions are possible.

## Public dataset extension

The optional loader targets PhysioNet's MIT-BIH Arrhythmia Database, version 1.0.0. PhysioNet states that the 48 two-channel half-hour excerpts were digitized at 360 Hz with 11-bit resolution over a 10 mV range and include expert beat annotations. The database page lists the Open Data Commons Attribution License v1.0. Source: https://physionet.org/content/mitdb/1.0.0/

Install `wfdb`, then call `load_mit_bih()` from `public_data.py`. This package intentionally keeps public-record output separate from synthetic results. The checked-in manifest says `public_record_results_generated: false`; no real-record performance result is fabricated.

## Failure analysis

The detector struggles when motion energy produces QRS-like slopes, when noise hides a low-amplitude R wave, when two sharp artifacts satisfy the refractory rule, and near padded record edges. A fixed global threshold is especially weak when signal amplitude changes over time. See `figures/failure_case.png` and filter `results/noise_sweep_results.csv` by low F1. Practical improvements include adaptive signal/noise peak tracking, multi-lead agreement, template correlation, refractory logic tied to recent RR intervals, and explicit unusable-signal rejection.

## Common DSP mistakes

- Confusing DC removal with baseline-wander removal.
- Choosing cutoffs without checking Nyquist or analog anti-alias protection.
- Using zero-phase filtering and then claiming real-time operation.
- Reporting accuracy without one-to-one peak matching and a stated tolerance.
- Tuning and testing on the same small record, or mixing synthetic and public results.
- Treating filtered morphology as clinically preserved without validation.
- Ignoring units, clipping, missing samples, edges, and filter stability.
- Calling a heuristic SQI a medically validated quality score.

## Interview explanation

Start with the contract: a reproducible, non-diagnostic verification bench with exact synthetic truth. Walk through each artifact and filter, show the response plot, explain the detector stages, then discuss the 80-condition sweep. Lead with the tradeoff: aggressive preprocessing improved synthetic beat timing while risking more waveform distortion. Close with the failure plot and the next verification step on annotated public ECGs.

## Limitations and future work

Synthetic ECG is regular and cleanly parameterized; it lacks many arrhythmias, lead changes, electrode saturation, pacing spikes, and true motion coupling. Only a global-threshold single-lead detector is implemented. The benchmark is 30 seconds per condition. Future work should add MIT-BIH records with record-level train/test separation, causal delay characterization, amplitude-step tests, corrupted-segment labeling, adaptive thresholds, parameter-sensitivity analysis, and a requirements-to-test traceability matrix suitable for a regulated-development exercise.

## Provenance

- Original implementation created for this portfolio project; the referenced MATLAB repository was inspiration only and no code was copied.
- Public-data metadata: MIT-BIH Arrhythmia Database v1.0.0, PhysioNet, ODC Attribution License v1.0.
- Synthetic data, figures, and numerical results are generated locally by this package with fixed seeds.
