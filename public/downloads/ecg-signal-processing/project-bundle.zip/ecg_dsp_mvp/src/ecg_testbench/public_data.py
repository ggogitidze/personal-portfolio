"""Optional MIT-BIH loader. Requires the optional `wfdb` package and network."""
from __future__ import annotations

def load_mit_bih(record="100", channel=0, sampto=10800):
    try:
        import wfdb
    except ImportError as exc:
        raise RuntimeError("Install optional dependency with: pip install wfdb") from exc
    rec = wfdb.rdrecord(record, pn_dir="mitdb", sampto=sampto, channels=[channel])
    ann = wfdb.rdann(record, "atr", pn_dir="mitdb", sampto=sampto)
    return rec.p_signal[:,0], float(rec.fs), ann.sample

