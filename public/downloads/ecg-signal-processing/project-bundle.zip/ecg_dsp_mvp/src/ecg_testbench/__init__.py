"""Educational ECG DSP testbench; not a medical device."""

__version__ = "1.0.0"

