"""Deterministic synthetic ECG and artifact generation in millivolts."""
from __future__ import annotations
import numpy as np


def _gaussian(t: np.ndarray, center: float, width: float, amplitude: float) -> np.ndarray:
    return amplitude * np.exp(-0.5 * ((t - center) / width) ** 2)


def generate_ecg(duration_s: float = 30.0, fs: float = 250.0, heart_rate_bpm: float = 72.0,
                 seed: int = 7) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    """Return time, clean ECG (mV), and exact R-peak sample indices.

    Beat timing includes small seeded respiratory-like variability. Each beat is a sum of
    Gaussian P, Q, R, S, and T components; it is useful test data, not a physiological model.
    """
    rng = np.random.default_rng(seed)
    t = np.arange(int(round(duration_s * fs))) / fs
    ecg = np.zeros_like(t)
    rr0 = 60.0 / heart_rate_bpm
    centers, beat_time, k = [], 0.7, 0
    while beat_time < duration_s - 0.5:
        centers.append(beat_time)
        variability = 0.035 * np.sin(2 * np.pi * 0.18 * beat_time) + rng.normal(0, 0.008)
        beat_time += max(0.45, rr0 + variability)
        k += 1
    for r in centers:
        ecg += _gaussian(t, r - 0.20, 0.035, 0.12)  # P
        ecg += _gaussian(t, r - 0.045, 0.012, -0.18) # Q
        ecg += _gaussian(t, r, 0.014, 1.05)          # R
        ecg += _gaussian(t, r + 0.040, 0.014, -0.28) # S
        ecg += _gaussian(t, r + 0.28, 0.075, 0.30)   # T
    peaks = np.asarray([int(round(x * fs)) for x in centers], dtype=int)
    peaks = peaks[(peaks >= 0) & (peaks < len(t))]
    return t, ecg, peaks


def artifact_components(n: int, fs: float, seed: int = 123, powerline_hz: float = 60.0,
                        baseline_mv: float = 0.25, powerline_mv: float = 0.08,
                        motion_mv: float = 0.18, impulse_mv: float = 0.6) -> dict[str, np.ndarray]:
    """Create deterministic named contaminants in mV."""
    rng = np.random.default_rng(seed)
    t = np.arange(n) / fs
    baseline = baseline_mv * (0.72*np.sin(2*np.pi*0.25*t) + 0.28*np.sin(2*np.pi*0.08*t+0.4))
    powerline = powerline_mv * np.sin(2*np.pi*powerline_hz*t + 0.2)
    white = rng.normal(0, 1, n)
    # Motion-like artifact: low-passed random process plus sparse electrode shifts.
    kernel = np.ones(max(3, int(fs*0.18))); kernel /= kernel.sum()
    motion = np.convolve(rng.normal(0, 1, n), kernel, mode="same")
    motion = motion_mv * motion / (np.std(motion) + 1e-12)
    impulses = np.zeros(n)
    count = max(1, int(n / fs / 6))
    idx = rng.choice(np.arange(int(fs), max(int(fs)+1, n-int(fs))), size=count, replace=False)
    for i in idx:
        width = max(1, int(0.025*fs))
        stop = min(n, i+width)
        impulses[i:stop] += impulse_mv * np.hanning(2*(stop-i))[:stop-i]
    return {"baseline": baseline, "powerline": powerline, "white_unit": white,
            "motion": motion, "impulses": impulses}


def add_noise_at_snr(clean: np.ndarray, fs: float, snr_db: float, seed: int = 123,
                     powerline_hz: float = 60.0, include_baseline: bool = True,
                     include_motion: bool = True, include_impulses: bool = True) -> tuple[np.ndarray, dict]:
    parts = artifact_components(len(clean), fs, seed, powerline_hz)
    structured = parts["powerline"].copy()
    if include_baseline: structured += parts["baseline"]
    if include_motion: structured += parts["motion"]
    if include_impulses: structured += parts["impulses"]
    target_noise_power = np.mean(clean**2) / (10**(snr_db/10))
    residual = max(target_noise_power - np.mean(structured**2), 0.0)
    white = parts["white_unit"] * np.sqrt(residual / (np.mean(parts["white_unit"]**2)+1e-12))
    total = structured + white
    # If structured noise alone exceeds the requested power, scale all noise exactly.
    current = np.mean(total**2)
    if current > 0:
        total *= np.sqrt(target_noise_power/current)
    noisy = clean + total
    actual = 10*np.log10(np.mean(clean**2)/(np.mean(total**2)+1e-15))
    return noisy, {"noise": total, "components": parts, "actual_snr_db": float(actual)}

