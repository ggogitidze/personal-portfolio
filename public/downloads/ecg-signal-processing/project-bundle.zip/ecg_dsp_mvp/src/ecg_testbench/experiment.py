from __future__ import annotations
from pathlib import Path
from dataclasses import replace
import json, csv
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from .synthetic import generate_ecg, add_noise_at_snr
from .filters import FilterConfig, apply_filters, response
from .qrs import DetectorConfig, detect_qrs, rr_analysis
from .metrics import snr_db, rmse, match_peaks, signal_quality_index

CONFIGS = {
 "balanced": (FilterConfig(name="balanced", highpass_hz=0.5, lowpass_hz=35, bandpass_order=4), DetectorConfig(threshold_scale=.38)),
 "aggressive": (FilterConfig(name="aggressive", highpass_hz=1.0, lowpass_hz=25, bandpass_order=6, smoothing_window_ms=21), DetectorConfig(threshold_scale=.30)),
}

def run(output_root: str|Path, duration_s=30.0, fs=250.0, seed=20260922):
    root=Path(output_root); (root/"results").mkdir(parents=True,exist_ok=True); (root/"figures").mkdir(exist_ok=True); (root/"data").mkdir(exist_ok=True)
    t,clean,truth=generate_ecg(duration_s,fs,72,seed)
    pd.DataFrame({"time_s":t,"clean_ecg_mv":clean}).to_csv(root/"data"/"synthetic_clean_ecg.csv",index=False)
    pd.DataFrame({"r_peak_sample":truth,"r_peak_time_s":truth/fs}).to_csv(root/"data"/"synthetic_reference_peaks.csv",index=False)
    rows=[]; example=None; failure=None
    for hz in (50.0,60.0):
      for snr_target in (-5,0,5,10,20):
       for artifact in ("all","baseline","motion","impulse"):
        noisy,meta=add_noise_at_snr(clean,fs,snr_target,seed+int(hz)+snr_target*3+len(artifact),hz,
          include_baseline=artifact in ("all","baseline"), include_motion=artifact in ("all","motion"), include_impulses=artifact in ("all","impulse"))
        for name,(fc,dc) in CONFIGS.items():
          fc_run=replace(fc, notch_hz=hz)
          y=apply_filters(noisy,fs,fc_run); det,stages=detect_qrs(y,fs,dc); dm=match_peaks(truth,det,fs); rr=rr_analysis(det,fs)
          row={"source":"synthetic","config":name,"powerline_hz":hz,"artifact":artifact,"target_snr_db":snr_target,
               "actual_input_snr_db":meta["actual_snr_db"],"output_snr_db":snr_db(clean,y),"snr_improvement_db":snr_db(clean,y)-meta["actual_snr_db"],
               "rmse_mv":rmse(clean,y),"heart_rate_bpm":rr["heart_rate_bpm"],"sqi":signal_quality_index(y,det,fs),**dm}
          rows.append(row)
          if hz==60 and snr_target==10 and artifact=="all" and name=="balanced": example=(noisy,y,det,stages)
          if hz==60 and snr_target==-5 and artifact=="motion" and name=="balanced": failure=(noisy,y,det)
    df=pd.DataFrame(rows); df.to_csv(root/"results"/"noise_sweep_results.csv",index=False)
    summary=df.groupby("config",as_index=False).agg(mean_f1=("f1","mean"),min_f1=("f1","min"),mean_precision=("precision","mean"),mean_recall=("recall","mean"),mean_timing_error_ms=("mean_abs_timing_error_ms","mean"),mean_output_snr_db=("output_snr_db","mean"),mean_sqi=("sqi","mean"))
    summary.to_csv(root/"results"/"configuration_summary.csv",index=False)
    # Filter response
    fig,axs=plt.subplots(2,1,figsize=(9,7),sharex=True)
    for name,(fc,_) in CONFIGS.items():
      f,h=response(fs,fc); axs[0].plot(f,20*np.log10(np.maximum(abs(h),1e-8)),label=name); axs[1].plot(f,np.unwrap(np.angle(h))*180/np.pi,label=name)
    axs[0].set(ylabel="Magnitude (dB)",ylim=(-80,5)); axs[1].set(xlabel="Frequency (Hz)",ylabel="Phase (degrees)");
    for ax in axs: ax.grid(True,alpha=.3); ax.legend(); ax.set_xlim(0,80)
    fig.tight_layout(); fig.savefig(root/"figures"/"filter_response.png",dpi=170); plt.close(fig)
    noisy,y,det,stages=example; sl=t<10
    fig,axs=plt.subplots(3,1,figsize=(11,8),sharex=True)
    axs[0].plot(t[sl],clean[sl],label="clean",lw=1.2); axs[0].plot(t[sl],noisy[sl],label="noisy",alpha=.65); axs[0].legend(); axs[0].set_ylabel("mV")
    axs[1].plot(t[sl],y[sl],label="filtered"); d=det[det<int(10*fs)]; axs[1].scatter(d/fs,y[d],c="crimson",s=22,label="detected R"); axs[1].legend(); axs[1].set_ylabel("mV")
    axs[2].plot(t[sl],stages["integrated"][sl]); axs[2].axhline(stages["threshold"],c="crimson",ls="--"); axs[2].set(xlabel="Time (s)",ylabel="Integrated energy")
    for ax in axs: ax.grid(True,alpha=.25)
    fig.tight_layout(); fig.savefig(root/"figures"/"waveform_and_detection.png",dpi=170); plt.close(fig)
    fig,ax=plt.subplots(figsize=(9,5))
    for name,g in df[df.artifact=="all"].groupby("config"):
      curve=g.groupby("target_snr_db").f1.mean(); ax.plot(curve.index,curve.values,marker="o",label=name)
    ax.set(xlabel="Target input SNR (dB)",ylabel="QRS F1",ylim=(0,1.05)); ax.grid(True,alpha=.3); ax.legend(); fig.tight_layout(); fig.savefig(root/"figures"/"noise_performance_curve.png",dpi=170); plt.close(fig)
    noisy,y,det=failure; sl=t<12
    fig,ax=plt.subplots(figsize=(11,4)); ax.plot(t[sl],y[sl],label="filtered severe-motion case"); d=det[det<int(12*fs)]; ax.scatter(d/fs,y[d],c="crimson",s=20,label="detected"); tr=truth[truth<int(12*fs)]; ax.vlines(tr/fs,*ax.get_ylim(),color="green",alpha=.18,label="true R"); ax.set(xlabel="Time (s)",ylabel="mV",title="Failure case: -5 dB motion-like contamination"); ax.grid(True,alpha=.25); ax.legend(); fig.tight_layout(); fig.savefig(root/"figures"/"failure_case.png",dpi=170); plt.close(fig)
    manifest={"seed":seed,"fs_hz":fs,"duration_s":duration_s,"clean_beats":len(truth),"rows":len(df),"public_record_results_generated":False,"non_diagnostic":True}
    (root/"results"/"run_manifest.json").write_text(json.dumps(manifest,indent=2))
    return df,summary,manifest

if __name__=="__main__":
    import argparse
    p=argparse.ArgumentParser(); p.add_argument("--output-root",default="."); p.add_argument("--duration",type=float,default=30); p.add_argument("--seed",type=int,default=20260922); a=p.parse_args()
    _,s,m=run(a.output_root,a.duration,250,a.seed); print(s.to_string(index=False)); print(json.dumps(m,indent=2))
