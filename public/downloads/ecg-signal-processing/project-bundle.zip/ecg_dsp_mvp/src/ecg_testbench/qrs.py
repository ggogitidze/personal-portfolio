"""Explainable Pan-Tompkins-inspired QRS detector."""
from __future__ import annotations
from dataclasses import dataclass
import numpy as np
from scipy import signal


@dataclass(frozen=True)
class DetectorConfig:
    integration_ms: float = 120.0
    refractory_ms: float = 250.0
    threshold_scale: float = 0.38
    search_radius_ms: float = 120.0


def detect_qrs(filtered: np.ndarray, fs: float, cfg: DetectorConfig = DetectorConfig()):
    x = np.asarray(filtered, dtype=float)
    derivative = np.gradient(x) * fs
    squared = derivative**2
    w = max(3, int(round(cfg.integration_ms*fs/1000)))
    integrated = np.convolve(squared, np.ones(w)/w, mode="same")
    # Robust global threshold: median floor plus a fraction of upper-tail spread.
    floor = np.median(integrated)
    threshold = floor + cfg.threshold_scale*(np.percentile(integrated, 99)-floor)
    distance = max(1, int(round(cfg.refractory_ms*fs/1000)))
    candidates, props = signal.find_peaks(integrated, height=threshold, distance=distance)
    radius = max(1, int(round(cfg.search_radius_ms*fs/1000)))
    refined = []
    for c in candidates:
        lo, hi = max(0, c-radius), min(len(x), c+radius+1)
        refined.append(lo + int(np.argmax(x[lo:hi])))
    peaks = np.asarray(sorted(set(refined)), dtype=int)
    # Enforce refractory period again after refinement, retaining larger amplitudes.
    kept = []
    for p in peaks:
        if not kept or p-kept[-1] >= distance: kept.append(p)
        elif x[p] > x[kept[-1]]: kept[-1] = p
    stages = {"derivative": derivative, "squared": squared, "integrated": integrated,
              "threshold": float(threshold), "candidates": candidates}
    return np.asarray(kept, dtype=int), stages


def rr_analysis(peaks: np.ndarray, fs: float) -> dict:
    rr = np.diff(np.asarray(peaks))/fs
    valid = rr[(rr > 0.25) & (rr < 3.0)]
    if len(valid) == 0:
        return {"rr_s": [], "heart_rate_bpm": float("nan"), "sdnn_ms": float("nan"),
                "rmssd_ms": float("nan")}
    return {"rr_s": valid.tolist(), "heart_rate_bpm": float(60/np.mean(valid)),
            "sdnn_ms": float(np.std(valid, ddof=1)*1000) if len(valid)>1 else 0.0,
            "rmssd_ms": float(np.sqrt(np.mean(np.diff(valid)**2))*1000) if len(valid)>1 else 0.0}

