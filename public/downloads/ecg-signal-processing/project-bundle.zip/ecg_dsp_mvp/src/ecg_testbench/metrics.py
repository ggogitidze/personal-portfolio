"""Denoising, detection, and heuristic signal-quality metrics."""
from __future__ import annotations
import numpy as np


def snr_db(reference, estimate):
    reference=np.asarray(reference); estimate=np.asarray(estimate)
    return float(10*np.log10(np.mean(reference**2)/(np.mean((estimate-reference)**2)+1e-15)))


def rmse(reference, estimate):
    return float(np.sqrt(np.mean((np.asarray(estimate)-np.asarray(reference))**2)))


def match_peaks(truth, detected, fs, tolerance_ms=100.0):
    truth=np.asarray(truth,dtype=int); detected=np.asarray(detected,dtype=int)
    tol=int(round(tolerance_ms*fs/1000)); used=set(); errors=[]; tp=0
    for t in truth:
        candidates=[(abs(int(d)-int(t)),j,d) for j,d in enumerate(detected) if j not in used and abs(int(d)-int(t))<=tol]
        if candidates:
            err,j,d=min(candidates); used.add(j); tp+=1; errors.append((int(d)-int(t))*1000/fs)
    fp=len(detected)-tp; fn=len(truth)-tp
    precision=tp/(tp+fp) if tp+fp else 0.0; recall=tp/(tp+fn) if tp+fn else 0.0
    f1=2*precision*recall/(precision+recall) if precision+recall else 0.0
    return {"tp":tp,"fp":fp,"fn":fn,"precision":precision,"recall":recall,"f1":f1,
            "mean_abs_timing_error_ms":float(np.mean(np.abs(errors))) if errors else float("nan"),
            "bias_timing_error_ms":float(np.mean(errors)) if errors else float("nan")}


def signal_quality_index(filtered, peaks, fs):
    """0-1 heuristic SQI combining plausible rate, beat consistency, and clipping/noise proxies."""
    x=np.asarray(filtered); peaks=np.asarray(peaks)
    if len(x)<3 or not np.all(np.isfinite(x)): return 0.0
    rr=np.diff(peaks)/fs
    rate=60/np.mean(rr) if len(rr) else 0
    rate_score=float(np.clip(1-abs(rate-75)/75,0,1)) if 35<=rate<=220 else 0.0
    rr_score=float(np.exp(-4*np.std(rr)/(np.mean(rr)+1e-12))) if len(rr)>1 else 0.0
    dx=np.diff(x); rough=np.median(np.abs(dx))/(np.std(x)+1e-12)
    smooth_score=float(np.exp(-8*rough))
    clipping=np.mean(np.abs(x)>=0.995*np.max(np.abs(x))) if np.max(np.abs(x)) else 1
    clip_score=float(np.clip(1-10*clipping,0,1))
    return float(np.clip(0.30*rate_score+0.30*rr_score+0.25*smooth_score+0.15*clip_score,0,1))

