"""Configurable ECG filters with causal and zero-phase execution."""
from __future__ import annotations
from dataclasses import dataclass
import numpy as np
from scipy import signal


@dataclass(frozen=True)
class FilterConfig:
    name: str = "balanced"
    highpass_hz: float = 0.5
    lowpass_hz: float = 35.0
    bandpass_order: int = 4
    notch_hz: float = 60.0
    notch_q: float = 30.0
    zero_phase: bool = True
    smoothing_window_ms: float = 0.0


def design_filters(fs: float, cfg: FilterConfig):
    if not (0 < cfg.highpass_hz < cfg.lowpass_hz < fs/2):
        raise ValueError("Cutoffs must satisfy 0 < highpass < lowpass < Nyquist")
    if not (0 < cfg.notch_hz < fs/2):
        raise ValueError("Notch frequency must be below Nyquist")
    sos = signal.butter(cfg.bandpass_order, [cfg.highpass_hz, cfg.lowpass_hz],
                        btype="bandpass", fs=fs, output="sos")
    b_notch, a_notch = signal.iirnotch(cfg.notch_hz, cfg.notch_q, fs=fs)
    if not np.all(np.abs(np.roots(a_notch)) < 1):
        raise ValueError("Unstable notch filter")
    return sos, b_notch, a_notch


def apply_filters(x: np.ndarray, fs: float, cfg: FilterConfig) -> np.ndarray:
    """DC removal -> notch -> band-pass -> optional Savitzky-Golay smoothing."""
    x = np.asarray(x, dtype=float)
    centered = x - np.mean(x)
    sos, bn, an = design_filters(fs, cfg)
    if cfg.zero_phase:
        y = signal.filtfilt(bn, an, centered)
        y = signal.sosfiltfilt(sos, y)
    else:
        y = signal.lfilter(bn, an, centered)
        y = signal.sosfilt(sos, y)
    if cfg.smoothing_window_ms > 0:
        window = int(round(cfg.smoothing_window_ms * fs / 1000))
        window = max(5, window | 1)
        if window < len(y): y = signal.savgol_filter(y, window, 2)
    return y


def response(fs: float, cfg: FilterConfig, worN: int = 4096):
    sos, bn, an = design_filters(fs, cfg)
    b_bp, a_bp = signal.sos2tf(sos)
    b = np.convolve(bn, b_bp); a = np.convolve(an, a_bp)
    f, h = signal.freqz(b, a, worN=worN, fs=fs)
    return f, h

