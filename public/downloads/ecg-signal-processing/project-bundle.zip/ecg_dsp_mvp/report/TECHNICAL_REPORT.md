# Technical Report

## Purpose and conclusion

This non-diagnostic engineering testbench demonstrates an end-to-end ECG DSP verification workflow. Across 80 fixed-seed synthetic conditions, the aggressive configuration achieved higher mean and worst-case QRS F1 than the balanced configuration. The result supports a narrow claim: stronger preprocessing was more robust for R-peak timing on this generator. It does not establish clinical performance or morphology preservation.

## Requirements and architecture

The input is one ECG-like millivolt waveform sampled uniformly at 250 Hz. The pipeline centers the data, rejects selectable mains interference, band-limits the signal, optionally smooths it, detects QRS complexes, estimates RR/heart rate, and scores both denoising and event detection. Modules are separated so generation, processing, detection, and verification can be tested independently.

## Verification matrix

| Requirement | Verification evidence |
|---|---|
| Stable digital filters | `test_filter_stability` checks notch and SOS poles |
| Length preservation | `test_output_length_and_finite` |
| Finite results | `test_output_length_and_finite` |
| Reproducible artifacts | `test_noise_reproducible` |
| Known-signal behavior | `test_known_signal_detection` requires precision and recall at least 0.90 |
| Bad cutoff rejection | `test_invalid_cutoff_rejected` |
| Robustness sweep | 80 rows in `noise_sweep_results.csv` |

## Results

The verified run contained 35 reference beats and 80 experiments. Mean F1 was 0.9898 for aggressive and 0.9693 for balanced; minimum F1 was 0.8947 and 0.7576, respectively. Mean absolute matched-peak timing error was below 1.1 ms for both. Timing is unusually accurate because synthetic R peaks are sharp, preprocessing is zero phase, and the detector locally refines to the positive maximum. These properties must be stated whenever the number is shown.

Output SNR does not increase monotonically in every condition because the metric compares the filtered waveform with the unfiltered synthetic reference. Band limitation can count intentional waveform alteration as error. That is a useful reminder that detection and waveform-fidelity objectives are not identical.

## Failure analysis

At -5 dB and with motion-like contamination, sharp artifact slopes can cross the energy threshold and become false positives, while artifact overlap can suppress or shift a true peak. The global threshold does not track local amplitude changes. The failure-case figure overlays detections and true timing to make these weaknesses visible.

## Risk and limitations

The synthetic model is not a population. No claim is made for sensitivity, specificity, rhythm classification, diagnostic interpretation, or safe operation. Forward-backward filtering is offline. The SQI is heuristic. Public MIT-BIH validation is prepared but was not executed in the verified package. A real product process would require formal requirements, risk management, traceability, independent verification, data governance, usability engineering, and clinical validation.

## Recommended next experiment

Install `wfdb`, download selected MIT-BIH records, preserve record identity, and report results separately by record. Freeze parameters before evaluation, exclude tuning records, compare causal and zero-phase modes, and publish both aggregate metrics and record-level failures.
