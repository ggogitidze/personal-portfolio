import numpy as np
from scipy import signal
from ecg_testbench.synthetic import generate_ecg, add_noise_at_snr
from ecg_testbench.filters import FilterConfig, design_filters, apply_filters
from ecg_testbench.qrs import detect_qrs
from ecg_testbench.metrics import match_peaks

def test_filter_stability():
    sos,b,a=design_filters(250,FilterConfig())
    assert np.all(np.abs(np.roots(a))<1)
    assert np.all(np.abs(np.concatenate([np.roots(row[3:]) for row in sos]))<1.000001)

def test_output_length_and_finite():
    _,x,_=generate_ecg(8,250,72,1); y=apply_filters(x,250,FilterConfig())
    assert len(y)==len(x) and np.all(np.isfinite(y))

def test_noise_reproducible():
    _,x,_=generate_ecg(8,250,72,1); a,_=add_noise_at_snr(x,250,5,44); b,_=add_noise_at_snr(x,250,5,44)
    assert np.array_equal(a,b)

def test_known_signal_detection():
    _,x,truth=generate_ecg(15,250,70,3); noisy,_=add_noise_at_snr(x,250,15,9)
    y=apply_filters(noisy,250,FilterConfig()); det,_=detect_qrs(y,250); m=match_peaks(truth,det,250)
    assert m["recall"]>=0.90 and m["precision"]>=0.90

def test_invalid_cutoff_rejected():
    import pytest
    with pytest.raises(ValueError): design_filters(100,FilterConfig(lowpass_hz=60))

