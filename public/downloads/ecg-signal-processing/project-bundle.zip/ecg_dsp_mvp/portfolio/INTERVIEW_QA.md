# Technical Interview Questions and Model Answers

## Why use a notch and a band-pass?

The notch targets narrow 50/60 Hz interference while the band-pass handles slow drift and broadband high-frequency noise. A band-pass alone can attenuate mains, but a narrower notch can provide deeper targeted rejection without lowering the general low-pass cutoff as far.

## Why is zero-phase filtering not real time?

Forward-backward filtering uses future samples in the backward pass. It cancels phase shift offline but is noncausal. A deployed streaming system needs causal filters and an explicit latency budget.

## What does filter order change?

Higher order sharpens transitions but can increase ringing, numerical sensitivity, and delay in causal use. I use second-order sections for the Butterworth implementation to improve numerical conditioning.

## How does the detector work?

It differentiates to emphasize slopes, squares to make slope energy positive, integrates over 120 ms, thresholds the energy, enforces a 250 ms refractory interval, then searches locally for the positive R maximum.

## Why refine the candidate peak?

The integrated energy peak is delayed and broadened relative to the waveform. Local refinement maps the event back to a sample on the filtered ECG, which improves timing estimates.

## How are peaks matched?

Each reference peak can match at most one detection within ±100 ms. That prevents double counting. Unmatched detections are false positives; unmatched references are false negatives.

## Why can output SNR worsen after useful filtering?

The clean reference contains frequency content that filtering changes. The metric counts both residual noise and intentional signal distortion as error. A detector can improve while waveform SNR relative to the unfiltered reference does not.

## What is the biggest validation weakness?

The verified benchmark is synthetic and uses regular, high-amplitude R peaks. I prepared an MIT-BIH loader, but I would freeze parameters and run record-separated public validation before making any generalization claim.

## What failure did you observe?

Motion-like artifacts can create slopes and integrated energy that resemble QRS complexes. A global threshold also struggles when amplitude changes. Adaptive thresholds and explicit low-quality rejection are logical next steps.

## What would change for embedded implementation?

I would replace forward-backward filtering with causal fixed-point or floating-point SOS stages, quantify group delay and CPU/RAM use, guard against overflow, use streaming state, and validate against the offline reference with sample-level tolerances.

