# Short Portfolio Summary

Built a reproducible, non-diagnostic Python ECG DSP testbench that injects controlled baseline, mains, broadband, motion-like, and impulsive noise; compares two configurable filter/detector chains; and verifies QRS timing with automated tests and an 80-condition fixed-seed sweep. Produced filter-response, waveform, detection, robustness, and failure-case evidence while explicitly separating synthetic results from future public-record validation.

