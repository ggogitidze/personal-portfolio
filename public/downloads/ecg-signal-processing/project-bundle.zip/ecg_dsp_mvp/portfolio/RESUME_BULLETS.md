# Truthful Resume Bullets

- Developed a modular Python ECG signal-processing testbench with DC removal, selectable 50/60 Hz notch filtering, Butterworth band-pass filtering, explainable QRS detection, RR/heart-rate analysis, and signal-quality scoring.
- Designed and executed an 80-condition fixed-seed synthetic robustness sweep across SNR, baseline drift, mains interference, impulsive artifacts, and motion-like noise; compared two configurations and generated auditable CSV/XLSX results and performance plots.
- Added automated verification for filter stability, output integrity, reproducible noise, invalid parameter handling, and known-signal detection; documented failure modes, offline phase assumptions, and non-diagnostic limitations.

