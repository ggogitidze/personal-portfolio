# ECG Denoising QRS Detection and Signal Quality Testbench

## Signal problem

ECG acquisition is vulnerable to baseline drift, mains coupling, broadband noise, electrode motion, and impulsive artifacts. I built a reproducible Python verification bench that separates the clean reference, named contaminants, processing configuration, and scoring logic.

## What I built

The pipeline removes DC, applies a selectable 50/60 Hz notch, performs Butterworth band-pass filtering, optionally smooths the result, and detects QRS complexes with an explainable derivative-square-integrate detector. It calculates RR intervals, average heart rate, denoising metrics, one-to-one event metrics, timing error, and a transparent heuristic SQI.

## Test method

I generated a deterministic 30 s, 250 Hz ECG with exact R-peak timing, then swept five input SNR targets, four artifact selections, two mains frequencies, and two processing configurations. Automated tests check filter stability, length preservation, finite values, random-seed reproducibility, invalid cutoffs, and detection on a known signal.

## Result and tradeoff

Across 80 synthetic conditions, the aggressive configuration produced mean F1 0.9898 versus 0.9693 for the balanced configuration, and its worst condition was also stronger. The aggressive path removes more bandwidth, so I would select it for robust timing only after checking that the application does not require preserved low-frequency morphology. These are synthetic engineering results, not medical-performance claims.

## Failure case and next step

Severe motion-like noise creates QRS-shaped slopes that cause false detections and can mask real peaks. The next step is a frozen-parameter evaluation on annotated MIT-BIH records, reported separately from synthetic results, followed by causal-filter delay characterization.
