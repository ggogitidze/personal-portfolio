# 30 Second Recruiter Explanation

I built an ECG signal-processing verification project to show that I can connect DSP theory with test engineering. It generates ECG signals with exact beat timing, adds realistic categories of interference, filters them, detects QRS complexes, and measures both waveform error and event-detection performance. I automated 80 noise conditions, compared two designs, and documented where the detector fails. It is explicitly educational and non-diagnostic, but the workflow—requirements, modular implementation, reproducible tests, metrics, and failure analysis—transfers directly to instrumentation and medical-device engineering.

