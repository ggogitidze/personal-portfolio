# Optional MATLAB Reproduction

1. Load `data/synthetic_clean_ecg.csv` with `readtable` and set `fs = 250`.
2. Create Butterworth filters with `[b,a] = butter(4,[0.5 35]/(fs/2),'bandpass')`.
3. Create a notch with `wo = 60/(fs/2); bw = wo/30; [bn,an] = iirnotch(wo,bw)`.
4. Reproduce offline filtering with `filtfilt(bn,an,x-mean(x))`, then `filtfilt(b,a,...)`.
5. Use `freqz` for magnitude and unwrapped phase. Label forward-backward execution as offline and noncausal.
6. Implement the detector using `gradient`, squaring, `movmean(...,round(0.120*fs))`, `findpeaks` with `MinPeakDistance=round(0.250*fs)`, and local maximum refinement.
7. Compare detected indices with `synthetic_reference_peaks.csv` using one-to-one matching within `round(0.100*fs)`.

MATLAB and SciPy may differ slightly in filter design conventions, padding, and floating-point behavior. Compare plots and toleranced metrics rather than requiring bitwise equality.

