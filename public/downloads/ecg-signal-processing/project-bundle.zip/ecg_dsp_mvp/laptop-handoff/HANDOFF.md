# Laptop Handoff and Acceptance Checklist

## Exact commands

```bash
unzip ECG_DSP_Testbench_Portable.zip
cd ecg_dsp_mvp
python -m venv .venv
# Windows: .venv\Scripts\activate
# macOS/Linux: source .venv/bin/activate
python -m pip install --upgrade pip
python -m pip install -r requirements.txt
python -m pip install -e .
pytest -q
python -m ecg_testbench.experiment --output-root . --duration 30 --seed 20260922
```

Optional MIT-BIH extension:

```bash
python -m pip install wfdb
python -c "from ecg_testbench.public_data import load_mit_bih; x,fs,p=load_mit_bih(); print(len(x),fs,len(p))"
```

## Final acceptance checklist

- [ ] `pytest -q` reports 5 passed.
- [ ] Experiment reports 80 rows and 35 clean reference beats.
- [ ] CSV detailed and summary results open correctly.
- [ ] XLSX sheets contain Overview, Configuration Summary, Noise Sweep, and Definitions.
- [ ] Four PNG figures render and labels are readable.
- [ ] Notebook runs top to bottom after editable install.
- [ ] README keeps synthetic and public-record results separate.
- [ ] No medical or diagnostic claim appears in presentation materials.
- [ ] Public loader is only claimed as tested after running it locally with `wfdb` and network access.
- [ ] If using causal mode, filter delay is measured and timing comparisons are adjusted.

