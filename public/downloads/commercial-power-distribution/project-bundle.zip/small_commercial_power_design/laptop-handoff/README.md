# Laptop Handoff

## Python reproduction

```bash
python -m venv .venv
# Windows: .venv\Scripts\activate
# macOS/Linux: source .venv/bin/activate
python -m pip install -r requirements.txt
python run_all.py
```

Expected result: four passing tests plus refreshed CSV, PNG, and SVG outputs. Compare `results/scenario_summary.csv` to the packaged file before editing assumptions.

## AutoCAD refinement

1. Start a drawing using the office electrical template and set units to inches or millimeters.
2. Create layers: `E-ONE-LINE`, `E-TEXT`, `E-EQUIP`, `E-PROTECTION`, and `E-NOTES` with plotted lineweights.
3. Place standard utility, transformer, breaker, bus, panel, grounding, and load symbols.
4. Recreate the connectivity shown in `diagrams/one_line_diagram.svg`.
5. Add feeder tags F1-F7, conductor/raceway callouts, breaker frame/trip/AIC values, bus voltage, transformer kVA/%Z/vector group, and grounding notes.
6. Add a title block stating `PRELIMINARY - EDUCATIONAL - NOT FOR CONSTRUCTION`.
7. Plot to PDF and compare every tag to `data/feeders.csv` and the equipment table.

## Revit refinement

1. Create a new electrical project using the correct voltage definitions for 480Y/277 V and 208Y/120 V.
2. Place switchboard, panelboard, transformer, mechanical equipment, lighting, and receptacle families.
3. Define distribution systems and connect circuits from loads upstream to panels and transformers.
4. Enter connected load and demand classifications from `data/load_schedule.csv`.
5. Generate panel schedules and compare demand totals and phase allocations with the Excel workbook.
6. Create a one-line/riser drafting view and add the same preliminary disclaimer.

## ETAP refinement

1. Create a 60 Hz ANSI project; add a utility source with max/min short-circuit MVA and X/R.
2. Add the 750 kVA 12.47/0.48 kV Dyn transformer and 150 kVA 0.48/0.208 kV Dyn transformer using actual test data if available.
3. Add buses, cables, panel equivalents, lumped loads, and motors. Enter exact cable library types and lengths.
4. Run load flow for base, peak, future, and 0.95 pu source cases. Compare bus voltage and equipment loading against `results/scenario_summary.csv`.
5. Run ANSI short circuit for 3-phase and SLG faults using actual positive-, negative-, and zero-sequence data.
6. Add exact breaker/fuse models and perform Star coordination. Overlay downstream/upstream curves, transformer inrush/damage, and motor-start curves.
7. Run IEEE 1584 arc flash only after protection settings are finalized.

## Data that must be replaced for a real project

Utility short-circuit contribution and X/R; transformer test reports; conductor/raceway type and temperature assumptions; actual routing; equipment nameplates; motor starting and contribution; manufacturer breaker/fuse curves; grounding details; local NEC edition and amendments; AHJ and utility requirements.
