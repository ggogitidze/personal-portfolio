from pathlib import Path
import subprocess, sys
ROOT=Path(__file__).resolve().parent
subprocess.run([sys.executable,str(ROOT/"src/model.py")],check=True)
subprocess.run([sys.executable,"-m","pytest",str(ROOT/"tests"),"-q"],check=True)
