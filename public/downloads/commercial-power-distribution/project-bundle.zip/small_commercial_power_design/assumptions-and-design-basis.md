# Assumptions and Design Basis

## Facility and boundary

This is a synthetic, educational design for a 35,000 ft2 one-story office/warehouse facility. The modeled boundary begins at a 12.47 kV utility Thevenin source and ends at representative panel and branch loads. No real site, utility account, survey, or construction documents were used.

## Electrical architecture

- Utility source: 12.47 kV, 60 Hz, 250 MVA maximum and 150 MVA minimum short-circuit strength, assumed X/R represented by R/X = 0.10.
- Service transformer: 750 kVA, 12.47 kV delta to 480Y/277 V grounded wye, 5.75% impedance, 30-degree shift.
- Service entrance: MSB-480, 1000 A main, preliminary 65 kA interrupting rating.
- 480 V distribution: 400 A MDP-480, 250 A MCC-1, and 125 A LP-277.
- Derived system: 150 kVA dry-type transformer TX-1, 480 V delta to 208Y/120 V grounded wye, 5.75% impedance.
- 208 V distribution: 450 A MDP-208, 175 A RP-1, and 200 A RP-2.

## Design conventions

- Copper THHN/THWN-2 conductors, 75 C terminal column, 30 C ambient, not more than three current-carrying conductors unless noted.
- Feeder ampacities are preliminary NEC-table assumptions and must be checked against the locally adopted NEC, conductor insulation, terminal ratings, ambient temperature, raceway fill, neutral treatment, and adjustment factors.
- Demand factors are engineering assumptions, not representations of a specific utility or AHJ-approved load calculation.
- Lighting is multiplied by 125% to represent a continuous-load design basis.
- Motors/HVAC use demand values from synthetic nameplate-like kW and assumed power factor. A final design must use actual MCA, MOCP, locked-rotor current, efficiency, and manufacturer data.
- Base planning voltage target: 0.95 to 1.05 pu at modeled buses. The familiar 3% branch and 5% combined voltage-drop values are treated as design recommendations, not universal mandatory limits.
- Balanced positive-sequence load flow is used. Phase labels in the schedule are checked separately for allocation but are not solved as an unbalanced four-wire network.
- Equipment grounding conductors, grounding-electrode conductors, bonding jumpers, and neutral sizes are not finalized. Both 480Y/277 V and 208Y/120 V grounded-wye points are assumed solidly grounded.

## Standards framework

- NFPA 70, National Electrical Code: load calculations, conductor ampacity, overcurrent protection, transformers, grounding/bonding, and voltage-drop design notes. The actual adopted edition and local amendments must be confirmed.
- IEEE 3002.2-2018: workflow guidance for industrial/commercial load-flow studies.
- IEEE 3002.3-2018: workflow guidance for industrial/commercial short-circuit studies.
- IEEE 242 / IEEE 3004 series concepts: preliminary protection and coordination discussion only.
- IEEE 1584 concepts: arc-flash analysis is explicitly outside this MVP.

## Model limits

The design is not construction-ready, stamped, or verified in ETAP, EasyPower, SKM, AutoCAD, or Revit. Utility impedance, cable impedances, transformer test reports, protective-device curves, arc-flash clearing times, and field measurements are synthetic or assumed.
