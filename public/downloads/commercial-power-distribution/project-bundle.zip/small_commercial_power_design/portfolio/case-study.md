# Small Commercial Facility Power Distribution Design and Analysis

## Problem

Design a traceable low-voltage distribution system for a fictional 35,000 ft2 office/warehouse and test whether the system can serve present and future load without excessive equipment loading or voltage depression.

## Architecture

A 12.47 kV utility source supplies a 750 kVA service transformer and 480Y/277 V main switchboard. The 480 V system serves lighting, HVAC, motors, process loads, and a 150 kVA transformer that creates a 208Y/120 V system for receptacles, IT, kitchen loads, and a future tenant allowance.

## Decisions and analysis

I built a demand load schedule, balanced single-phase loads, sized preliminary feeders and breakers, calculated voltage drop, and implemented a reproducible pandapower network. I evaluated base, peak, future-expansion, and low-source-voltage scenarios. I also calculated IEC 60909 three-phase fault current and documented a deliberately simplified SLG estimate separately.

The first executed model found that a 225 A MDP feeder would be overloaded and that the phase schedule exceeded a 10% imbalance target. I revised the feeder to two parallel 3/0 Cu sets on a 400 A breaker and reassigned one single-phase circuit. The corrected base case converges with the most heavily loaded feeder below 70% and the service and 150 kVA transformers near 48% load.

## Results

- Base: approximately 331 kW, 142 kvar; minimum bus voltage 0.952 pu.
- Peak: minimum bus voltage 0.944 pu, which fails the 0.95 pu planning target.
- Future expansion: TX-1 reaches about 77% while the most heavily loaded feeder reaches about 90%; RP-2 falls to about 0.927 pu.
- Low-source-voltage: minimum voltage falls to about 0.899 pu.
- Maximum modeled three-phase fault: about 16.2 kA at MSB-480.

## Validation

Unit tests verify current, voltage-drop, transformer-fault, and phase-balance calculations. Independent hand checks bracket transformer secondary fault current and feeder voltage drop. CSV outputs, an Excel workbook, plots, and a one-line diagram make every result traceable.

## Limitations

The model is balanced and synthetic. It is not a construction design, coordination study, arc-flash study, harmonic study, or proprietary-tool verification. Real utility sequence data, cable geometry, device curves, motor contribution, temperature derating, and local code review would be required before design release.

## Future improvements

Build an unbalanced four-wire model, add manufacturer protection curves, perform motor-starting and harmonic studies, compare with ETAP, and refine the one-line in AutoCAD or Revit.

## Short portfolio summary

Designed and analyzed a synthetic 480Y/277 V and 208Y/120 V commercial distribution system using Python and pandapower. The project includes auditable load schedules, feeder and transformer sizing, voltage drop, four operating scenarios, IEC 60909 fault calculations, automated checks, and a professional one-line diagram.

## Truthful resume bullets

- Designed a synthetic 480Y/277 V and 208Y/120 V commercial distribution system, sizing a 750 kVA service transformer, 150 kVA step-down transformer, panelboards, breakers, and copper feeders from a traceable demand-load schedule.
- Built and tested a pandapower model for four load/voltage scenarios; identified and corrected an overloaded feeder and phase imbalance, then quantified bus voltages, feeder loading, transformer utilization, and losses.
- Calculated representative voltage drop and IEC 60909 three-phase fault duties, documented SLG and coordination limitations, and produced a one-line diagram, engineering report, Excel workbook, and reproducible test suite.

## 30-second recruiter explanation

I designed a fictional small commercial electrical distribution system from the utility source down to lighting, HVAC, motor, and receptacle panels. I created the load schedule, sized the main equipment and feeders, then built a pandapower model to test base, peak, future, and low-voltage conditions. The first run actually found an undersized feeder and poor phase balance, so I corrected both and reran the tests. The final package includes voltage-drop and fault calculations, a one-line diagram, automated validation, and clear limits on what still requires a licensed engineer and proprietary coordination tools.
