import math
from pathlib import Path
import sys
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/"src"))
from engineering import three_phase_current_a, feeder_voltage_drop, transformer_secondary_fault_a, load_schedule, phase_summary

def test_three_phase_current():
    assert abs(three_phase_current_a(100,480,0.9)-133.65) < 0.1

def test_transformer_fault():
    assert abs(transformer_secondary_fault_a(150,208,5.75)-7241.5) < 2

def test_voltage_drop_positive():
    dv,pct=feeder_voltage_drop(100,480,0.9,100,0.1,0.05)
    assert 0 < dv < 10 and 0 < pct < 3

def test_phase_balance():
    loads=load_schedule(ROOT/"data/load_schedule.csv")
    assert phase_summary(loads).imbalance_pct.max() < 10
