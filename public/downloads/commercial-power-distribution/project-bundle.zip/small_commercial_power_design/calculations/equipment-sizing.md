# Equipment and Feeder Sizing

## Core equations

Three-phase current:

`I = P / (sqrt(3) V_LL PF)`

Single-phase current:

`I = P / (V_LN PF)`

Apparent power:

`S = P / PF`, with `Q = P tan(cos^-1(PF))`.

Three-phase feeder voltage drop:

`Delta V = sqrt(3) I (R cos(phi) + X sin(phi))`

Single-phase two-wire drop:

`Delta V = 2 I (R cos(phi) + X sin(phi))`

Transformer terminal short-circuit estimate on an infinite bus:

`I_sc = I_FLA x 100 / Z_percent`.

## Representative decisions

### Service transformer and MSB

The base load-flow source supplies about 331 kW and 142 kvar, or 361 kVA. The 750 kVA service transformer is therefore about 48% loaded in the base case. The 1000 A, 480 V switchboard matches the transformer's full-load current of approximately 902 A and provides room for staged growth. The modeled maximum MSB three-phase fault is about 16.2 kA; 65 kAIC is a conservative preliminary selection, not a substitute for vendor series-rating or utility confirmation.

### TX-1 and MDP-208

TX-1 is 150 kVA. Full-load secondary current is `150,000/(sqrt(3)x208)=416 A`; a 450 A secondary main is used as a preliminary standard rating. Base loading is approximately 48%. Future-expansion loading is approximately 77%. The two-set 250 kcmil Cu secondary feeder is an assumption that provides 510 A of tabulated ampacity before adjustment factors.

### MDP-480 feeder correction

The first model run used a 225 A feeder and exceeded 100% thermal loading. The corrected design uses two parallel 3/0 Cu sets with 400 A aggregate assumed ampacity and a 400 A breaker. This correction is retained in the project as an auditable design iteration.

### Representative branch circuit

A 120 V, 16 A, 120 ft receptacle circuit on #12 Cu produced about 5.9% branch drop and was rejected. Upsizing the representative circuit to #10 Cu reduces calculated branch drop to about 3.8%. Combined with the RP-1 feeder drop, the path is about 4.9%, subject to actual routing and load distribution.

## Ratings table

| Element | Preliminary rating | Design reason |
|---|---:|---|
| Service transformer | 750 kVA | 48% base loading and growth margin |
| MSB-480 | 1000 A, 65 kAIC | Transformer FLA and fault duty margin |
| MDP-480 | 400 A | Supplies lighting, process, heater, and TX-1 |
| MCC-1 | 250 A | Base modeled feeder loading under 70% |
| LP-277 | 125 A | 65 kW continuous-adjusted lighting schedule |
| TX-1 | 150 kVA | Base 48%, future 77% modeled loading |
| MDP-208 | 450 A | 416 A transformer secondary FLA |
| RP-1 | 175 A | Office receptacle demand and voltage-drop margin |
| RP-2 | 200 A | Existing plus 30 kW future tenant allowance |

All ratings require final verification using actual product data, local code, temperature/derating, available fault current, and selective-coordination requirements.
