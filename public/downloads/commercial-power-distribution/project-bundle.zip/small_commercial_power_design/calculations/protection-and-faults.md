# Fault and Preliminary Protection Discussion

## Three-phase faults

`src/model.py` uses pandapower's IEC 60909 short-circuit calculation with the modeled positive-sequence utility, transformers, and feeder impedances. This is the most rigorous fault result in this MVP, but it remains only as accurate as the synthetic inputs.

Key maximum initial symmetrical currents are approximately 16.2 kA at MSB-480, 13.3 kA at MDP-480, 10.3 kA at MCC-1, 6.0 kA at MDP-208, 4.2 kA at RP-1, and 3.8 kA at RP-2.

## Single-line-to-ground faults

The SLG column is an explicit approximation. The project assumes `Z2 = Z1` and `Z0 = 3 Z1`, giving:

`I_LG / I_3phi = 3 Z1 / (Z1 + Z2 + Z0) = 0.60`.

This is not a validated ground-fault study. A professional study needs utility sequence data, transformer zero-sequence impedance, grounding conductor impedance, neutral/ground paths, generator contribution, motor contribution, and actual grounding method.

## Preliminary device strategy

- MSB main: 1000 A electronic-trip breaker, preliminary 65 kAIC. Confirm utility maximum fault and transformer data.
- MDP-480 feeder: 400 A breaker, preliminary 35 kAIC or higher.
- MCC-1 feeder: 250 A breaker, preliminary 35 kAIC or higher. Motor branch protection must use actual equipment MCA/MOCP and starting data.
- TX-1 primary: 200 A breaker, coordinated with transformer inrush and secondary main.
- MDP-208 main: 450 A breaker, preliminary 22 kAIC or higher.
- RP panel mains: 175/200 A, preliminary 10 kAIC minimum, with 22 kAIC preferred until series-rating and available-fault data are finalized.

## Coordination boundaries

No manufacturer time-current curves were imported. No instantaneous pickup, long-time pickup/delay, short-time pickup/delay, ground-fault pickup, fuse curve, transformer damage curve, motor-start curve, or arc-flash clearing time was optimized. A defensible next step is to obtain actual catalog numbers, overlay the curves from downstream to upstream, preserve transformer inrush and damage margins, check selective coordination where required, and then perform IEEE 1584 arc-flash analysis.
