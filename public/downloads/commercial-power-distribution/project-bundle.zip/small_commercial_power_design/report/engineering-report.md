# Engineering Report

## Small Commercial Facility Power Distribution Design and Analysis

**Status:** Educational preliminary design - synthetic data - not for construction  
**Prepared for:** Portfolio demonstration  
**Prepared by:** Giorgi Gogitidze  
**Date:** September 2026

## Executive summary

This study develops a radial 12.47 kV to 480Y/277 V to 208Y/120 V distribution system for a fictional 35,000 ft2 office/warehouse. The corrected base design serves approximately 331 kW and 142 kvar with a minimum voltage of 0.952 pu. The 750 kVA service transformer and 150 kVA secondary transformer each operate near 48% loading. Maximum base feeder loading is 69.5%.

Stress testing shows that voltage regulation is the governing future constraint. The peak case reaches 0.944 pu, future expansion reaches 0.927 pu at RP-2, and a 0.95 pu source produces 0.899 pu at the weakest bus. Future design work should prioritize 208 V feeder impedance and transformer tap/impedance choices before increasing transformer kVA.

The model calculates a maximum three-phase fault of approximately 16.2 kA at MSB-480 and 6.0 kA at MDP-208. SLG values are approximations only. No full protection coordination or arc-flash study is claimed.

## Design basis

The utility is modeled as a 12.47 kV Thevenin source with 250 MVA maximum short-circuit strength. A 750 kVA, 5.75% impedance delta-grounded-wye service transformer supplies a 1000 A 480 V switchboard. The facility distributes 480 V to HVAC, motors, heating, and process loads; 277 V to lighting; and derives 208Y/120 V through a 150 kVA, 5.75% transformer for receptacle, IT, kitchen, and future tenant loads.

Conductors are assumed copper THHN/THWN-2 using preliminary 75 C ampacities. Demand factors and power factors are synthetic and visible in the schedule. Both secondary systems are solidly grounded at their transformer neutral points. Actual code adoption, utility rules, derating, grounding, equipment listings, and manufacturer data require project-specific verification.

## Load and sizing method

Demand real power equals connected kW times demand factor. Reactive power is calculated from power factor. Current uses standard single-phase or balanced three-phase equations. Equipment and feeders are selected from demand current with practical standard ratings and then tested by load flow.

The initial 225 A MDP feeder failed the network test because downstream lighting and transformer demand were omitted from its sizing basis. The corrected feeder uses two parallel 3/0 Cu sets on a 400 A breaker. A phase-allocation check also caused a single-phase kitchen load to move from A to C.

## Voltage drop and load flow

Hand-style voltage-drop calculations use conductor R and X with load current and power factor. A representative 120 V branch was upsized from #12 to #10 Cu after the initial design exceeded the project drop target.

The pandapower model solves balanced positive-sequence AC power flow. The base system is thermally acceptable. The peak, future, and low-voltage cases fail the 0.95 pu planning threshold at downstream 208 V buses. These are planning findings, not code-violation declarations.

## Short circuit and protection

Pandapower IEC 60909 calculations provide the three-phase maximum initial symmetrical current. A transformer-only hand check yields 7.24 kA at the 150 kVA transformer terminals on an infinite bus; the network model produces 5.97 kA after upstream impedance, which is physically reasonable.

The SLG estimate assumes Z2 equals Z1 and Z0 equals three times Z1. It must not be used for equipment selection. Preliminary breaker AIC values exceed modeled three-phase duties, but manufacturer series ratings, actual utility maximums, device curves, coordination, and arc-flash clearing times remain open.

## Conclusions

The corrected base design is a credible educational MVP. It demonstrates that executable analysis can expose load-path and phase-allocation errors that are easy to miss in a spreadsheet. The current equipment has thermal capacity for the modeled future load, but future bus voltage is unacceptable under the project criterion. Real design continuation would obtain utility/transformer sequence data, optimize downstream impedance/taps, use exact manufacturer protection curves, run unbalanced and motor-start studies, and obtain licensed-engineer/AHJ review.
