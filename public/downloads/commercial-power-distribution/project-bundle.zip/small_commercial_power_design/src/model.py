from __future__ import annotations

import argparse
import json
import math
import os
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))
sys.path.insert(0, str(ROOT.parent / ".deps"))

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import pandapower as pp
import pandapower.shortcircuit as sc

from engineering import feeder_voltage_drop, load_schedule, phase_summary, transformer_secondary_fault_a, validate_design


SCENARIOS = {
    "base": {"base": 1.00, "future": 0.00, "source_vm": 1.00},
    "peak": {"base": 1.15, "future": 0.00, "source_vm": 1.00},
    "future_expansion": {"base": 1.10, "future": 1.00, "source_vm": 1.00},
    "low_voltage": {"base": 1.00, "future": 0.00, "source_vm": 0.95},
}


def add_line(net, name, fb, tb, kv, length_ft, r_kft, x_kft, ampacity, parallel=1):
    length_km = length_ft * 0.0003048
    # convert ohm/kft to ohm/km; parallel circuits reduce impedance and add ampacity
    mult = 3.280839895 / parallel
    return pp.create_line_from_parameters(net, fb, tb, length_km, r_kft * mult,
        x_kft * mult, c_nf_per_km=0.0, max_i_ka=ampacity * parallel / 1000.0,
        name=name, parallel=1, g_us_per_km=0.0)


def build_network(loads: pd.DataFrame, feeders: pd.DataFrame, scenario: str):
    cfg = SCENARIOS[scenario]
    net = pp.create_empty_network(sn_mva=1.0, f_hz=60)
    bus = {}
    for name, kv in [("UTILITY-12.47",12.47),("MSB-480",0.48),("MDP-480",0.48),("MCC-1",0.48),
                     ("LP-277",0.48),("TX-1-PRI",0.48),("MDP-208",0.208),("RP-1",0.208),("RP-2",0.208)]:
        bus[name] = pp.create_bus(net, vn_kv=kv, name=name)
    pp.create_ext_grid(net, bus["UTILITY-12.47"], vm_pu=cfg["source_vm"], s_sc_max_mva=250,
                       s_sc_min_mva=150, rx_max=0.10, rx_min=0.10, name="Utility source")
    pp.create_transformer_from_parameters(net, bus["UTILITY-12.47"], bus["MSB-480"],
        sn_mva=0.750, vn_hv_kv=12.47, vn_lv_kv=0.48, vk_percent=5.75, vkr_percent=0.95,
        pfe_kw=1.6, i0_percent=0.5, shift_degree=30, vector_group="Dyn", name="UTILITY-XFMR")
    fidx = feeders.set_index("feeder_id")
    for fid in ["F1","F2","F3","F4"]:
        f=fidx.loc[fid]
        add_line(net,fid,bus[f.from_bus],bus[f.to_bus],f.voltage_v/1000,f.length_ft,f.r_ohm_per_kft,f.x_ohm_per_kft,f.ampacity_a,int(f.parallel_sets))
    pp.create_transformer_from_parameters(net, bus["TX-1-PRI"], bus["MDP-208"],
        sn_mva=0.150, vn_hv_kv=0.48, vn_lv_kv=0.208, vk_percent=5.75, vkr_percent=1.35,
        pfe_kw=0.55, i0_percent=1.5, shift_degree=30, vector_group="Dyn", name="TX-1")
    for fid in ["F6","F7"]:
        f=fidx.loc[fid]
        add_line(net,fid,bus[f.from_bus],bus[f.to_bus],f.voltage_v/1000,f.length_ft,f.r_ohm_per_kft,f.x_ohm_per_kft,f.ampacity_a,int(f.parallel_sets))

    mapping={"LP-277":"LP-277","RP-1":"RP-1","RP-2":"RP-2","MCC-1":"MCC-1","MDP-480":"MDP-480"}
    for _,r in loads.iterrows():
        factor = cfg["base"] if r.base_in_service else cfg["future"]
        if factor == 0: continue
        pp.create_load(net,bus[mapping[r.bus]],p_mw=r.demand_kw*factor/1000,
                       q_mvar=r.demand_kvar*factor/1000,name=r.load_id,scaling=1.0)
    return net,bus


def calculate_voltage_drop(loads, feeders):
    by_bus=loads[loads.base_in_service.eq(1)].groupby("bus").agg({"demand_kw":"sum","demand_kvar":"sum"})
    rows=[]
    downstream = {
        "F1": ["MDP-480", "LP-277", "RP-1", "RP-2"],
        "F2": ["MCC-1"], "F3": ["LP-277"],
        "F4": ["RP-1", "RP-2"], "F5": ["RP-1", "RP-2"],
        "F6": ["RP-1"], "F7": ["RP-2"],
    }
    for _,f in feeders.iterrows():
        buses=[b for b in downstream.get(f.feeder_id,[]) if b in by_bus.index]
        if not buses: continue
        kw=by_bus.loc[buses,"demand_kw"].sum(); kvar=by_bus.loc[buses,"demand_kvar"].sum()
        kva=math.hypot(kw,kvar); pf=kw/kva; current=kva*1000/(math.sqrt(3)*f.voltage_v)
        dv,pct=feeder_voltage_drop(current,f.voltage_v,pf,f.length_ft,f.r_ohm_per_kft,f.x_ohm_per_kft,3,int(f.parallel_sets))
        rows.append({"feeder_id":f.feeder_id,"from_bus":f.from_bus,"to_bus":f.to_bus,"load_kw":kw,
                     "load_kva":kva,"current_a":current,"pf":pf,"drop_v":dv,"drop_pct":pct})
    # representative 120-V branch circuit: 16 A, 0.95 pf, 120 ft, upsized #10 Cu approx 1.21 ohm/kft
    dv,pct=feeder_voltage_drop(16,120,0.95,120,1.21,0.05,1,1)
    rows.append({"feeder_id":"BC-1","from_bus":"RP-1","to_bus":"Remote receptacle","load_kw":1.824,
                 "load_kva":1.92,"current_a":16,"pf":0.95,"drop_v":dv,"drop_pct":pct})
    return pd.DataFrame(rows)


def run():
    out=ROOT/"results"; out.mkdir(exist_ok=True)
    loads=load_schedule(ROOT/"data/load_schedule.csv")
    feeders=pd.read_csv(ROOT/"data/feeders.csv")
    loads.to_csv(out/"load_schedule_calculated.csv",index=False,float_format="%.4f")
    phase_summary(loads).to_csv(out/"phase_balance_base.csv",index=False,float_format="%.4f")
    calculate_voltage_drop(loads,feeders).to_csv(out/"voltage_drop.csv",index=False,float_format="%.4f")
    pd.DataFrame(validate_design(loads,feeders)).to_csv(out/"validation_checks.csv",index=False)
    scen_rows=[]; bus_rows=[]; line_rows=[]
    for name in SCENARIOS:
        net,bus=build_network(loads,feeders,name)
        pp.runpp(net,algorithm="nr",calculate_voltage_angles=True,init="flat",tolerance_mva=1e-8,max_iteration=30)
        minidx=net.res_bus.vm_pu.idxmin(); maxline=net.res_line.loading_percent.max()
        tx1_loading=float(net.res_trafo.loc[net.trafo.name.eq("TX-1"),"loading_percent"].iloc[0])
        service_loading=float(net.res_trafo.loc[net.trafo.name.eq("UTILITY-XFMR"),"loading_percent"].iloc[0])
        scen_rows.append({"scenario":name,"converged":net.converged,"total_p_kw":net.res_ext_grid.p_mw.iloc[0]*1000,
                          "total_q_kvar":net.res_ext_grid.q_mvar.iloc[0]*1000,"min_bus":net.bus.name.loc[minidx],
                          "min_voltage_pu":net.res_bus.vm_pu.min(),"max_line_loading_pct":maxline,
                          "tx1_loading_pct":tx1_loading,"service_transformer_loading_pct":service_loading})
        for i,r in net.res_bus.iterrows(): bus_rows.append({"scenario":name,"bus":net.bus.name.loc[i],"voltage_pu":r.vm_pu,"angle_deg":r.va_degree})
        for i,r in net.res_line.iterrows(): line_rows.append({"scenario":name,"line":net.line.name.loc[i],"loading_pct":r.loading_percent,"loss_kw":r.pl_mw*1000})
    scenarios=pd.DataFrame(scen_rows); scenarios.to_csv(out/"scenario_summary.csv",index=False,float_format="%.5f")
    pd.DataFrame(bus_rows).to_csv(out/"bus_voltages.csv",index=False,float_format="%.6f")
    pd.DataFrame(line_rows).to_csv(out/"line_results.csv",index=False,float_format="%.6f")

    # Positive-sequence IEC 60909 three-phase short-circuit calculation.
    net,bus=build_network(loads,feeders,"base")
    sc.calc_sc(net,case="max",fault="3ph",ip=True,ith=True,branch_results=False)
    fault=[]
    # SLG estimate uses Z0=3*Z1 locally: I_LG/I_3ph = 3*Z1/(2*Z1+Z0)=0.60.
    for key in ["MSB-480","MDP-480","MCC-1","LP-277","MDP-208","RP-1","RP-2"]:
        idx=bus[key]; i3=float(net.res_bus_sc.at[idx,"ikss_ka"])*1000
        fault.append({"bus":key,"voltage_v":net.bus.vn_kv.at[idx]*1000,"three_phase_fault_a":i3,
                      "three_phase_method":"pandapower IEC 60909 positive-sequence",
                      "slg_fault_estimate_a":0.60*i3,"slg_method":"approximation: Z2=Z1 and Z0=3Z1; verify with utility/grounding data"})
    pd.DataFrame(fault).to_csv(out/"fault_levels.csv",index=False,float_format="%.1f")

    hand=transformer_secondary_fault_a(150,208,5.75)
    validations={"tx1_secondary_terminal_fault_hand_a":hand,
                 "tx1_secondary_terminal_fault_model_a":next(x["three_phase_fault_a"] for x in fault if x["bus"]=="MDP-208"),
                 "note":"Model includes upstream source and service impedance; hand value treats TX-1 as sole impedance on infinite bus."}
    (out/"independent_hand_checks.json").write_text(json.dumps(validations,indent=2))

    plt.style.use("seaborn-v0_8-whitegrid")
    fig,ax=plt.subplots(figsize=(9,5));
    piv=pd.DataFrame(bus_rows).pivot(index="bus",columns="scenario",values="voltage_pu").loc[["MSB-480","MDP-480","MCC-1","LP-277","MDP-208","RP-1","RP-2"]]
    piv.plot(kind="bar",ax=ax,color=["#1f4e78","#70ad47","#ed7d31","#a5a5a5"])
    ax.axhline(0.95,color="#c00000",ls="--",lw=1,label="0.95 pu reference"); ax.set_ylabel("Voltage (pu)"); ax.set_title("Bus voltage by scenario"); ax.set_ylim(0.90,1.01); ax.legend(ncol=3,fontsize=8)
    fig.tight_layout(); fig.savefig(ROOT/"diagrams/bus_voltage_scenarios.png",dpi=200); plt.close(fig)
    fig,ax=plt.subplots(figsize=(8,4.5)); s=scenarios.set_index("scenario")[["tx1_loading_pct","service_transformer_loading_pct"]]
    s.plot(kind="bar",ax=ax,color=["#4472c4","#70ad47"]); ax.axhline(100,color="#c00000",ls="--"); ax.set_ylabel("Loading (%)"); ax.set_title("Transformer loading by scenario"); ax.legend(["150 kVA TX-1","750 kVA service transformer"]); fig.tight_layout(); fig.savefig(ROOT/"diagrams/transformer_loading.png",dpi=200); plt.close(fig)
    make_one_line(ROOT/"diagrams/one_line_diagram.png", ROOT/"diagrams/one_line_diagram.svg")
    print(scenarios.to_string(index=False))


def make_one_line(png,svg):
    import matplotlib.patches as patches
    fig,ax=plt.subplots(figsize=(14,8)); ax.set_xlim(0,14); ax.set_ylim(0,8); ax.axis("off")
    def box(x,y,w,h,title,sub,color="#d9eaf7"):
        ax.add_patch(patches.FancyBboxPatch((x,y),w,h,boxstyle="round,pad=0.04",facecolor=color,edgecolor="#1f2937",lw=1.4))
        ax.text(x+w/2,y+h*0.62,title,ha="center",va="center",fontsize=10,fontweight="bold")
        ax.text(x+w/2,y+h*0.28,sub,ha="center",va="center",fontsize=8)
    def line(a,b,c,d,label=""):
        ax.plot([a,c],[b,d],color="#1f2937",lw=2)
        if label: ax.text((a+c)/2,(b+d)/2+0.15,label,ha="center",fontsize=7,color="#374151")
    box(.3,6.1,1.8,1.1,"UTILITY","12.47 kV\n250 MVA max SC","#e5e7eb")
    box(2.8,6.1,2.0,1.1,"SERVICE XFMR","750 kVA\n12.47 kV-480Y/277 V")
    box(5.6,6.1,1.8,1.1,"MSB-480","1000 A main\n65 kAIC preliminary","#fde68a")
    line(2.1,6.65,2.8,6.65); line(4.8,6.65,5.6,6.65)
    box(3.0,3.9,1.8,1.0,"MCC-1","250 A\nHVAC + motors")
    box(5.7,3.9,1.8,1.0,"MDP-480","400 A\n480 V distribution")
    line(6.5,6.1,3.9,4.9,"F2"); line(6.5,6.1,6.6,4.9,"F1")
    box(5.0,1.9,1.8,1.0,"LP-277","125 A\nlighting")
    box(7.5,1.9,1.8,1.0,"TX-1","150 kVA\n480-208Y/120 V")
    line(6.2,3.9,5.9,2.9,"F3"); line(6.9,3.9,8.4,2.9,"F4")
    box(10.0,1.9,1.8,1.0,"MDP-208","450 A main\n208Y/120 V")
    line(9.3,2.4,10.0,2.4,"F5")
    box(9.0,.2,1.7,.9,"RP-1","175 A\noffice receptacles")
    box(11.2,.2,1.7,.9,"RP-2","200 A\nkitchen, IT, future")
    line(10.6,1.9,9.85,1.1,"F6"); line(11.2,1.9,12.05,1.1,"F7")
    ax.text(7,7.7,"SMALL COMMERCIAL FACILITY - PRELIMINARY ONE-LINE",ha="center",fontsize=15,fontweight="bold")
    ax.text(7,7.35,"Synthetic educational design. Ratings require licensed engineer, utility, and AHJ verification.",ha="center",fontsize=9,color="#7f1d1d")
    fig.tight_layout(); fig.savefig(png,dpi=200,bbox_inches="tight"); fig.savefig(svg,bbox_inches="tight"); plt.close(fig)


if __name__ == "__main__": run()
