from __future__ import annotations

import math
from dataclasses import dataclass
from pathlib import Path
import pandas as pd

SQRT3 = math.sqrt(3.0)


def kvar_from_kw_pf(kw: float, pf: float) -> float:
    return kw * math.tan(math.acos(pf))


def three_phase_current_a(kw: float, voltage_ll_v: float, pf: float) -> float:
    return 1000.0 * kw / (SQRT3 * voltage_ll_v * pf)


def single_phase_current_a(kw: float, voltage_ln_v: float, pf: float) -> float:
    return 1000.0 * kw / (voltage_ln_v * pf)


def load_schedule(path: Path) -> pd.DataFrame:
    df = pd.read_csv(path)
    df["connected_kva"] = df.connected_kw / df.pf
    df["demand_kw"] = df.connected_kw * df.demand_factor
    df["demand_kvar"] = [kvar_from_kw_pf(p, pf) for p, pf in zip(df.demand_kw, df.pf)]
    df["demand_kva"] = (df.demand_kw**2 + df.demand_kvar**2) ** 0.5
    df["design_current_a"] = [
        single_phase_current_a(p, v, pf) if ph in ("AN", "BN", "CN")
        else three_phase_current_a(p, v, pf)
        for p, v, pf, ph in zip(df.demand_kw, df.voltage_v, df.pf, df.phase)
    ]
    return df


def feeder_voltage_drop(current_a: float, voltage_v: float, pf: float, length_ft: float,
                        r_ohm_kft: float, x_ohm_kft: float, phases: int = 3,
                        parallel_sets: int = 1) -> tuple[float, float]:
    length_kft = length_ft / 1000.0
    r = r_ohm_kft * length_kft / parallel_sets
    x = x_ohm_kft * length_kft / parallel_sets
    sinphi = math.sqrt(max(0.0, 1.0 - pf**2))
    factor = SQRT3 if phases == 3 else 2.0
    drop_v = factor * current_a * (r * pf + x * sinphi)
    return drop_v, 100.0 * drop_v / voltage_v


def transformer_secondary_fault_a(kva: float, voltage_ll_v: float, z_percent: float) -> float:
    fla = kva * 1000.0 / (SQRT3 * voltage_ll_v)
    return fla * 100.0 / z_percent


def phase_summary(df: pd.DataFrame, scenario: str = "base") -> pd.DataFrame:
    active = df[df.base_in_service.eq(1)] if scenario == "base" else df[df.future_in_service.eq(1)]
    rows = []
    for phase in "ABC":
        kw = 0.0
        for _, r in active.iterrows():
            if r.phase == "ABC": kw += r.demand_kw / 3.0
            elif r.phase.startswith(phase): kw += r.demand_kw
        rows.append({"phase": phase, "demand_kw": kw})
    out = pd.DataFrame(rows)
    out["imbalance_pct"] = 100 * (out.demand_kw - out.demand_kw.mean()).abs() / out.demand_kw.mean()
    return out


def validate_design(loads: pd.DataFrame, feeders: pd.DataFrame) -> list[dict]:
    checks = []
    checks.append({"check": "Demand load does not exceed connected load times 1.25 maximum",
                   "status": "PASS" if (loads.demand_kw <= loads.connected_kw * 1.25 + 1e-9).all() else "FAIL"})
    checks.append({"check": "All power factors are within 0.80 to 1.00",
                   "status": "PASS" if loads.pf.between(0.8, 1.0).all() else "FAIL"})
    checks.append({"check": "All feeder breaker ratings do not exceed total assumed conductor ampacity",
                   "status": "PASS" if (feeders.breaker_a <= feeders.ampacity_a * feeders.parallel_sets).all() else "FAIL"})
    ps = phase_summary(loads)
    checks.append({"check": "Base phase demand imbalance is below 10%",
                   "status": "PASS" if ps.imbalance_pct.max() < 10 else "FAIL"})
    return checks
