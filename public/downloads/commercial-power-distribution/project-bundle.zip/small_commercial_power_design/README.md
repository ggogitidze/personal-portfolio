# Small Commercial Facility Power Distribution Design and Analysis

An executable educational MVP for a synthetic 35,000 ft2 office/warehouse. It demonstrates commercial load scheduling, preliminary equipment and feeder sizing, voltage-drop checks, balanced AC load flow, fault-current analysis, scenario testing, documentation, and engineering judgment.

> This is a portfolio study, not a construction design. No real facility, utility, field measurement, proprietary-software result, or professional seal is represented.

## What is being designed

The system begins with a 12.47 kV utility source and a 750 kVA service transformer. The 480Y/277 V system serves HVAC/motors, lighting, process equipment, and a 150 kVA step-down transformer. The 208Y/120 V system serves office receptacles, kitchen loads, IT, and a 30 kW future allowance.

![One-line diagram](diagrams/one_line_diagram.png)

## Why the architecture was chosen

- 480 V reduces current for major three-phase equipment compared with 208 V.
- 277 V is a common commercial lighting voltage from the same grounded-wye service.
- 208Y/120 V supports standard receptacles and smaller equipment.
- Delta-wye transformers establish grounded secondary systems and block upstream zero-sequence paths.
- A radial topology is appropriate for a small facility MVP and keeps protection and analysis explainable.

## Project structure

```text
data/                 synthetic loads and feeder assumptions
calculations/         sizing and protection narratives
src/                  engineering functions and pandapower model
results/              calculated CSV/JSON outputs
diagrams/             one-line and portfolio charts
report/               engineering report PDF and source
portfolio/            case study, summary, resume bullets, interview answers
laptop-handoff/       AutoCAD, Revit, and ETAP refinement steps
tests/                unit tests and acceptance checklist
notebooks/            guided executable analysis notebook
```

## Step 1 - Load schedule

Each row starts with connected real power `P_connected`, demand factor `DF`, and power factor `PF`.

`P_demand = P_connected x DF` in kW

`Q_demand = P_demand tan(cos^-1(PF))` in kvar

`S_demand = sqrt(P_demand^2 + Q_demand^2)` in kVA

For a three-phase load:

`I = 1000 P_demand / (sqrt(3) V_LL PF)` amperes

For a line-to-neutral load:

`I = 1000 P_demand / (V_LN PF)` amperes

Example: the 45 kW RTU at 480 V and 0.88 PF draws `45,000/(sqrt(3)x480x0.88)=61.5 A` at its modeled demand.

Phase labels AN, BN, and CN allocate single-phase loads. ABC loads are split equally in the phase-balance check. Moving the kitchen circuit from Phase A to C reduced maximum base imbalance from 13.3% to below 10%.

## Step 2 - Equipment and feeders

Equipment was selected from calculated demand plus realistic growth margin, then tested in the network. The important lesson is that sizing is iterative: the original F1 feeder omitted downstream contribution and exceeded 100% model loading. It was corrected to two parallel 3/0 Cu sets on a 400 A breaker.

Ampacities in `data/feeders.csv` are explicitly assumed 75 C values. They are not a substitute for checking the locally adopted NEC, terminal ratings, ambient correction, conductor bundling, harmonics, neutral treatment, and manufacturer data.

## Step 3 - Voltage drop

For a three-phase feeder:

`Delta V = sqrt(3) I (R cos(phi) + X sin(phi))`

where `I` is amperes, `R` and `X` are one-way conductor resistance and reactance in ohms, and `phi=cos^-1(PF)`.

For a single-phase two-wire circuit, replace `sqrt(3)` with `2`.

The representative 120 V, 16 A, 120 ft branch was upsized from #12 to #10 Cu after the first calculation produced about 5.9% branch drop. The revised branch drop is about 3.8%, and the combined RP-1 feeder-plus-branch path is about 4.9%.

## Step 4 - Load flow

Pandapower solves a balanced positive-sequence AC Newton-Raphson power flow. Loads retain both kW and kvar. The model includes conductor resistance/reactance, two transformers, and utility source voltage/strength.

Scenarios:

| Scenario | Definition | Engineering purpose |
|---|---|---|
| Base | 100% modeled demand | Normal design checkpoint |
| Peak | 115% of base loads | Short-term coincident stress |
| Future expansion | 110% existing plus 30 kW future load | Capacity and voltage planning |
| Low voltage | Base load at 0.95 pu utility voltage | Source-voltage sensitivity |

Executed results:

| Scenario | Source kW | Minimum voltage | Maximum line loading | TX-1 loading |
|---|---:|---:|---:|---:|
| Base | 331.4 | 0.952 pu | 69.5% | 48.1% |
| Peak | 381.7 | 0.944 pu | 80.5% | 55.6% |
| Future expansion | 397.4 | 0.927 pu | 89.9% | 76.7% |
| Low voltage | 331.7 | 0.899 pu | 73.6% | 50.8% |

The base case is thermally acceptable and barely above the 0.95 pu planning target. Peak, future, and low-voltage cases fail that voltage target. Mitigations include shorter/larger 208 V feeders, transformer taps, higher source voltage where allowed, moving future load to 480 V, local power-factor correction after harmonic review, or a larger/lower-impedance transformer. The correct choice requires lifecycle cost and real equipment data.

![Bus voltages](diagrams/bus_voltage_scenarios.png)

## Step 5 - Fault current

Three-phase currents in `results/fault_levels.csv` come from pandapower's IEC 60909 positive-sequence calculation. The maximum is approximately 16.2 kA at MSB-480. The 150 kVA transformer infinite-bus hand estimate is:

`I_FLA = 150,000/(sqrt(3)x208)=416 A`

`I_SC = 416 x 100/5.75 = 7.24 kA`.

The detailed model gives about 5.97 kA at MDP-208 because it also includes upstream source, service-transformer, and feeder impedance. That direction and magnitude are physically consistent.

SLG currents are not claimed as exact. They assume `Z2=Z1` and `Z0=3Z1`, producing `I_LG=0.60 I_3phi`. Real SLG analysis needs actual zero-sequence and grounding-path data.

## Step 6 - Protection

Interrupting ratings are conservatively higher than modeled duty, but no series-rating or selectivity claim is made. A full coordination study requires exact breaker/fuse curves and settings, transformer inrush and damage curves, motor-start curves, and arc-flash clearing times. See `calculations/protection-and-faults.md`.

## Run the project

```bash
python -m venv .venv
# Windows: .venv\Scripts\activate
# macOS/Linux: source .venv/bin/activate
python -m pip install -r requirements.txt
python run_all.py
```

The command rebuilds calculated CSV files and diagrams, then runs the tests. For a guided review, open `notebooks/facility_analysis.ipynb` after installing Jupyter.

## How to interpret outputs

- `scenario_summary.csv`: first screening table for voltage and loading violations.
- `bus_voltages.csv`: every bus and scenario; values below 0.95 pu need engineering review.
- `line_results.csv`: thermal loading and real losses for each feeder.
- `fault_levels.csv`: three-phase model result plus clearly labeled SLG estimate.
- `voltage_drop.csv`: hand-style representative checks that should agree in trend with load flow.
- `validation_checks.csv`: independent terminal checks; no downstream calculation depends on these PASS cells.

## Validation performed

- Four unit tests pass for current, transformer fault, voltage drop, and phase balance.
- All four power-flow cases converge.
- The original undersized feeder and phase imbalance were found through execution and corrected.
- The 150 kVA transformer terminal-fault hand calculation bounds the model result correctly.
- CSVs, plots, SVG, workbook, and PDF were generated from source data.

## Common mistakes

- Sizing an upstream feeder from only local loads and omitting downstream panels.
- Confusing connected kW, demand kW, kVA, and breaker amperes.
- Applying a three-phase current formula to a 120 V single-phase circuit.
- Using conductor ampacity without temperature, bundling, terminal, and neutral checks.
- Treating balanced load flow as proof that a four-wire system is phase-balanced.
- Treating transformer `%Z` alone as the complete facility fault impedance.
- Reporting an SLG current without zero-sequence data.
- Calling breaker hierarchy a coordination study without time-current curves.

## Interview defense

Lead with the design iteration: the first executable model found an overloaded feeder and excessive phase imbalance. Explain how you traced downstream demand, corrected conductor capacity and phase allocation, reran the model, and then used stress cases to reveal that voltage, not transformer kVA, becomes the future constraint. Be explicit that the model is synthetic, balanced, and preliminary.

## Limitations and next steps

This MVP does not include unbalanced four-wire load flow, harmonics, motor starting, generator/PV contribution, protection curves, arc flash, grounding-grid analysis, cost estimation, construction drawings, or licensed-engineer review. Laptop refinement instructions are in `laptop-handoff/README.md`.

## Reference framework

- NFPA 70 / NEC for safe installation requirements, subject to adopted edition and local amendments.
- IEEE 3002.2-2018 for industrial/commercial load-flow study practice.
- IEEE 3002.3-2018 for industrial/commercial short-circuit study practice.
- Pandapower documentation and IEC 60909 implementation for the executable short-circuit model.

The GitHub project supplied in the prompt was used only as high-level inspiration; no code, data, or drawings were copied.
