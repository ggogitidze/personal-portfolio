# Requirements specification — Rev A MVP

Status: design targets, not measured performance.

| ID | Requirement | Acceptance method |
|---|---|---|
| PWR-01 | USB-C bus powered, 5 V nominal, USB 2.0 default-current load; no USB-PD negotiation | inspect schematic; bench current test |
| PWR-02 | Protected 3.3 V rail, design load <=150 mA, normal estimate <80 mA | calculation; bench measurement |
| AIN-01 | Two simultaneous-user analog connectors, single-ended 0–3.0 V, DC coupled | schematic review; DC sweep |
| AIN-02 | 12-bit conversion, 3.3 V reference, 0.806 mV nominal LSB | calculation; code check |
| AIN-03 | Per-channel sample rate selectable through 20 kS/s; target signal bandwidth 5 kHz | firmware timing; sine sweep |
| AIN-04 | Input must tolerate accidental -0.3 to 5.5 V through series impedance/clamps without damage (design intent; bench abuse test deferred) | review and controlled test |
| AOUT-01 | One 12-bit-command PWM analog output, 0–3.3 V nominal, useful bandwidth <=100 Hz, load >=10 kohm | scope/DMM test |
| USB-01 | USB 2.0 full-speed CDC device; binary framed samples and text commands | enumeration and host test |
| DBG-01 | 10-pin 1.27 mm Cortex SWD header with SWDIO, SWCLK, NRST, 3V3, GND | continuity/program test |
| PHY-01 | Two-layer, 1.6 mm FR-4, 1 oz copper, target board <=80 x 55 mm | KiCad inspection/fab quote |
| ENV-01 | Prototype laboratory use, 0–50 °C; not medical/safety certified | documentation review |

## Explicit non-requirements

No galvanic isolation, calibrated instrument accuracy, IEC 60601 compliance, USB certification, ± voltage input, or production EMC qualification in Rev A.
