#!/usr/bin/env python3
"""Receive framed samples from serial, save CSV, optionally plot; simulation works without hardware."""
import argparse,csv,struct,time,math,random
SYNC=0xA55A; N=32; FMT="<HHI"+"H"*(2*N)+"HH"; SIZE=struct.calcsize(FMT)
def crc16(data):
 c=0xffff
 for b in data:
  c^=b<<8
  for _ in range(8): c=((c<<1)^0x1021)&0xffff if c&0x8000 else (c<<1)&0xffff
 return c
def parse_frame(raw):
 if len(raw)!=SIZE: raise ValueError("wrong frame length")
 v=struct.unpack(FMT,raw)
 if v[0]!=SYNC or crc16(raw[:-2])!=v[-1]: raise ValueError("sync/CRC failure")
 return {"seq":v[1],"t_us":v[2],"ch0":v[3:35],"ch1":v[35:67],"status":v[67]}
def simulated(frames,rate):
 for seq in range(frames):
  t0=seq*N/rate
  a=[int(2048+1500*math.sin(2*math.pi*123*(t0+i/rate))) for i in range(N)]
  b=[max(0,min(4095,int(1000+random.gauss(0,8)))) for _ in range(N)]
  vals=[SYNC,seq,int(t0*1e6),*a,*b,0]; body=struct.pack(FMT[:-1],*vals); yield parse_frame(body+struct.pack("<H",crc16(body)))
def serial_frames(port,count):
 import serial
 with serial.Serial(port,115200,timeout=2) as s:
  buf=bytearray()
  while count:
   buf.extend(s.read(256)); marker=struct.pack("<H",SYNC); p=buf.find(marker)
   if p<0: buf[:]=buf[-1:]; continue
   if len(buf)-p<SIZE: continue
   raw=bytes(buf[p:p+SIZE]); del buf[:p+SIZE]
   try: yield parse_frame(raw); count-=1
   except ValueError: pass
def main():
 p=argparse.ArgumentParser();p.add_argument("--port");p.add_argument("--frames",type=int,default=10);p.add_argument("--rate",type=float,default=20000);p.add_argument("--csv",default="capture.csv");p.add_argument("--plot");a=p.parse_args()
 source=serial_frames(a.port,a.frames) if a.port else simulated(a.frames,a.rate); rows=[]
 for f in source:
  for i,(x,y) in enumerate(zip(f["ch0"],f["ch1"])): rows.append((f["seq"],f["t_us"]+round(i*1e6/a.rate),x,y,x*3.3/4096,y*3.3/4096,f["status"]))
 with open(a.csv,"w",newline="") as o:
  w=csv.writer(o);w.writerow(["frame","time_us","ch0_code","ch1_code","ch0_v","ch1_v","status"]);w.writerows(rows)
 if a.plot:
  import matplotlib.pyplot as plt
  t=[r[1]/1e6 for r in rows];plt.plot(t,[r[4] for r in rows],label="CH0");plt.plot(t,[r[5] for r in rows],label="CH1");plt.xlabel("Time (s)");plt.ylabel("Volts");plt.grid();plt.legend();plt.tight_layout();plt.savefig(a.plot,dpi=180)
 print(f"wrote {len(rows)} samples to {a.csv}")
if __name__=="__main__": main()
