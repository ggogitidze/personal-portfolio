# Exact KiCad / laptop completion guide

## Install and start

1. Install KiCad 8 or newer, STM32CubeIDE, Git, Python 3.11+, and an ST-LINK driver/tool.
2. Create `hardware/kicad/usb_mixed_signal_stm32_daq.kicad_pro`.
3. Add hierarchical sheets: `usb_power`, `mcu_debug`, `analog_in_adc`, `analog_out_ui`.
4. Enter circuits from `schematic_ready_connections.csv`; do **not** blindly trust symbol pin numbers. Cross-check every symbol against the current datasheet.

## Schematic signoff

1. Annotate, assign values/MPNs, and add net labels exactly as listed.
2. Run Inspect → Electrical Rules Checker. Resolve every error; justify any exclusions in an ERC log.
3. Tools → Assign Footprints. Prefer SOIC/LQFP/0603/0805 as specified.
4. Open every footprint in the viewer; cross-check pad number, pitch, exposed-pad behavior, connector orientation, and courtyard against manufacturer drawings.
5. Print connector/MCU footprints 1:1 and place physical parts on paper.

## Board setup and routing

1. Import from schematic. Set outline <=80 x 55 mm and fab clearance/minimum rules.
2. Ask the chosen fab for a two-layer controlled-impedance recommendation. Create `USB_DIFF` net class using its width/spacing for 90 Ω differential.
3. Place in functional order described in `layout_strategy.md`; lock connectors and mounting holes first.
4. Route USB first, then power, analog, SPI, PWM, and remaining GPIO. Pour bottom GND; inspect that no high-speed trace crosses a plane break.
5. Add stitching vias around board edge and near signal-layer transitions, without creating stubs on D+/D-.
6. Run DRC. Resolve every violation; inspect differential length/spacing and unconnected count.
7. Inspect front/back copper, solder mask, silkscreen readability/polarity, courtyard overlaps, and 3D view.

## Outputs

1. Plot Gerbers: copper, mask, silkscreen, Edge.Cuts; generate drill files and IPC-356 if fab accepts it.
2. Open the plotted files in KiCad Gerber Viewer—this is a separate verification step.
3. Export BOM and position files; compare BOM references/counts against `bom.csv`.

## CLI gates after KiCad project exists

```bash
kicad-cli sch erc hardware/kicad/usb_mixed_signal_stm32_daq.kicad_sch -o hardware/kicad/erc.rpt
kicad-cli pcb drc hardware/kicad/usb_mixed_signal_stm32_daq.kicad_pcb -o hardware/kicad/drc.rpt
kicad-cli pcb render hardware/kicad/usb_mixed_signal_stm32_daq.kicad_pcb -o hardware/kicad/board.png
```

Do not order boards until the final acceptance checklist passes and an experienced reviewer checks USB-C, power, MCU boot/debug, ADC reference/input, and connector footprints.
