# USB Mixed-Signal STM32 Data-Acquisition Board

## Short summary

A compact USB-powered, two-channel data-acquisition board designed around an STM32G0, an external 12-bit SPI ADC, protected analog conditioning, and a filtered PWM output. The project connects requirements, mixed-signal PCB decisions, embedded buffering, a CRC-framed USB protocol, and a Python capture/plot workflow.

## Case study

The goal was not to claim laboratory-instrument accuracy; it was to design a credible, manufacturable Rev A that exposes the real interfaces between analog, digital, firmware, and test engineering. Requirements define two 0–3.0 V channels, 20 kS/s per channel, 5 kHz target bandwidth, USB CDC transport, and a small two-layer board.

I selected the STM32G0B1 for native USB FS, SWD, SPI, timers, and an assembly-friendly LQFP package. I deliberately chose the MCP3202 rather than a more impressive 24-bit converter: its two-channel SPI interface and SOIC package reduce first-board risk while still requiring external-ADC timing, referencing, filtering, and layout discipline. TLV9062 unity buffers isolate input RC networks from the ADC's switched-capacitor input. A filtered PWM path provides slow analog stimulus without adding another precision converter.

The layout strategy uses one continuous ground plane and placement-based analog/digital partitioning. That keeps return currents predictable and avoids the classic mistake of routing signals across split grounds. USB ESD protection sits at the connector; D+/D- stay paired over uninterrupted ground. Analog filter/buffer/ADC loops are compact, and SPI/PWM are kept away from high-impedance input nodes.

Verification is layered: executable calculation scripts, native C tests for framing/buffering/PWM math, Python parser and simulated captures, then explicit KiCad ERC/DRC and bench gates. Performance numbers are labeled calculated, simulated, or measured; this package contains no fabricated hardware results.

## Resume bullets

- Designed a schematic-ready two-channel STM32 USB DAQ architecture with protected 0–3.0 V inputs, external 12-bit SPI conversion, 20 kS/s/channel target, and mixed-signal PCB constraints.
- Implemented and unit-tested ping-pong sample buffering, CRC-16 framed transport, sequence/error reporting, and 12-bit PWM control in portable C.
- Built a Python capture/plot utility and verification package covering filter, quantization, noise, power, USB routing, bring-up, and Rev-A risk controls.

## 30-second recruiter explanation

“I built a complete Rev-A design package for a USB mixed-signal STM32 acquisition board. It has two protected analog channels, an external 12-bit SPI ADC, buffered USB sample streaming, and a filtered PWM output. The important part is that I connected circuit calculations and return-path-aware PCB constraints to tested firmware and a Python host tool. I’m careful to separate what I verified in software from the ERC, DRC, and bench measurements still required before calling it hardware-validated.”

## Known limitations / next revision

Rev A is non-isolated, uncalibrated, uses the 3.3 V rail as ADC reference, has only a one-pole analog anti-alias filter, and uses PWM rather than a precision DAC. Rev B would add a precision reference, second-order active filtering, optional differential inputs, input range selection, and a true DAC after Rev-A measurements justify them.
