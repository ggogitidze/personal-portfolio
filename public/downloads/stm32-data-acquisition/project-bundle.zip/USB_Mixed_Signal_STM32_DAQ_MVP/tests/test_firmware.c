#include <assert.h>
#include <stdio.h>
#include "daq_core.h"
int main(void){daq_state_t s;daq_init(&s);for(unsigned i=0;i<32;i++)daq_push(&s,i,4095-i,i*50);daq_frame_t*f=0;assert(daq_take_ready(&s,&f));assert(daq_frame_valid(f));assert(f->sequence==0&&f->ch0[31]==31&&f->ch1[0]==4095);assert(daq_pwm_compare(0,999)==0);assert(daq_pwm_compare(4095,999)==999);assert(daq_pwm_compare(2048,999)>=499&&daq_pwm_compare(2048,999)<=500);puts("firmware core tests passed");}
