import struct
import sys
from pathlib import Path
import pytest
sys.path.insert(0,str(Path(__file__).parents[1]/"host-software"))
import daq_host
def test_simulated_frames():
 f=list(daq_host.simulated(2,20000));assert len(f)==2 and f[1]["seq"]==1 and len(f[0]["ch0"])==32
def test_crc_rejects():
 values=[daq_host.SYNC,0,0,*([2048]*daq_host.N),*([1000]*daq_host.N),0]
 body=struct.pack(daq_host.FMT[:-1],*values)
 raw=bytearray(body+struct.pack("<H",daq_host.crc16(body)))
 raw[10]^=0x01
 with pytest.raises(ValueError,match="sync/CRC failure"):
  daq_host.parse_frame(raw)
