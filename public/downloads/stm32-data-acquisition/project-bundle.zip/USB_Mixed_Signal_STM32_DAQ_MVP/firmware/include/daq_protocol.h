#pragma once
#include <stdint.h>
#include <stddef.h>
#define DAQ_SYNC 0xA55Au
#define DAQ_SAMPLES_PER_FRAME 32u
#if defined(_MSC_VER)
#pragma pack(push, 1)
#define DAQ_PACKED
#else
#define DAQ_PACKED __attribute__((packed))
#endif
typedef struct DAQ_PACKED {
  uint16_t sync; uint16_t sequence; uint32_t timestamp_us;
  uint16_t ch0[DAQ_SAMPLES_PER_FRAME]; uint16_t ch1[DAQ_SAMPLES_PER_FRAME];
  uint16_t status; uint16_t crc16;
} daq_frame_t;
#if defined(_MSC_VER)
#pragma pack(pop)
#endif
#undef DAQ_PACKED
uint16_t daq_crc16_ccitt(const uint8_t *data, size_t len);
int daq_frame_valid(const daq_frame_t *f);
