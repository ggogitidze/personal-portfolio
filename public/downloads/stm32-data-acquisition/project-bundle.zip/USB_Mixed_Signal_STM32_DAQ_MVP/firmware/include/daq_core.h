#pragma once
#include <stdint.h>
#include "daq_protocol.h"
typedef struct {daq_frame_t frames[2];uint8_t fill;uint8_t ready_mask;uint8_t active;uint16_t seq;uint32_t dropped;} daq_state_t;
void daq_init(daq_state_t *s);
void daq_push(daq_state_t *s,uint16_t a,uint16_t b,uint32_t timestamp_us);
int daq_take_ready(daq_state_t *s,daq_frame_t **frame);
uint16_t daq_pwm_compare(uint16_t code12,uint16_t period);
