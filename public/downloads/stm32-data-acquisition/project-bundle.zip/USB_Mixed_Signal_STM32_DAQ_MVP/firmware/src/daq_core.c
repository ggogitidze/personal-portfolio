#include "daq_core.h"
#include <string.h>
void daq_init(daq_state_t*s){memset(s,0,sizeof(*s));s->frames[0].sync=s->frames[1].sync=DAQ_SYNC;}
void daq_push(daq_state_t*s,uint16_t a,uint16_t b,uint32_t t){daq_frame_t*f=&s->frames[s->active];f->ch0[s->fill]=a&0x0FFF;f->ch1[s->fill]=b&0x0FFF;f->timestamp_us=t;if(++s->fill==DAQ_SAMPLES_PER_FRAME){f->sequence=s->seq++;f->status=s->dropped?1:0;f->crc16=daq_crc16_ccitt((const uint8_t*)f,sizeof(*f)-2);uint8_t bit=1u<<s->active;if(s->ready_mask&bit)s->dropped++;else s->ready_mask|=bit;s->active^=1;s->fill=0;}}
int daq_take_ready(daq_state_t*s,daq_frame_t**f){for(int i=0;i<2;i++)if(s->ready_mask&(1u<<i)){*f=&s->frames[i];s->ready_mask&=~(1u<<i);return 1;}return 0;}
uint16_t daq_pwm_compare(uint16_t code12,uint16_t period){if(code12>4095)code12=4095;return (uint16_t)(((uint32_t)code12*period+2047)/4095);}
