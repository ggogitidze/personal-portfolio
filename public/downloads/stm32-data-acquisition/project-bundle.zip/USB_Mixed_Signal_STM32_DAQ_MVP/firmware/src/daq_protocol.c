#include "daq_protocol.h"
uint16_t daq_crc16_ccitt(const uint8_t *p,size_t n){uint16_t c=0xFFFF;while(n--){c^=(uint16_t)(*p++)<<8;for(int i=0;i<8;i++)c=(c&0x8000)?(uint16_t)((c<<1)^0x1021):(uint16_t)(c<<1);}return c;}
int daq_frame_valid(const daq_frame_t *f){return f&&f->sync==DAQ_SYNC&&daq_crc16_ccitt((const uint8_t*)f,sizeof(*f)-2)==f->crc16;}
