/* CubeMX integration template; intentionally excluded from native tests.
 * Configure: SPI1 mode 0; TIM sample trigger 20 kHz; TIM1 PWM 250 kHz;
 * USB Device CDC; GPIO LED/button; DMA if desired.
 */
#include "daq_core.h"
static daq_state_t daq;
extern uint16_t board_mcp3202_read(unsigned channel); /* implement with HAL_SPI */
extern uint32_t board_micros(void);
extern int board_usb_cdc_tx(const uint8_t*,uint16_t); /* return 0 when accepted */
extern void board_pwm_set_compare(uint16_t);
void app_init(void){daq_init(&daq);}
void app_sample_timer_callback(void){
  uint16_t a=board_mcp3202_read(0), b=board_mcp3202_read(1);
  daq_push(&daq,a,b,board_micros());
}
void app_poll(void){daq_frame_t*f;if(daq_take_ready(&daq,&f)){
  if(board_usb_cdc_tx((const uint8_t*)f,(uint16_t)sizeof(*f))!=0) daq.dropped++;
}}
void app_set_output(uint16_t code12,uint16_t timer_period){board_pwm_set_compare(daq_pwm_compare(code12,timer_period));}
