# USB Mixed-Signal STM32 Data-Acquisition Board

Schematic-ready Rev-A MVP for a USB-powered two-channel acquisition/control board. This package is deliberately honest: calculations and software are executable; no ERC, DRC, target build, fabrication, or bench measurement is claimed.

## Design at a glance

- STM32G0B1CBT6, LQFP-48, USB 2.0 full-speed CDC and SWD.
- MCP3202 dual 12-bit SPI ADC using 3.3 V analog rail/reference.
- Two 0–3.0 V inputs: series protection, Schottky clamps, 10.6 kHz RC filters, TLV9062 buffers.
- 20 kS/s/channel target; 5 kHz useful signal-band target.
- 250 kHz PWM through two 4.82 kHz RC poles for slow 0–3.3 V output.
- USB-C 5 V input, CC pull-downs, data-line ESD, PTC fuse, 3.3 V low-noise LDO.
- Continuous ground plane and placement-based mixed-signal partitioning.

## How the blocks interact

USB supplies 5 V and transports samples. The protected LDO creates 3V3_DIG; a ferrite-fed 3V3_ANA powers buffers and ADC. Inputs are filtered/buffered before conversion. A timer triggers paired SPI conversions; ping-pong buffers decouple sampling from USB latency. Frames add sync, sequence, status, and CRC. The host parses frames into engineering units. PWM provides a low-bandwidth output/loopback stimulus.

## Key decisions

The external MCP3202 proves converter/SPI integration without the input/clock complexity of a 24-bit delta-sigma design. LQFP/SOIC packages are student-assembly friendly. One ground plane avoids broken return paths. The 3.3 V rail as reference and PWM output are conscious cost/scope compromises, documented as Rev-A limitations.

## Repository map

- `requirements/`: measurable targets and acceptance methods.
- `hardware/`: block/power diagrams, trade study, pins, schematic-ready connections, layout rules.
- `calculations/`: executable math and interpretation.
- `firmware/`: portable protocol/core, STM32 HAL integration template, CMake native tests.
- `host-software/`: serial/simulation capture, CSV, plot utility.
- `tests/`: firmware and host tests.
- `bom/`: BOM CSV/XLSX.
- `report/`: bring-up, risks, review, interview preparation.
- `portfolio/`: case-study copy, summary, resume bullets, recruiter explanation.
- `laptop-handoff/`: exact KiCad completion gates.

## Reproduce verified software

```bash
python3 calculations/design_calculations.py
cmake -S firmware -B build && cmake --build build && ctest --test-dir build --output-on-failure
python3 -m pytest -q
python3 host-software/daq_host.py --frames 50 --csv results/capture.csv --plot results/simulated_capture.png
```

Install `pyserial` for hardware capture and `matplotlib` for plots. Run `python3 host-software/daq_host.py --port /dev/ttyACM0 --frames 100 --csv capture.csv --plot capture.png` after enumeration.

## Firmware target build

Create a CubeMX project for the exact STM32G0B1CBT6 package. Enable USB Device CDC, SPI1 mode 0, a 20 kHz sampling timer, TIM1 PWM at 250 kHz, SWD, LED/button GPIO, and copy the portable sources plus HAL integration template. Confirm MCP3202 command bit timing against its current datasheet before implementing `board_mcp3202_read`. Native tests do not prove HAL or hardware timing.

## Bring-up order

Unpowered inspection/ohms → current-limited rails → SWD/blink → USB enumeration → ADC DC tests → noise/sine tests → PWM → loopback → sustained streaming. See `report/bringup_test_plan.md`.

## Common PCB mistakes

Wrong USB-C connector pad numbering; missing CC pull-downs; ESD placed far from connector; D+/D- routed over plane gaps; split grounds; decouplers connected through long traces; incorrect MCU alternate-function pins; swapped SWD pins; ADC reference treated like an ordinary rail; op amp driven outside input/output headroom; and declaring DRC clean without opening generated Gerbers.

## Interview framing

Lead with requirements and tradeoffs. Explain why buildability beat inflated resolution, why ground is continuous, how buffers/filters interact with SAR conversion, and how sequence/CRC/error paths make failures observable. State verification boundaries precisely.

## Status

Completed here: requirements, architecture, schematic-ready connection data, calculations, BOM, portable firmware core, native tests, host utility, simulation output, test/risk/review plans, report material, portfolio copy, and handoff.

Laptop verification required: exact-symbol/package pin audit, CubeMX target configuration/build, KiCad schematic/PCB capture, ERC, DRC, impedance geometry, 3D inspection, Gerbers, assembly, and all bench measurements.
