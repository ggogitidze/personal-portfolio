import fs from 'fs';
import { Workbook } from '@oai/artifact-tool';

const lines = fs.readFileSync('bom/bom.csv','utf8').trim().split(/\r?\n/);
const parse = s => { let a=[],v='',q=false; for(let i=0;i<s.length;i++){const c=s[i];if(c==='"'){if(q&&s[i+1]==='"'){v+='"';i++;}else q=!q;}else if(c===','&&!q){a.push(v);v='';}else v+=c;}a.push(v);return a; };
const data=lines.map(parse);
const wb=Workbook.create();
const sh=wb.worksheets.add('BOM');
sh.getRangeByIndexes(0,0,data.length,data[0].length).values=data;
sh.getRange('A1:J1').format={fill:'#17365D',font:{bold:true,color:'#FFFFFF'},verticalAlignment:'center',wrapText:true};
sh.freezePanes.freezeRows(1);
sh.getRange(`A1:J${data.length}`).format.wrapText=true;
const widths=[7,7,14,22,25,34,14,13,24,30];
for(let i=0;i<widths.length;i++) sh.getRangeByIndexes(0,i,data.length,1).format.columnWidth=widths[i];
sh.getRange(`A2:B${data.length}`).format.horizontalAlignment='center';
sh.getRange(`H2:H${data.length}`).format.numberFormat='$0.00';
sh.getRange(`A1:J${data.length}`).format.autofitRows();
const xlsx=await wb.export({format:'xlsx'});
fs.writeFileSync('bom/USB_Mixed_Signal_DAQ_BOM.xlsx',Buffer.from(await xlsx.arrayBuffer()));
