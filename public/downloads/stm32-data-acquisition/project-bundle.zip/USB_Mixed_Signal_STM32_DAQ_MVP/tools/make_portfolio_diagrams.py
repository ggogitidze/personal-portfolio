from pathlib import Path
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch

out=Path('portfolio/images');out.mkdir(parents=True,exist_ok=True)
def box(ax,xy,w,h,text,color):
 ax.add_patch(FancyBboxPatch(xy,w,h,boxstyle='round,pad=.02',facecolor=color,edgecolor='#17365d',linewidth=1.5))
 ax.text(xy[0]+w/2,xy[1]+h/2,text,ha='center',va='center',fontsize=10,weight='bold',color='#10243e')
def arrow(ax,a,b): ax.add_patch(FancyArrowPatch(a,b,arrowstyle='-|>',mutation_scale=14,color='#4b6478',linewidth=1.4))
fig,ax=plt.subplots(figsize=(12,5));ax.set_xlim(0,12);ax.set_ylim(0,5);ax.axis('off')
box(ax,(.3,2),1.6,1,'USB-C\n5 V + data','#d9eaf7');box(ax,(2.3,2),1.6,1,'Protection\n+ 3.3 V LDO','#e9eef2');box(ax,(4.4,2),1.8,1,'STM32G0B1\nUSB + control','#cfe2f3');box(ax,(7.1,3.3),1.8,1,'MCP3202\n12-bit ADC','#d9ead3');box(ax,(9.8,3.3),1.8,1,'2× filtered\nanalog inputs','#fff2cc');box(ax,(7.1,.7),1.8,1,'250 kHz PWM','#fce5cd');box(ax,(9.8,.7),1.8,1,'2-pole filter\nanalog output','#eadcf8')
for a,b in [((1.9,2.5),(2.3,2.5)),((3.9,2.5),(4.4,2.5)),((6.2,2.7),(7.1,3.7)),((9.8,3.8),(8.9,3.8)),((6.2,2.3),(7.1,1.2)),((8.9,1.2),(9.8,1.2))]:arrow(ax,a,b)
ax.text(6,4.75,'USB Mixed-Signal STM32 DAQ — Rev A Architecture',ha='center',fontsize=16,weight='bold',color='#17365d');fig.tight_layout();fig.savefig(out/'architecture.png',dpi=200,bbox_inches='tight');plt.close(fig)

fig,ax=plt.subplots(figsize=(10,4.2));ax.set_xlim(0,10);ax.set_ylim(0,4);ax.axis('off')
box(ax,(.4,1.5),1.6,1,'USB VBUS\n5 V','#d9eaf7');box(ax,(2.6,1.5),1.8,1,'Fuse + TVS','#e9eef2');box(ax,(5.0,1.5),1.8,1,'TPS7A2033\n3.3 V LDO','#cfe2f3');box(ax,(7.7,2.5),1.8,1,'3V3_DIG\nMCU + LEDs','#fce5cd');box(ax,(7.7,.5),1.8,1,'3V3_ANA\nADC + buffers','#d9ead3')
for a,b in [((2,2),(2.6,2)),((4.4,2),(5,2)),((6.8,2.1),(7.7,3)),((6.8,1.9),(7.7,1))]:arrow(ax,a,b)
ax.text(5,3.8,'Power Tree',ha='center',fontsize=16,weight='bold',color='#17365d');ax.text(7.15,.9,'ferrite',fontsize=9,color='#4b6478');fig.tight_layout();fig.savefig(out/'power_tree.png',dpi=200,bbox_inches='tight');plt.close(fig)
