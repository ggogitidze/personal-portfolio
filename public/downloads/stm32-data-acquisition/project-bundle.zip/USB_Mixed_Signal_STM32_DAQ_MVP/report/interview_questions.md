# Technical interview questions and model answers

1. **Why not split analog and digital grounds?** A continuous plane gives every signal a short return path. I partitioned by placement and current flow; a split can force USB/SPI returns around a gap and increase loop area.
2. **Why an external 12-bit ADC if the MCU has one?** It demonstrates SPI converter integration and isolates conversion choices from MCU internals. The MCP3202 is intentionally modest and buildable; Rev A prioritizes completion over headline resolution.
3. **What does 12-bit resolution mean here?** With 3.3 V reference, one ideal code is 0.806 mV. That is resolution, not accuracy; offset, gain, reference, INL, noise, and layout add error.
4. **Why is ±0.5 LSB the quantization bound?** Rounding maps a continuum into code bins; absent clipping, the maximum difference to the bin center is half a code.
5. **Does a 10.6 kHz RC prevent aliasing at 20 kS/s?** No. It is a gentle first-order aid and is only about 7 dB down at 20 kHz. The input spectrum must be constrained; a steeper filter is a Rev-B improvement.
6. **Why buffer the inputs?** The op amp presents high input impedance and supplies transient charge to the SAR ADC input. The 47 Ω resistor helps isolate capacitive kickback.
7. **Why 90 Ω USB differential routing?** USB is a controlled-impedance differential channel. Actual width/spacing comes from the chosen fab stackup; guessing geometry would be false precision.
8. **How do you detect dropped data?** Frames carry sequence numbers and a status flag; firmware counts buffer/USB backpressure drops and the host can identify gaps.
9. **What is verified?** Calculation outputs, native C buffering/CRC/PWM tests, and simulated host capture. KiCad ERC/DRC, target compilation, enumeration, and analog performance are not yet verified.
10. **First bench failure you expect?** USB/footprint mistakes are high-impact, followed by analog headroom/reference noise. The bring-up plan isolates power, SWD, USB, ADC, then output in that order.
