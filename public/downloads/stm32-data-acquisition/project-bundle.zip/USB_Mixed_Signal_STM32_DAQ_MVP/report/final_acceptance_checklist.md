# Final acceptance checklist

## Package acceptance — completed

- [x] Requirements have IDs and acceptance methods.
- [x] Architecture, power tree, trade study, pins, connections, and layout rules exist.
- [x] Calculations execute and results are saved.
- [x] Portable C compiles with strict warnings and native tests pass.
- [x] Host protocol/simulation assertion passes; CSV and plots are generated.
- [x] CSV and formatted XLSX BOM are present.
- [x] Bring-up, risk, review, interview, report, portfolio, and handoff documents are present.
- [x] No hardware/PCB verification is falsely claimed.

## Laptop design acceptance — pending

- [ ] Current datasheet revision and lifecycle checked for every major part.
- [ ] Exact MCU pin/alternate-function map verified in CubeMX.
- [ ] MCP3202 SPI command/timing and sample-rate limits verified at 3.3 V.
- [ ] Schematic captured; ERC has zero unexplained errors/warnings.
- [ ] Every footprint pin mapping and 1:1 mechanical print checked.
- [ ] PCB placed/routed over continuous ground using fab-provided 90 Ω USB geometry.
- [ ] DRC clean; 3D review complete; independent Gerber/drill review complete.
- [ ] STM32 target firmware compiles with zero errors and archived tool versions.

## Hardware acceptance — pending

- [ ] Power/short/current-limited bring-up passes.
- [ ] SWD programming and USB enumeration pass.
- [ ] Both inputs meet range, rate, DC error, noise, and bandwidth criteria after criteria are numerically finalized.
- [ ] Output DC levels/ripple meet defined load criteria.
- [ ] Sequence/CRC/drop handling survives one-hour stream.
- [ ] Thermal and protection tests pass within safe laboratory limits.
- [ ] Measured results replace planning estimates in report and portfolio.
