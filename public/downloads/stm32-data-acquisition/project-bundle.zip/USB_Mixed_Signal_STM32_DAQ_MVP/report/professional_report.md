# Engineering Report — USB Mixed-Signal STM32 Data-Acquisition Board

**Revision:** A MVP design package  
**Author:** Giorgi Gogitidze  
**Status:** software/calculations verified; PCB and hardware unverified

## Executive summary

This project develops a manufacturable-scope, USB-powered, two-channel data-acquisition board for educational and portfolio use. The architecture combines USB-C power/data, an STM32G0 MCU, external 12-bit conversion, protected and buffered analog inputs, a filtered PWM output, SWD debug, and a host capture utility. Rev A emphasizes traceable requirements, buildability, signal-return discipline, observable firmware failure modes, and an explicit verification boundary.

## Requirements and architecture

The board targets 0–3.0 V inputs, 20 kS/s per channel, 5 kHz useful signal bandwidth, 12-bit nominal conversion, and USB CDC streaming. It is a laboratory prototype, not an isolated or certified instrument. USB VBUS feeds a protected 3.3 V supply; analog supply noise is reduced with a ferrite-fed placement zone while all grounds share one continuous plane.

## Circuit design

USB-C CC1/CC2 each use a 5.1 kΩ sink resistor. Low-capacitance ESD protection is placed at the connector, and D+/D- use tuneable series-resistor footprints before the MCU. The TPS7A2033 supplies 3.3 V with estimated 0.136 W dissipation at the 80 mA design load.

Each input passes through 1 kΩ and 15 nF, producing a 10.61 kHz pole, then rail clamps and a TLV9062 unity buffer. A 47 Ω output isolator feeds an MCP3202 channel. The 3.3 V analog rail serves as ADC reference in Rev A; therefore rail noise and tolerance directly affect accuracy. The output is 250 kHz PWM filtered by two 3.3 kΩ/10 nF poles. It is appropriate for slow stimulus/control, not precision waveform generation.

## Firmware and software

A timer-driven acquisition path reads paired ADC samples into two alternating 32-sample buffers. Frames include sync, sequence, timestamp, status, and CRC-16-CCITT so the host can reject corruption and identify drops. USB transmission is kept outside the sampling callback. The host tool supports simulated or serial input, CSV export, voltage conversion, and plotting.

## Verification evidence

The calculation script executed successfully. Portable C was compiled with `-std=c11 -Wall -Wextra -Werror`; its CRC, buffer, sequence, and PWM checks passed. The Python parser/simulator assertion test passed and generated 1,600 samples, CSV output, and a PNG plot. CMake, pytest, KiCad, and the ARM cross-compiler were unavailable, so no claim is made for those toolchains. No target MCU build, ERC, DRC, USB enumeration, fabrication, or electrical measurement has occurred.

## Engineering judgment and limitations

The first-order input filter does not provide strong Nyquist rejection and the ADC reference is not precision-grade. The protection network may add leakage/capacitance. PWM output performance depends on load. These are appropriate Rev-A compromises only because they are visible, testable, and paired with concrete Rev-B paths.

## Conclusion

The package is a complete schematic-ready MVP and credible portfolio case study, but it is not yet a finished PCB. Completion requires exact datasheet pin audits, KiCad capture, ERC/DRC, stackup-specific USB geometry, target firmware build, fabrication review, and staged bench validation.
