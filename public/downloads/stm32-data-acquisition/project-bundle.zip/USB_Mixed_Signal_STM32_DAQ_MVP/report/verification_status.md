# Verification status — 2026-09-22

| Item | Status | Evidence |
|---|---|---|
| Engineering calculations | PASS | `calculations/results.json` produced by script |
| Portable C compile | PASS | CMake/MSVC native Release build completed |
| Firmware core test | PASS | CTest: 1/1 native test passed |
| Host frame simulation/parser | PASS | direct Python assertions, 3 frames |
| 50-frame simulated capture | PASS | 1,600 data rows plus header |
| Portfolio PNG generation | PASS | three valid PNG files |
| BOM XLSX container | PASS | ZIP structure tested; Excel 2007+ identified |
| CMake workflow | PASS | configure, Release build, and CTest completed on Windows |
| pytest suite | PASS | 2 host-software tests passed, including CRC corruption rejection |
| ARM target compile | NOT RUN | ARM cross-compiler/CubeIDE unavailable |
| KiCad ERC/DRC/3D | NOT RUN | KiCad unavailable; no `.kicad_sch`/`.kicad_pcb` fabricated |
| Hardware measurements | NOT RUN | no physical PCB |

“PASS” applies only to the named artifact or software behavior, not to electrical performance.
