# Risk register and design-review gates

| Risk | Likelihood | Impact | Mitigation / gate |
|---|---|---|---|
| USB fails enumeration | M | H | copy ST reference topology; verify pins/clock in CubeMX; D+/D- continuity and scope |
| Wrong USB-C footprint | M | H | print 1:1, compare mechanical drawing and ordered suffix |
| Analog clipping near 3.0 V | M | M | DC sweep buffer output; preserve 0.3 V headroom; revise range if needed |
| ADC reference polluted by digital 3.3 V | M | M | ferrite/local bulk, placement, grounded-input FFT; Rev B precision reference |
| First-order input filter aliases | M | M | enforce 20 kS/s and 5 kHz signal band; document limitation; Rev B active filter |
| PWM ripple exceeds need | M | M | measure under load; lower bandwidth or add DAC in Rev B |
| SPI timing/data framing error | M | H | logic-analyzer capture; CRC and sequence checks; unit tests |
| LDO thermal issue | L | M | 0.136 W estimate, copper area, temperature test |
| Protection clamps inject noise | M | L | footprints allow DNI/substitution; characterize leakage/noise |
| Firmware throughput overrun | M | H | ping-pong buffers, frame sequence/status, sustained-stream test |

## Design review

- [ ] Datasheet revisions and lifecycle verified for every IC.
- [ ] Every power/ground pin connected and decoupled.
- [ ] MCU exact package pinout cross-checked with CubeMX.
- [ ] ADC SPI mode, acquisition timing, reference settling verified.
- [ ] USB-C CC resistors, ESD orientation, shield strategy reviewed.
- [ ] Connector pin numbering checked against mechanical drawings.
- [ ] ERC exclusions justified; no unexplained warnings.
- [ ] Footprints checked 1:1 and pin-to-pad mapping audited.
- [ ] DRC clean under fab rules; USB impedance agreed with fab.
- [ ] Gerbers/drills opened in an independent viewer.
