# Bring-up and test checklist

## Before power

- [ ] Visual microscope inspection: polarity, pin 1, bridges, tombstones, connector footprint.
- [ ] Resistance checks: VBUS-to-GND and 3V3-to-GND are not shorts; record values.
- [ ] Current-limited bench supply at 5.0 V/50 mA into VBUS test point, USB disconnected.

## Power and MCU

- [ ] Record VBUS, 3V3_DIG, 3V3_ANA and current; increase current limit only after rails are correct.
- [ ] Check LDO temperature. Verify NRST high and SWD target detection.
- [ ] Program LED-blink image, then USB CDC firmware. Record device enumeration and identifiers.

## ADC/input

- [ ] Apply 0, 0.5, 1.0, 2.0, 3.0 V from a known source to each channel; log mean, standard deviation, code error and channel crosstalk.
- [ ] Ground each input; capture >=10,000 samples for histogram/noise-free bits.
- [ ] Apply 1 kHz sine at safe amplitude; compare amplitude/frequency, clipping, FFT harmonics, and dropped-frame count.
- [ ] Sweep 100 Hz–20 kHz to estimate filter response. The 5 kHz useful-bandwidth requirement needs a defined amplitude-error limit in Rev B.

## Output and integration

- [ ] Command 0%, 25%, 50%, 75%, 100%; measure DC output and PWM ripple with x10 probe/spring ground.
- [ ] Loop AOUT to AIN through 1 kΩ; execute staircase and slow sine tests.
- [ ] Run one-hour stream; record USB errors, sequence gaps, current, and temperature.

Common equipment: DMM, current-limited supply, oscilloscope, function generator; logic analyzer optional. Never connect an external source above the documented range during ordinary tests.
