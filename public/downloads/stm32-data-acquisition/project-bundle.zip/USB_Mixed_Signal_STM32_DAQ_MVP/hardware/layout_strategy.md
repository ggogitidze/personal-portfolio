# PCB constraints and layout plan

## Stack and placement

Two-layer FR-4: top for components/signals; bottom kept as an almost continuous ground plane. Put USB connector/ESD at the board edge, MCU immediately behind USB, ADC and op amp together in the analog half, and input connectors at the opposite edge. LDO sits near USB power entry; ferrite bead marks the analog supply boundary.

## Rules

- USB D+/D-: 90 ohm differential target, same layer, tightly coupled, matched within 0.5 mm, minimal vias, no stubs, no plane gaps. Use the fabricator's field solver/impedance table; width/spacing is **not fixed here** because stackup controls it.
- Keep D+/D- away from PWM, SPI clock, board edge, and analog inputs; place ESD first from the connector's perspective.
- Continuous ground under USB and all signals. Never route across a plane void. Return current should remain directly below its outgoing trace.
- Put each 100 nF bypass capacitor beside its IC power pin with a short trace and dedicated ground via. Bulk capacitors do not replace local bypassing.
- Keep AIN_FILT, op-amp inputs, ADC inputs, and VREF loops short; no digital trace parallel to these nodes.
- Route SPI as a compact group over ground; reserve 22–47 ohm source-series footprints on SCK/MOSI if ringing is observed.
- Separate by placement, not by splitting ground. Join connector shield to chassis-style ground footprint through selectable 0 ohm/RC network; do not dump ESD current through analog return paths.
- Guard sensitive analog routing with grounded copper where practical, but avoid creating isolated copper slivers.
- Put test points on VBUS, 3V3_DIG, 3V3_ANA, NRST, SCK, CS, both ADC inputs, PWM, and AOUT.

## Preliminary floorplan

`[USB-C | ESD | fuse/LDO] [MCU | SWD | LEDs] [bead] [ADC/op amp/filters | AIN connectors]`

PWM output sits below the MCU, away from the ADC input edge. Ground-return paths from input connectors terminate near the analog circuitry and flow on the plane without crossing USB/PWM current concentrations.
