# Authoritative design references

Accessed 2026-09-22. Use the latest controlled revision during schematic signoff.

1. STMicroelectronics, STM32G0B1CB product page and datasheet: https://www.st.com/en/microcontrollers-microprocessors/stm32g0b1cb.html
2. STMicroelectronics, AN4879, *USB hardware and PCB design guidelines*: https://www.st.com/resource/en/application_note/an4879-introduction-to-usb-hardware-and-pcb-design-guidelines-using-stm32-microcontrollers-stmicroelectronics.pdf
3. Microchip, MCP3202 product documentation / datasheet: https://www.microchip.com/en-us/product/MCP3202
4. Texas Instruments, TLV9062 product page and datasheet: https://www.ti.com/product/TLV9062
5. Texas Instruments, TPS7A20 product page and datasheet: https://www.ti.com/product/TPS7A20
6. Littelfuse, SP05 series datasheet: https://www.littelfuse.com/assetdocs/tvs-diode-array-spasp050xba-lead-freegreen-datasheet
7. USB-IF, USB Type-C Cable and Connector Specification: https://www.usb.org/document-library/usb-type-cr-cable-and-connector-specification-release-24

The web-visible ST source confirms the STM32G0B1 includes USB 2.0 full-speed device capability and SWD. Microchip identifies MCP3202 as a two-channel 12-bit ADC with SPI-style serial interface. TI specifies TLV9062 as a dual 10 MHz RRIO amplifier and TPS7A20 as a 300 mA low-noise LDO. These are selection facts, not proof that this board meets end-product compliance.
