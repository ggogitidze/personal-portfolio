# Major-component trade study

Scores: 1 poor, 5 strong. Pricing is an unverified planning estimate for qty 1–10 and must be refreshed before purchase.

| Function / candidate | Availability | Cost | Hand assembly | Performance | Learning | Decision |
|---|---:|---:|---:|---:|---:|---|
| MCU: STM32G0B1CBT6, LQFP-48 | 4 | 4 | 5 | 4 | 5 | **Selected:** native crystal-less USB FS, SWD, SPI, timers, generous peripherals |
| MCU: RP2040, QFN | 5 | 5 | 2 | 4 | 4 | rejected: harder package and external flash |
| MCU: STM32F072CBT6 | 3 | 3 | 5 | 4 | 5 | alternate; older family |
| ADC: MCP3202-CI/SN, SOIC-8 | 4 | 4 | 5 | 3 | 5 | **Selected:** two channels, 12-bit SPI, simple layout/firmware |
| ADC: MCU internal 12-bit ADC | 5 | 5 | 5 | 2 | 3 | fallback; less separation of mixed-signal blocks |
| ADC: ADS131M02 | 3 | 2 | 2 | 5 | 5 | rejected Rev A: differential front end and clocking add risk |
| Op amp: TLV9062IDR, SOIC-8 | 4 | 4 | 5 | 4 | 4 | **Selected:** dual RRIO, 10 MHz, 1.8–5.5 V |
| LDO: TPS7A2033PDBVR, SOT-23-5 | 4 | 3 | 4 | 5 | 4 | **Selected:** 300 mA, low noise; ample headroom from 5 V |
| Output: timer PWM + 2-pole RC | 5 | 5 | 5 | 2 | 4 | **Selected:** sufficient for slow control/test stimulus |
| Output: external DAC (MCP4725) | 4 | 3 | 4 | 4 | 4 | Rev B option if DC accuracy/ripple matters |

Authoritative baseline sources: ST STM32G0B1 product page/datasheet; Microchip MCP3202 datasheet; TI TLV9062 and TPS7A20 datasheets; USB-IF Type-C/USB 2.0 documents. Exact limits must be rechecked against the downloaded revision before schematic signoff.
