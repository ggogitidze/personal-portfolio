# Architecture and power tree

```mermaid
flowchart LR
  USB["USB-C 5 V + D+/D-"] --> PROT["Fuse, TVS, ESD"]
  PROT --> LDO["3.3 V LDO"]
  LDO --> MCU["STM32G0B1"]
  LDO --> ANA["TLV9062 + MCP3202"]
  IN["2 x 0–3 V inputs"] --> ANA
  ANA -->|SPI + DRDY/CS| MCU
  MCU -->|PWM| FILT["2-pole RC output"]
  MCU -->|USB CDC| USB
  SWD["SWD header"] --> MCU
```

```mermaid
flowchart TD
  VBUS["USB VBUS 5 V"] --> F1["500 mA resettable fuse"]
  F1 --> TVS["5 V TVS + bulk 10 uF"]
  TVS --> REG["TPS7A2033 LDO"]
  REG --> D33["3V3_DIG"]
  REG --> FB["Ferrite bead"]
  FB --> A33["3V3_ANA"]
  D33 --> MCU["MCU, LEDs, USB pull circuitry"]
  A33 --> ADC["ADC, op amp, reference/decoupling"]
```

One continuous ground plane is used. “Analog” and “digital” describe placement and current-flow zones, not split ground nets. The bead separates supply noise only; AGND and DGND pins connect directly to the unbroken plane with local vias.
