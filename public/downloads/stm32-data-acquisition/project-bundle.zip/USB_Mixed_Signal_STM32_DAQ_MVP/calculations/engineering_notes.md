# Engineering calculations and interpretation

- ADC LSB: `VREF / 2^N = 3.3 / 4096 = 0.8057 mV`. Ideal quantization error is bounded by ±0.4028 mV; RMS quantization noise is 0.2326 mV under the usual uniformly distributed-error model.
- 0–3.0 V uses code range 0–3723 nominal, leaving rail margin for the unity buffers and protection network.
- Each analog input's 1 kΩ/15 nF pole is 10.61 kHz. This is above the 5 kHz target signal band. It is only a first-order anti-alias aid; the digital sampling rate must be >=20 kS/s/channel and out-of-band rejection is limited.
- Two 3.3 kΩ/10 nF PWM poles each have 4.82 kHz cutoff. At 250 kHz carrier, the ideal asymptotic two-pole attenuation is about 68.6 dB. Component/loading/parasitic effects make actual ripple a bench measurement.
- At 80 mA, LDO dissipation is `(5-3.3)*0.08 = 0.136 W`; headroom is 1.7 V. Thermal rise requires actual package/board thermal data and measurement.
- Planning noise is an RSS estimate, not a guarantee. The ADC contribution dominates at 0.45 LSB RMS. Reference/supply residual is assumed at 100 µV RMS pending measurement. This predicts roughly 10.8 effective bits; actual ENOB needs a grounded-input histogram and sine FFT.
- USB routes target 90 Ω differential. Trace width/spacing cannot be finalized without the fabricator's dielectric thickness and Dk.

## Approximate current budget

| Load | Estimate |
|---|---:|
| STM32 active + USB | 35 mA |
| MCP3202 | 1 mA |
| TLV9062 dual | 1.2 mA |
| LEDs (worst intended) | 6 mA |
| LDO/quiescent and dividers | 1 mA |
| margin / headers | 35.8 mA |
| **Design total** | **80 mA** |

Every row is an engineering estimate until firmware state and bench current are known.
