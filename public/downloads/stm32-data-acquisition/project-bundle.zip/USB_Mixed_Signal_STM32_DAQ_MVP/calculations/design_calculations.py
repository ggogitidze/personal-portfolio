"""Auditable Rev-A calculations. Values are design assumptions, not measurements."""
from math import pi, sqrt, log10
import json
from pathlib import Path

VREF=3.3; BITS=12; R_IN=1_000; C_IN=15e-9
PWM_R=3_300; PWM_C=10e-9; PWM_FREQ=250_000
I_LOAD=0.080; VIN=5.0; VOUT=3.3

lsb=VREF/(2**BITS)
results={
 "adc_lsb_v": lsb,
 "ideal_quantization_peak_v": lsb/2,
 "ideal_quantization_rms_v": lsb/sqrt(12),
 "ideal_quantization_snr_db_full_scale_sine": 6.02*BITS+1.76,
 "input_rc_fc_hz": 1/(2*pi*R_IN*C_IN),
 "pwm_each_pole_fc_hz": 1/(2*pi*PWM_R*PWM_C),
 "pwm_carrier_attenuation_two_pole_db_approx": -40*log10(PWM_FREQ/(1/(2*pi*PWM_R*PWM_C))),
 "ldo_dissipation_w_at_80mA": (VIN-VOUT)*I_LOAD,
 "usb_input_power_w_at_80mA": VIN*I_LOAD,
 "regulated_load_power_w_at_80mA": VOUT*I_LOAD,
 "input_fullscale_code_at_3V": round(3.0/VREF*(2**BITS-1)),
}

# RSS input-referred planning estimate: ADC transition/thermal 0.45 LSB RMS,
# op amp integrated + resistor + supply/reference residual estimates. Unverified.
noise_terms_uv={"adc":0.45*lsb*1e6,"opamp":35,"resistor":13,"reference_supply":100}
results["planning_noise_terms_uv_rms"]=noise_terms_uv
results["planning_total_noise_uv_rms"]=sqrt(sum(v*v for v in noise_terms_uv.values()))
results["planning_enob_from_noise"]=log10(VREF/(results["planning_total_noise_uv_rms"]*1e-6*sqrt(12)))/log10(2)

out=Path(__file__).with_name("results.json")
out.write_text(json.dumps(results,indent=2)+"\n")
print(json.dumps(results,indent=2))
