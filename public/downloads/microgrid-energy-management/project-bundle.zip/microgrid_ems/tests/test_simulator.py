import numpy as np
from src.config import Config
from src.data_generation import generate_synthetic_data, load_data
from src.simulator import optimize_dispatch, validate


def test_optimized_power_balance_and_soc(tmp_path):
    p=tmp_path/"data.csv"; generate_synthetic_data(p,days=2,seed=321); cfg=Config()
    r=optimize_dispatch(load_data(p,cfg.solar_kw),cfg); v=validate(r,cfg)
    assert v["passed"]
    assert v["max_power_balance_error_kw"] < 1e-5
    assert r.soc_kwh.min() >= cfg.soc_min*cfg.battery_kwh-1e-6
    assert r.soc_kwh.max() <= cfg.soc_max*cfg.battery_kwh+1e-6
    assert np.minimum(r.battery_charge_kw,r.battery_discharge_kw).max() < 1e-6


def test_outage_grid_is_zero(tmp_path):
    p=tmp_path/"data.csv"; generate_synthetic_data(p,days=2,seed=7); cfg=Config(outage_start=20,outage_duration_h=6)
    r=optimize_dispatch(load_data(p,cfg.solar_kw),cfg)
    assert r.grid_import_kw.iloc[20:26].max() < 1e-7
    assert r.grid_export_kw.iloc[20:26].max() < 1e-7

