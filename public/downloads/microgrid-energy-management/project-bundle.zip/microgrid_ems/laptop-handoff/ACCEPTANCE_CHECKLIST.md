# Final acceptance checklist

- [x] Synthetic input data uses fixed seed 321 and is labeled synthetic.
- [x] Grid-only, solar-only, rule-based storage, and optimized storage cases execute.
- [x] Optimization uses an accessible SciPy HiGHS MILP solver.
- [x] Binary battery mode prevents simultaneous charge and discharge.
- [x] Energy, demand, wear, export-credit, and unserved-energy terms are explicit.
- [x] Battery power, energy, SOC, efficiency, and grid constraints are implemented.
- [x] Optional islanding forces grid import and export to zero.
- [x] Power-balance and SOC-limit automated tests pass.
- [x] Scenario analysis covers battery, PV, tariff, demand charge, initial SOC, and outage duration.
- [x] CSV and XLSX results, plots, notebook, report, portfolio text, and interview Q&A are included.
- [x] README distinguishes simulation from physical hardware testing.
- [ ] Recreate the virtual environment and rerun on the target laptop.
- [ ] Open the XLSX in desktop Excel and confirm native chart appearance.
- [ ] Run the notebook interactively and add personal observations in your own words.
- [ ] If publishing numerical claims, preserve the exact configuration and generated result files.

## Exact laptop commands

```bash
unzip Solar_Battery_Microgrid_EMS_MVP.zip
cd microgrid_ems
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
PYTHONPATH=. python -m src.run_scenarios
PYTHONPATH=. python -m pytest -q tests
```

Windows PowerShell activation: `.venv\Scripts\Activate.ps1`. Then use `$env:PYTHONPATH='.'` before the two Python commands.

