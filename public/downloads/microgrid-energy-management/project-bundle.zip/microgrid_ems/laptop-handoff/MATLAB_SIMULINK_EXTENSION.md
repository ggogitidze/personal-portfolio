# MATLAB and Simulink extension

The Python MVP is complete. MATLAB/Simulink was not required in this environment.

1. Install MATLAB, Simulink, Optimization Toolbox, and Simscape Electrical.
2. Import `data/synthetic_week.csv` with `readtable` and convert timestamps using `datetime`.
3. Recreate the MILP with `optimproblem`, nonnegative `optimvar` arrays, a binary mode array, and `solve` using `intlinprog`.
4. Confirm MATLAB metrics match Python within a stated tolerance.
5. In Simulink, create a discrete model with one-hour sample time first: From Workspace blocks for load/PV/setpoints, a battery SOC integrator implementing the same efficiency equation, grid and curtailment algebra, and Assertion blocks for balance/SOC.
6. Replace the ideal battery with Simscape Electrical Battery and bidirectional converter components only after the supervisory logic agrees with the algebraic model.
7. Reduce the step to 15 minutes and regenerate inputs. Do not interpolate hourly demand peaks and call them measured data.

Exact Python laptop commands are in the main README. A useful MATLAB acceptance test is maximum absolute power-balance residual below `1e-5 kW`, SOC within configured bounds, and no interval with both charge and discharge above tolerance.

