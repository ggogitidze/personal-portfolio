from pathlib import Path
import argparse, json
import pandas as pd
import matplotlib.pyplot as plt
from .config import Config
from .data_generation import generate_synthetic_data, load_data
from .simulator import simulate_grid_only, simulate_solar_only, simulate_rule_based, optimize_dispatch, metrics, validate


ROOT=Path(__file__).resolve().parents[1]

def plot_dispatch(r, out):
    t=r.timestamp
    fig,ax=plt.subplots(3,1,figsize=(12,9),sharex=True)
    ax[0].plot(t,r.load_kw,label="Load",c="#202020"); ax[0].plot(t,r.pv_available_kw,label="PV available",c="#E69F00"); ax[0].set_ylabel("Power (kW)"); ax[0].legend(ncol=2)
    ax[1].plot(t,r.grid_import_kw-r.grid_export_kw,label="Grid (+ import)",c="#0072B2"); ax[1].plot(t,r.battery_power_kw,label="Battery (+ discharge)",c="#009E73"); ax[1].axhline(0,c="gray",lw=.7); ax[1].set_ylabel("Power (kW)"); ax[1].legend(ncol=2)
    ax[2].plot(t,100*r.soc_kwh/r.attrs.get("battery_kwh",160),c="#CC79A7"); ax[2].set_ylabel("SOC (%)"); ax[2].set_xlabel("Time")
    fig.tight_layout(); fig.savefig(out,dpi=180); plt.close(fig)

def run(output_root=ROOT):
    data_path=output_root/"data"/"synthetic_week.csv"; generate_synthetic_data(data_path)
    cfg=Config(); df=load_data(data_path,cfg.solar_kw)
    methods=[simulate_grid_only,simulate_solar_only,simulate_rule_based,optimize_dispatch]
    results=[]; rows=[]; validations=[]
    for f in methods:
        r=f(df,cfg); r.attrs["battery_kwh"]=cfg.battery_kwh; results.append(r); rows.append(metrics(r,cfg)); validations.append({"controller":r.controller.iloc[0],**validate(r,cfg)})
        r.to_csv(output_root/"results"/f"dispatch_{r.controller.iloc[0]}.csv",index=False)
    base=rows[0]["total_cost_usd"]
    for x in rows: x["savings_vs_grid_usd"]=base-x["total_cost_usd"]
    pd.DataFrame(rows).to_csv(output_root/"results"/"controller_comparison.csv",index=False)
    pd.DataFrame(validations).to_csv(output_root/"results"/"validation.csv",index=False)
    plot_dispatch(results[-1],output_root/"figures"/"optimized_dispatch.png")
    m=pd.DataFrame(rows); fig,ax=plt.subplots(figsize=(9,5)); ax.bar(m.controller,m.total_cost_usd,color=["#777777","#E69F00","#009E73","#0072B2"]); ax.set_ylabel("Weekly operating cost (USD)"); ax.tick_params(axis='x',rotation=15); fig.tight_layout(); fig.savefig(output_root/"figures"/"cost_comparison.png",dpi=180); plt.close(fig)
    scenarios=[]
    cases=[]
    for b in [80,160,240]: cases.append(("battery_kwh",b,cfg.with_changes(battery_kwh=b,battery_kw=min(80,b/2))))
    for s in [60,100,140]: cases.append(("solar_kw",s,cfg.with_changes(solar_kw=s)))
    for mult in [.8,1.0,1.25]: cases.append(("tariff_multiplier",mult,cfg))
    for dc in [0,18,30]: cases.append(("demand_charge",dc,cfg.with_changes(demand_charge_per_kw=dc)))
    for soc in [.2,.5,.8]: cases.append(("initial_soc",soc,cfg.with_changes(initial_soc=soc)))
    for dur in [0,2,6,12]: cases.append(("outage_duration_h",dur,cfg.with_changes(outage_start=96 if dur else None,outage_duration_h=dur)))
    for kind,val,cc in cases:
        d=load_data(data_path,cc.solar_kw)
        if kind=="tariff_multiplier": d["buy_price_per_kwh"]*=val
        r=optimize_dispatch(d,cc); mm=metrics(r,cc); scenarios.append({"factor":kind,"value":val,**mm,**validate(r,cc)})
    pd.DataFrame(scenarios).to_csv(output_root/"results"/"sensitivity_analysis.csv",index=False)
    with open(output_root/"results"/"run_metadata.json","w") as f: json.dump({"seed":321,"hours":len(df),"solver":"SciPy milp / HiGHS","data":"synthetic"},f,indent=2)
    return m

if __name__=="__main__":
    for d in ["data","results","figures"]: (ROOT/d).mkdir(parents=True,exist_ok=True)
    run(ROOT)

