from dataclasses import dataclass, replace


@dataclass(frozen=True)
class Config:
    dt_h: float = 1.0
    solar_kw: float = 100.0
    battery_kwh: float = 160.0
    battery_kw: float = 60.0
    soc_min: float = 0.10
    soc_max: float = 0.90
    initial_soc: float = 0.50
    eta_charge: float = 0.95
    eta_discharge: float = 0.95
    export_limit_kw: float = 80.0
    import_limit_kw: float = 250.0
    demand_charge_per_kw: float = 18.0
    unserved_penalty_per_kwh: float = 10_000.0
    battery_wear_per_kwh: float = 0.01
    outage_start: int | None = None
    outage_duration_h: int = 0

    def with_changes(self, **kwargs):
        return replace(self, **kwargs)

