from pathlib import Path
import numpy as np
import pandas as pd


def generate_synthetic_data(path: str | Path, days: int = 7, seed: int = 321) -> pd.DataFrame:
    """Generate reproducible hourly commercial load, PV capacity factor, and TOU tariff."""
    rng = np.random.default_rng(seed)
    n = days * 24
    ts = pd.date_range("2026-07-06", periods=n, freq="h")
    hour = ts.hour.to_numpy()
    weekday = np.asarray((ts.dayofweek < 5).astype(float))
    occupied = ((hour >= 7) & (hour <= 20)).astype(float)
    morning = 20 * np.exp(-0.5 * ((hour - 9) / 2.2) ** 2)
    afternoon = 30 * np.exp(-0.5 * ((hour - 16) / 3.0) ** 2)
    load = 43 + weekday * occupied * 25 + morning + afternoon + rng.normal(0, 2.0, n)
    load = np.clip(load, 30, None)
    daylight = np.sin(np.pi * np.clip((hour - 6) / 14, 0, 1))
    daily_cloud = rng.uniform(0.72, 1.0, days).repeat(24)
    pv_cf = np.clip(daylight * daily_cloud + rng.normal(0, 0.015, n), 0, 1)
    buy = np.where((hour >= 14) & (hour < 21), 0.31, np.where((hour >= 8) & (hour < 14), 0.19, 0.11))
    sell = np.full(n, 0.055)
    df = pd.DataFrame({"timestamp": ts, "load_kw": load.round(4), "pv_capacity_factor": pv_cf.round(6),
                       "buy_price_per_kwh": buy, "sell_price_per_kwh": sell})
    path = Path(path); path.parent.mkdir(parents=True, exist_ok=True)
    df.to_csv(path, index=False)
    return df


def load_data(path: str | Path, solar_kw: float) -> pd.DataFrame:
    df = pd.read_csv(path, parse_dates=["timestamp"])
    df["pv_available_kw"] = df["pv_capacity_factor"] * solar_kw
    return df
