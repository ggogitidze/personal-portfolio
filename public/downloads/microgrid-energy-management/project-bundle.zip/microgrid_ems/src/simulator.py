import numpy as np
import pandas as pd
from scipy.optimize import Bounds, LinearConstraint, milp
from scipy.sparse import lil_matrix
from .config import Config


COLS = ["pv_used_kw", "grid_import_kw", "grid_export_kw", "battery_charge_kw",
        "battery_discharge_kw", "unserved_kw", "soc_kwh"]


def _outage_mask(n, cfg):
    m = np.zeros(n, dtype=bool)
    if cfg.outage_start is not None and cfg.outage_duration_h > 0:
        m[cfg.outage_start:min(n, cfg.outage_start + cfg.outage_duration_h)] = True
    return m


def _frame(df, arrays, cfg, name):
    out = df.copy()
    for k, v in arrays.items(): out[k] = v
    out["battery_power_kw"] = out["battery_discharge_kw"] - out["battery_charge_kw"]
    out["pv_curtailed_kw"] = out["pv_available_kw"] - out["pv_used_kw"]
    out["controller"] = name
    return out


def simulate_grid_only(df, cfg):
    n=len(df); outage=_outage_mask(n,cfg); load=df.load_kw.to_numpy()
    imp=np.where(outage,0,load); unserved=np.where(outage,load,0)
    z=np.zeros(n)
    return _frame(df, dict(pv_used_kw=z,grid_import_kw=imp,grid_export_kw=z,battery_charge_kw=z,
        battery_discharge_kw=z,unserved_kw=unserved,soc_kwh=np.full(n+1,cfg.initial_soc*cfg.battery_kwh)[:-1]),cfg,"grid_only")


def simulate_solar_only(df, cfg):
    n=len(df); outage=_outage_mask(n,cfg); load=df.load_kw.to_numpy(); pv=df.pv_available_kw.to_numpy()
    used=np.minimum(load,pv); residual=load-used; surplus=pv-used
    imp=np.where(outage,0,residual); unserved=np.where(outage,residual,0)
    exp=np.where(outage,0,np.minimum(surplus,cfg.export_limit_kw)); used=used+exp; z=np.zeros(n)
    return _frame(df,dict(pv_used_kw=used,grid_import_kw=imp,grid_export_kw=exp,battery_charge_kw=z,
        battery_discharge_kw=z,unserved_kw=unserved,soc_kwh=np.full(n,cfg.initial_soc*cfg.battery_kwh)),cfg,"solar_only")


def simulate_rule_based(df, cfg):
    n=len(df); outage=_outage_mask(n,cfg); soc=np.zeros(n+1); soc[0]=cfg.initial_soc*cfg.battery_kwh
    arr={k:np.zeros(n) for k in COLS if k!="soc_kwh"}; lo=cfg.soc_min*cfg.battery_kwh; hi=cfg.soc_max*cfg.battery_kwh
    for t in range(n):
        load=float(df.load_kw.iloc[t]); pv=float(df.pv_available_kw.iloc[t]); direct=min(load,pv)
        arr["pv_used_kw"][t]=direct; deficit=load-direct; surplus=pv-direct
        if surplus>0:
            ch=min(surplus,cfg.battery_kw,(hi-soc[t])/(cfg.eta_charge*cfg.dt_h)); arr["battery_charge_kw"][t]=ch
            surplus-=ch; arr["pv_used_kw"][t]+=ch
            if not outage[t]:
                arr["grid_export_kw"][t]=min(surplus,cfg.export_limit_kw)
                arr["pv_used_kw"][t]+=arr["grid_export_kw"][t]
        if deficit>0:
            dis=min(deficit,cfg.battery_kw,(soc[t]-lo)*cfg.eta_discharge/cfg.dt_h); arr["battery_discharge_kw"][t]=dis; deficit-=dis
            if outage[t]: arr["unserved_kw"][t]=deficit
            else: arr["grid_import_kw"][t]=min(deficit,cfg.import_limit_kw); arr["unserved_kw"][t]=max(0,deficit-cfg.import_limit_kw)
        soc[t+1]=soc[t]+cfg.eta_charge*arr["battery_charge_kw"][t]*cfg.dt_h-arr["battery_discharge_kw"][t]*cfg.dt_h/cfg.eta_discharge
    arr["soc_kwh"]=soc[:-1]
    return _frame(df,arr,cfg,"rule_based")


def optimize_dispatch(df, cfg):
    """MILP using SciPy/HiGHS. Binary mode makes charge and discharge mutually exclusive."""
    n=len(df); outage=_outage_mask(n,cfg); dt=cfg.dt_h
    # blocks: pv, import, export, charge, discharge, unserved, soc(n+1), mode(n), peak(1)
    starts=np.cumsum([0,n,n,n,n,n,n,n+1,n]); pv_i,gi_i,ge_i,ch_i,dis_i,us_i,soc_i,mode_i,peak_i=starts
    nv=peak_i+1; c=np.zeros(nv)
    c[gi_i:gi_i+n]=df.buy_price_per_kwh*dt; c[ge_i:ge_i+n]=-df.sell_price_per_kwh*dt
    c[ch_i:ch_i+n]=cfg.battery_wear_per_kwh*dt; c[dis_i:dis_i+n]=cfg.battery_wear_per_kwh*dt
    c[us_i:us_i+n]=cfg.unserved_penalty_per_kwh*dt; c[peak_i]=cfg.demand_charge_per_kw
    lb=np.zeros(nv); ub=np.full(nv,np.inf)
    ub[pv_i:pv_i+n]=df.pv_available_kw; ub[gi_i:gi_i+n]=cfg.import_limit_kw; ub[ge_i:ge_i+n]=cfg.export_limit_kw
    ub[ch_i:ch_i+n]=cfg.battery_kw; ub[dis_i:dis_i+n]=cfg.battery_kw; ub[us_i:us_i+n]=df.load_kw
    lb[soc_i:soc_i+n+1]=cfg.soc_min*cfg.battery_kwh; ub[soc_i:soc_i+n+1]=cfg.soc_max*cfg.battery_kwh
    ub[mode_i:mode_i+n]=1
    ub[gi_i:gi_i+n][outage]=0; ub[ge_i:ge_i+n][outage]=0
    rows=4*n+2; A=lil_matrix((rows,nv)); lower=np.full(rows,-np.inf); upper=np.full(rows,np.inf); r=0
    for t in range(n):
        # pv + import + discharge + unserved - export - charge = load
        for idx,val in [(pv_i+t,1),(gi_i+t,1),(dis_i+t,1),(us_i+t,1),(ge_i+t,-1),(ch_i+t,-1)]: A[r,idx]=val
        lower[r]=upper[r]=df.load_kw.iloc[t]; r+=1
        # soc[t+1]-soc[t]-eta_c ch dt + dis dt/eta_d = 0
        for idx,val in [(soc_i+t+1,1),(soc_i+t,-1),(ch_i+t,-cfg.eta_charge*dt),(dis_i+t,dt/cfg.eta_discharge)]: A[r,idx]=val
        lower[r]=upper[r]=0; r+=1
        # charge <= P * mode; discharge <= P*(1-mode)
        A[r,ch_i+t]=1; A[r,mode_i+t]=-cfg.battery_kw; upper[r]=0; r+=1
        A[r,dis_i+t]=1; A[r,mode_i+t]=cfg.battery_kw; upper[r]=cfg.battery_kw; r+=1
    A[r,soc_i]=1; lower[r]=upper[r]=cfg.initial_soc*cfg.battery_kwh; r+=1
    A[r,soc_i+n]=1; lower[r]=cfg.initial_soc*cfg.battery_kwh; r+=1
    # grid import <= peak, appended separately
    Ap=lil_matrix((n,nv))
    for t in range(n): Ap[t,gi_i+t]=1; Ap[t,peak_i]=-1
    constraints=[LinearConstraint(A.tocsr(),lower,upper),LinearConstraint(Ap.tocsr(),-np.inf,0)]
    integrality=np.zeros(nv,int); integrality[mode_i:mode_i+n]=1
    res=milp(c,integrality=integrality,bounds=Bounds(lb,ub),constraints=constraints,options={"time_limit":120,"mip_rel_gap":1e-7})
    if not res.success: raise RuntimeError(f"Optimization failed: {res.message}")
    x=res.x; arrays={"pv_used_kw":x[pv_i:pv_i+n],"grid_import_kw":x[gi_i:gi_i+n],"grid_export_kw":x[ge_i:ge_i+n],
        "battery_charge_kw":x[ch_i:ch_i+n],"battery_discharge_kw":x[dis_i:dis_i+n],"unserved_kw":x[us_i:us_i+n],"soc_kwh":x[soc_i:soc_i+n]}
    out=_frame(df,arrays,cfg,"optimized"); out.attrs.update(objective=res.fun,solver="SciPy milp / HiGHS",mip_gap=getattr(res,"mip_gap",None))
    return out


def validate(result, cfg, tol=1e-5):
    bal=result.pv_used_kw+result.grid_import_kw+result.battery_discharge_kw+result.unserved_kw-result.load_kw-result.battery_charge_kw-result.grid_export_kw
    soc=result.soc_kwh.to_numpy(); next_soc=np.r_[soc[1:], soc[-1]+cfg.eta_charge*result.battery_charge_kw.iloc[-1]*cfg.dt_h-result.battery_discharge_kw.iloc[-1]*cfg.dt_h/cfg.eta_discharge]
    dyn=next_soc-soc-cfg.eta_charge*result.battery_charge_kw.to_numpy()*cfg.dt_h+result.battery_discharge_kw.to_numpy()*cfg.dt_h/cfg.eta_discharge
    simultaneous=np.minimum(result.battery_charge_kw,result.battery_discharge_kw)
    return {"max_power_balance_error_kw":float(np.max(np.abs(bal))),"max_soc_dynamics_error_kwh":float(np.max(np.abs(dyn))),
            "soc_min_kwh":float(soc.min()),"soc_max_kwh":float(soc.max()),"max_simultaneous_charge_discharge_kw":float(simultaneous.max()),
            "passed":bool(np.max(np.abs(bal))<=tol and np.max(np.abs(dyn))<=tol and soc.min()>=cfg.soc_min*cfg.battery_kwh-tol and soc.max()<=cfg.soc_max*cfg.battery_kwh+tol)}


def metrics(result, cfg):
    dt=cfg.dt_h; buy=result.buy_price_per_kwh; sell=result.sell_price_per_kwh
    energy_cost=float(((result.grid_import_kw*buy-result.grid_export_kw*sell)*dt).sum())
    demand=float(result.grid_import_kw.max()*cfg.demand_charge_per_kw)
    wear=float(((result.battery_charge_kw+result.battery_discharge_kw)*dt*cfg.battery_wear_per_kwh).sum())
    pv_available=float((result.pv_available_kw*dt).sum()); pv_used=float((result.pv_used_kw*dt).sum())
    return {"controller":result.controller.iloc[0],"import_kwh":float(result.grid_import_kw.sum()*dt),"export_kwh":float(result.grid_export_kw.sum()*dt),
      "peak_import_kw":float(result.grid_import_kw.max()),"pv_curtailed_kwh":float(result.pv_curtailed_kw.sum()*dt),
      "battery_throughput_kwh":float((result.battery_charge_kw.add(result.battery_discharge_kw).sum()*dt)/2),
      "energy_cost_usd":energy_cost,"demand_charge_usd":demand,"battery_wear_usd":wear,"total_cost_usd":energy_cost+demand+wear,
      "renewable_utilization_pct":100*pv_used/pv_available if pv_available else 0,"unserved_energy_kwh":float(result.unserved_kw.sum()*dt)}
