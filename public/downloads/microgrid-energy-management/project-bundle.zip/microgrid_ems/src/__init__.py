"""Solar and battery microgrid energy-management simulator."""

