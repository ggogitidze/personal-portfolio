# Assumptions and conventions

- Resolution: hourly; power is kW, energy is kWh, prices are USD/kWh, demand charge is USD/kW for the simulated billing window.
- Synthetic dataset: a seven-day commercial profile generated with NumPy seed 321. It is not measured utility or customer data and is released with this project under MIT terms.
- Positive battery power in outputs means discharge; negative means charge. Internal charge and discharge variables are individually nonnegative.
- Grid import and export are individually nonnegative. Net grid power is import minus export.
- SOC is stored energy at the start of each interval. Charge and discharge efficiencies are each 95%.
- PV may serve load, charge the battery, or be exported. Remaining PV is curtailed.
- The optimizer has perfect foresight over the study horizon. This is useful for benchmarking, not a claim about a deployed real-time controller.
- A binary battery-mode variable prevents charging and discharging in the same interval. Export compensation below retail price also removes the usual incentive for grid import/export arbitrage.
- The optimized case requires final SOC to be at least initial SOC, preventing artificial savings from consuming stored energy without replacement.
- During an outage, import and export limits are zero. Unserved load is allowed with a large penalty so every scenario remains mathematically feasible.
- Costs are operating-cost estimates only. They exclude capital cost, degradation physics beyond a throughput proxy, taxes, fixed charges, and interconnection costs.

