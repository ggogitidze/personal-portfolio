# Technical interview questions and model answers

1. **Why use separate charge and discharge variables?** They keep the SOC equation and equipment limits linear. A binary mode couples them so only one can be positive in an interval.
2. **Why require final SOC at least equal initial SOC?** Without a terminal condition, the optimizer can lower cost by consuming stored energy that it never replenishes, biasing comparisons.
3. **Where do efficiencies appear?** Charging adds `eta_charge * P_charge * dt` to stored energy. Delivering AC discharge requires `P_discharge * dt / eta_discharge` from stored energy.
4. **What does the demand-charge variable do?** It is constrained above every import value. Because its objective coefficient is positive, the optimizer sets it to the maximum import.
5. **Why is unserved load allowed?** It preserves feasibility during severe islanding. A high value-of-lost-load penalty makes shedding the last resort and quantifies resilience shortfall.
6. **Does the model prevent grid import and export simultaneously?** The retail buy price exceeds the export credit, so simultaneous flows increase cost and are dominated. A production model could add another binary mode if tariffs create unusual arbitrage incentives.
7. **What is renewable utilization?** PV used for load, charging, or export divided by available PV. It measures curtailment avoidance, not the share of load served by renewables.
8. **Why can optimized throughput exceed rule-based throughput?** The optimizer may charge off-peak and discharge during on-peak or peak-demand intervals. The wear coefficient limits but does not fully model degradation.
9. **What makes the optimizer noncausal?** It knows all future load, PV, prices, and outages. A deployable EMS would use rolling forecasts and repeatedly solve a shorter horizon.
10. **What would you validate before deployment?** Meter sign conventions, tariff rules, inverter limits, SOC calibration, forecast accuracy, fail-safe behavior, communications, interconnection requirements, protection coordination, and hardware-in-the-loop response.
11. **Why hourly resolution?** It keeps the MVP clear and fast. Utility demand billing commonly needs 15-minute intervals, which is an important next step.
12. **How would you add network physics?** Couple dispatch to linearized or nonlinear power flow using pandapower/OpenDSS, including voltage, line loading, reactive power, and inverter kVA limits.

