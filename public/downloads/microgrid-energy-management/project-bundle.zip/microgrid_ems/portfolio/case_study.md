# Solar and Battery Microgrid EMS Case Study

## Short portfolio summary

Built a Python microgrid energy-management simulator that routes solar, battery, and grid power under time-of-use energy prices, demand charges, equipment limits, and optional outages. Compared grid-only, solar-only, rule-based storage, and mixed-integer optimized storage, then verified hourly power balance and state-of-charge constraints with automated tests.

## Engineering problem

Commercial sites with PV and batteries need an operating policy that balances energy cost, peak demand, renewable use, battery cycling, and outage resilience. A simple controller can consume solar locally but may miss opportunities to pre-charge before expensive periods or shave the monthly peak.

## What I built

I created a reproducible hourly simulation with synthetic commercial load, PV availability, and time-of-use rates. The rule-based EMS prioritizes PV self-consumption. The optimization EMS uses a mixed-integer linear program through SciPy and HiGHS. It chooses PV use, grid import/export, battery charge/discharge, and load shedding while enforcing ratings, SOC dynamics, outage isolation, and a terminal-energy condition.

## Validation and results

The program checks the AC-bus power balance, SOC recursion, SOC bounds, and mutually exclusive battery modes for every interval. The generated comparison table and figures report imported/exported energy, peak grid demand, curtailment, battery throughput, operating cost, savings, renewable utilization, and outage unserved energy. Numerical results shown on the portfolio page should be copied from the generated `controller_comparison.csv`; they are simulated estimates, not field measurements.

## Limitations

This is a single-bus operational model with hourly data and perfect forecasts. It does not claim protection, transient, voltage, power-quality, interconnection, or hardware validation. A production design would use site data, 15-minute billing intervals, forecast uncertainty, inverter kVA constraints, detailed degradation, and rolling-horizon control.

## Three truthful resume bullets

- Built a Python solar-plus-storage microgrid simulator comparing grid-only, PV-only, rule-based, and mixed-integer optimized dispatch under time-of-use energy and demand charges.
- Formulated hourly power balance, battery SOC dynamics, efficiency losses, equipment limits, outage isolation, and binary charge/discharge modes using SciPy's HiGHS MILP solver.
- Automated scenario analysis and engineering validation, producing interval-level CSVs, an Excel results workbook, plots, and tests for balance residuals and SOC limits.

## 30-second recruiter explanation

I built a software model of a commercial solar-and-battery microgrid. It compares a simple self-consumption controller with an optimizer that schedules the battery around energy prices and peak-demand charges, while respecting power, energy, efficiency, and outage constraints. I validated every hourly power balance and SOC transition, then packaged sensitivity studies, plots, tests, and an Excel report. It is a simulation project, but it demonstrates the same modeling, controls, and optimization reasoning used in utility and energy-automation work.

