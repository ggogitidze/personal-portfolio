from pathlib import Path
import pandas as pd
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch
from docx import Document
from docx.shared import Inches, Pt, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.section import WD_SECTION
from docx.enum.table import WD_TABLE_ALIGNMENT, WD_CELL_VERTICAL_ALIGNMENT
from reportlab.lib.pagesizes import letter
from reportlab.lib import colors
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.enums import TA_CENTER
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, Image, PageBreak

ROOT=Path(__file__).resolve().parents[1]

def architecture():
    fig,ax=plt.subplots(figsize=(12,5)); ax.set_xlim(0,12); ax.set_ylim(0,5); ax.axis('off')
    boxes={"PV array\n100 kW":(0.5,3.2,"#F6C85F"),"Battery\n160 kWh / 60 kW":(0.5,.8,"#6F4E9C"),
           "AC bus":(4.5,2.0,"#4C78A8"),"Facility load":(8.2,3.2,"#5F9E6E"),"Utility grid":(8.2,.8,"#9B9B9B"),
           "EMS\nrule based or MILP":(4.25,.15,"#E45756")}
    for label,(x,y,c) in boxes.items():
        p=FancyBboxPatch((x,y),2.6,1,boxstyle="round,pad=0.08",fc=c,ec="white",lw=2); ax.add_patch(p); ax.text(x+1.3,y+.5,label,ha='center',va='center',color='white',weight='bold',fontsize=11)
    def arrow(a,b,bidir=False,style='-'):
        ax.add_patch(FancyArrowPatch(a,b,arrowstyle='<->' if bidir else '->',mutation_scale=16,lw=2,color='#333333',linestyle=style))
    arrow((3.1,3.7),(4.5,2.7)); arrow((3.1,1.3),(4.5,2.3),True); arrow((7.1,2.6),(8.2,3.5)); arrow((7.1,2.2),(8.2,1.3),True)
    arrow((5.55,1.15),(5.55,2.0),False,'--'); arrow((6.4,.65),(8.2,1.15),False,'--')
    ax.text(6,4.65,"Solar and Battery Microgrid Architecture",ha='center',fontsize=17,weight='bold')
    ax.text(6,4.25,"Single-bus operational simulation; arrows show permitted real-power flow",ha='center',fontsize=10,color='#444444')
    fig.tight_layout(); out=ROOT/'portfolio'/'architecture.png'; fig.savefig(out,dpi=200,bbox_inches='tight'); plt.close(fig)
    return out

def set_cell_shading(cell, fill):
    from docx.oxml import OxmlElement
    from docx.oxml.ns import qn
    shd=OxmlElement('w:shd'); shd.set(qn('w:fill'),fill); cell._tc.get_or_add_tcPr().append(shd)

def build_docx(arch):
    comp=pd.read_csv(ROOT/'results'/'controller_comparison.csv'); val=pd.read_csv(ROOT/'results'/'validation.csv')
    d=Document(); sec=d.sections[0]; sec.top_margin=Inches(.65); sec.bottom_margin=Inches(.65); sec.left_margin=Inches(.75); sec.right_margin=Inches(.75)
    styles=d.styles; styles['Normal'].font.name='Arial'; styles['Normal'].font.size=Pt(10.5)
    for name,size in [('Title',24),('Heading 1',16),('Heading 2',12)]:
        styles[name].font.name='Arial'; styles[name].font.size=Pt(size); styles[name].font.color.rgb=RGBColor(0,0,0)
    p=d.add_paragraph(style='Title'); p.alignment=WD_ALIGN_PARAGRAPH.CENTER; p.add_run('Solar and Battery Microgrid Energy Management Simulator')
    p=d.add_paragraph(); p.alignment=WD_ALIGN_PARAGRAPH.CENTER; p.add_run('Technical report | Giorgi Gogitidze | September 2026').italic=True
    d.add_picture(str(arch),width=Inches(7.0)); d.paragraphs[-1].alignment=WD_ALIGN_PARAGRAPH.CENTER
    d.add_paragraph('This report documents a reproducible software simulation of a commercial microgrid. The project compares four control strategies and shows that an optimization-based EMS can coordinate solar, storage, and grid exchange while satisfying power and energy constraints. Results are simulated, not measured or hardware-tested.')
    sections=[
      ('1 Scope and physical model',["The model represents a single AC bus connected to a facility load, solar PV, a bidirectional battery inverter, and the utility grid. Hourly average power is converted to energy using a one-hour interval. An optional outage sets grid import and export to zero.","The seven-day load, solar capacity factor, and tariff are synthetic. NumPy seed 321 makes the dataset reproducible. Units are kW, kWh, USD/kWh, and USD/kW."]),
      ('2 Control methods',["Grid-only operation supplies the load from the utility. Solar-only operation uses PV for load and exports allowable surplus. The rule-based battery consumes PV locally, charges on surplus, and discharges on deficits. The optimized EMS solves a mixed-integer linear program using SciPy and the open-source HiGHS solver.","The MILP minimizes imported-energy cost minus export credit, demand charge, a battery-throughput wear proxy, and a high unserved-energy penalty. It enforces bus balance, SOC recursion, power/energy ratings, PV and grid limits, outage isolation, and final SOC at least equal to initial SOC."]),
      ('3 Equations and constraints',["Power balance: PV used + grid import + battery discharge + unserved load = facility load + battery charge + grid export.","SOC dynamics: SOC[t+1] = SOC[t] + eta_charge x charge x dt - discharge x dt / eta_discharge. SOC remains between 10% and 90%. A binary mode enforces charge <= Pmax x mode and discharge <= Pmax x (1 - mode), preventing simultaneous operation."]),
      ('4 Results',["The baseline run covers 168 hourly intervals. The optimized case reduced simulated weekly operating cost relative to grid-only operation while satisfying all modeled limits. Because the horizon is one week, the demand-charge term is a scenario cost rather than an exact customer bill."]),
      ('5 Validation',["Every controller passed the final AC-bus balance validation. The optimized dispatch also passed SOC recursion and SOC-bound checks and had zero simultaneous charge/discharge within numerical tolerance. Automated tests repeat these checks and verify zero grid exchange during an outage."]),
      ('6 Sensitivity and limitations',["Sensitivity cases vary battery energy, PV rating, tariff level, demand-charge rate, initial SOC, and outage duration. The model uses perfect forecasts, fixed efficiency, a linear cycling proxy, and a single bus. It omits voltage, reactive power, protection, converter dynamics, detailed degradation, and forecast uncertainty."]),
      ('7 Recommended extensions',["Use 15-minute measured load and irradiance, implement rolling-horizon model-predictive control, add forecast scenarios and battery degradation, and connect dispatch to OpenDSS or pandapower for feeder voltage and thermal limits. MATLAB/Simulink steps are included in the laptop handoff."])]
    for h,paras in sections:
        d.add_heading(h,level=1)
        for x in paras: d.add_paragraph(x)
        if h.startswith('4'):
            table=d.add_table(rows=1,cols=6); table.alignment=WD_TABLE_ALIGNMENT.CENTER; table.style='Table Grid'
            headers=['Controller','Import kWh','Peak kW','Cost USD','Savings USD','Renewable use']
            for i,x in enumerate(headers): table.rows[0].cells[i].text=x; set_cell_shading(table.rows[0].cells[i],'1F4E78'); table.rows[0].cells[i].paragraphs[0].runs[0].font.color.rgb=RGBColor(255,255,255)
            for _,r in comp.iterrows():
                cells=table.add_row().cells; vals=[r.controller,f'{r.import_kwh:,.1f}',f'{r.peak_import_kw:,.1f}',f'${r.total_cost_usd:,.0f}',f'${r.savings_vs_grid_usd:,.0f}',f'{r.renewable_utilization_pct:.1f}%']
                for i,x in enumerate(vals): cells[i].text=x; cells[i].vertical_alignment=WD_CELL_VERTICAL_ALIGNMENT.CENTER
            d.add_picture(str(ROOT/'figures'/'cost_comparison.png'),width=Inches(6.5)); d.paragraphs[-1].alignment=WD_ALIGN_PARAGRAPH.CENTER
        if h.startswith('5'):
            d.add_picture(str(ROOT/'figures'/'optimized_dispatch.png'),width=Inches(6.8)); d.paragraphs[-1].alignment=WD_ALIGN_PARAGRAPH.CENTER
    out=ROOT/'report'/'technical_report.docx'; d.save(out); return out

def build_pdf(arch):
    pdfmetrics.registerFont(TTFont('DejaVu','/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf'))
    pdfmetrics.registerFont(TTFont('DejaVu-Bold','/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf'))
    comp=pd.read_csv(ROOT/'results'/'controller_comparison.csv')
    out=ROOT/'report'/'technical_report.pdf'; styles=getSampleStyleSheet()
    for key in ['Normal','BodyText','Heading1','Heading2','Title']: styles[key].fontName='DejaVu'
    styles['Heading1'].fontName='DejaVu-Bold'; styles.add(ParagraphStyle(name='CenterTitle',parent=styles['Title'],alignment=TA_CENTER,fontName='DejaVu-Bold',fontSize=20,spaceAfter=12))
    doc=SimpleDocTemplate(str(out),pagesize=letter,rightMargin=48,leftMargin=48,topMargin=48,bottomMargin=48)
    story=[Paragraph('Solar and Battery Microgrid Energy Management Simulator',styles['CenterTitle']),Paragraph('Technical report | Giorgi Gogitidze | September 2026',styles['Normal']),Spacer(1,12),Image(str(arch),width=500,height=208),Spacer(1,12),Paragraph('This report documents a reproducible software simulation, not physical hardware testing. It compares grid-only, solar-only, rule-based storage, and mixed-integer optimized storage over a synthetic seven-day dataset.',styles['BodyText'])]
    content=[('Model and formulation','A single AC bus connects facility load, PV, battery, and utility. The hourly balance is PV used + import + discharge + unserved = load + charge + export. Battery energy follows SOC[t+1] = SOC[t] + eta_c charge dt - discharge dt / eta_d. A binary mode prevents simultaneous charge and discharge.'),('Control and optimization','The rule controller prioritizes PV self-consumption. The MILP minimizes energy cost, demand charge, throughput wear, and unserved-energy penalty subject to equipment, SOC, terminal-energy, grid, and outage constraints. SciPy uses the open-source HiGHS solver.'),('Baseline results','The optimized dispatch achieved the lowest modeled weekly operating cost and reduced peak import. These are simulation results for the supplied synthetic assumptions; they are not a utility bill or field guarantee.')]
    for h,b in content: story += [Spacer(1,12),Paragraph(h,styles['Heading1']),Paragraph(b,styles['BodyText'])]
    data=[['Controller','Import kWh','Peak kW','Total cost','Savings']]+[[r.controller,f'{r.import_kwh:,.1f}',f'{r.peak_import_kw:,.1f}',f'${r.total_cost_usd:,.0f}',f'${r.savings_vs_grid_usd:,.0f}'] for _,r in comp.iterrows()]
    t=Table(data,colWidths=[110,80,70,80,80]); t.setStyle(TableStyle([('BACKGROUND',(0,0),(-1,0),colors.HexColor('#1F4E78')),('TEXTCOLOR',(0,0),(-1,0),colors.white),('GRID',(0,0),(-1,-1),.5,colors.HexColor('#D9D9D9')),('ALIGN',(1,1),(-1,-1),'RIGHT'),('FONTNAME',(0,0),(-1,0),'DejaVu-Bold'),('FONTNAME',(0,1),(-1,-1),'DejaVu'),('ROWBACKGROUNDS',(0,1),(-1,-1),[colors.white,colors.HexColor('#EEF4F8')]),('VALIGN',(0,0),(-1,-1),'MIDDLE')]))
    story += [Spacer(1,12),t,Spacer(1,12),Image(str(ROOT/'figures'/'cost_comparison.png'),width=450,height=250),PageBreak(),Paragraph('Optimized dispatch',styles['Heading1']),Image(str(ROOT/'figures'/'optimized_dispatch.png'),width=500,height=375),Paragraph('Validation',styles['Heading1']),Paragraph('All four final controller outputs pass interval-level power balance. The optimized controller passes SOC recursion and limits and has no simultaneous charge/discharge within numerical tolerance. Two automated tests also verify outage isolation.',styles['BodyText']),Paragraph('Limitations and next steps',styles['Heading1']),Paragraph('The model uses perfect forecasts, fixed efficiency, hourly data, and one bus. Future work should add 15-minute measured data, rolling-horizon control, forecast uncertainty, detailed degradation, inverter kVA constraints, and feeder power flow.',styles['BodyText'])]
    doc.build(story); return out

if __name__=='__main__':
    a=architecture(); print(build_docx(a)); print(build_pdf(a))
