import fs from "node:fs/promises";
import { Workbook, SpreadsheetFile } from "@oai/artifact-tool";

const root = process.env.MICROGRID_ROOT || new URL("../", import.meta.url).pathname;
const parse = (s) => {
  const lines=s.trim().split(/\r?\n/); const headers=lines[0].split(',');
  return [headers,...lines.slice(1).map(line=>line.split(',').map((v,i)=>i===0?v:(v===''?null:(Number.isFinite(Number(v))?Number(v):v))))];
};
const wb=Workbook.create(); const summary=wb.worksheets.add("Summary"); const sens=wb.worksheets.add("Sensitivity"); const valid=wb.worksheets.add("Validation");
for (const sh of [summary,sens,valid]) {sh.showGridLines=false; sh.getRange("A1:Z300").format.font={name:"Arial",size:10};}
const comp=parse(await fs.readFile(root+"results/controller_comparison.csv","utf8"));
summary.getRange("A2").values=[["Solar and Battery Microgrid EMS Results"]]; summary.getRange("A2").format.font={name:"Arial",size:16,bold:true,color:"#000000"};
summary.getRange("A3").values=[["Synthetic seven-day simulation; costs are modeled estimates, not field measurements."]]; summary.getRange("A3").format.font={name:"Arial",size:10,italic:true,color:"#555555"};
summary.getRange("A5").write(comp); const last=5+comp.length-1; summary.tables.add(`A5:N${last}`,true,"ControllerComparison");
summary.getRange("A5:N5").format={fill:"#1F4E78",font:{name:"Arial",size:10,bold:true,color:"#FFFFFF"},wrapText:true,verticalAlignment:"center",horizontalAlignment:"center"};
summary.getRange(`B6:F${last}`).format.numberFormat="#,##0.0"; summary.getRange(`G6:K${last}`).format.numberFormat="$#,##0.00"; summary.getRange(`L6:L${last}`).format.numberFormat="0.0%";
// CSV stores percentage as 0-100; correct display without percent scaling.
summary.getRange(`L6:L${last}`).format.numberFormat='0.0"%"'; summary.getRange(`M6:M${last}`).format.numberFormat="#,##0.0"; summary.getRange(`N6:N${last}`).format.numberFormat="$#,##0.00";
summary.getRange("A5:N9").format.borders={preset:"all",style:"thin",color:"#D9D9D9"}; summary.freezePanes.freezeRows(5);
const cost=summary.charts.add("column",[summary.getRange(`A5:A${last}`),summary.getRange(`J5:J${last}`)]); cost.title="Weekly operating cost (USD)"; cost.hasLegend=false; cost.setPosition("A12","G29");
const peak=summary.charts.add("column",[summary.getRange(`A5:A${last}`),summary.getRange(`D5:D${last}`)]); peak.title="Peak grid import (kW)"; peak.hasLegend=false; peak.setPosition("H12","N29");
const ss=parse(await fs.readFile(root+"results/sensitivity_analysis.csv","utf8")); sens.getRange("A2").values=[["Sensitivity analysis"]]; sens.getRange("A2").format.font={name:"Arial",size:16,bold:true}; sens.getRange("A4").write(ss); const sl=4+ss.length-1; sens.tables.add(`A4:${String.fromCharCode(64+Math.min(ss[0].length,26))}${sl}`,true,"SensitivityTable"); sens.getRange(`A4:Z4`).format={fill:"#4472C4",font:{name:"Arial",bold:true,color:"#FFFFFF"},wrapText:true}; sens.freezePanes.freezeRows(4);
const vv=parse(await fs.readFile(root+"results/validation.csv","utf8")); valid.getRange("A2").values=[["Engineering validation"]]; valid.getRange("A2").format.font={name:"Arial",size:16,bold:true}; valid.getRange("A3").values=[["Power balance and SOC dynamics are checked at every interval; numerical residuals reflect solver precision."]]; valid.getRange("A5").write(vv); const vl=5+vv.length-1; valid.tables.add(`A5:G${vl}`,true,"ValidationTable"); valid.getRange("A5:G5").format={fill:"#548235",font:{name:"Arial",bold:true,color:"#FFFFFF"},wrapText:true}; valid.getRange(`B6:F${vl}`).format.numberFormat="0.000000E+00";
for (const sh of [summary,sens,valid]) { const used=sh.getUsedRange(); used.format.verticalAlignment="center"; used.format.autofitColumns(); used.format.autofitRows(); }
summary.getRange("A:N").format.columnWidth=14; summary.getRange("A:A").format.columnWidth=18; sens.getRange("A:Z").format.columnWidth=15; valid.getRange("A:G").format.columnWidth=21;
wb.recalculate();
const out=root+"results/microgrid_results.xlsx"; const x=await SpreadsheetFile.exportXlsx(wb); await x.save(out);
const check=await wb.inspect({kind:"table",range:"Summary!A2:N9",include:"values,formulas",tableMaxRows:10,tableMaxCols:14}); console.log(check.ndjson);
const errors=await wb.inspect({kind:"match",searchTerm:"#REF!|#DIV/0!|#VALUE!|#NAME\\?|#N/A|#NUM!|#NULL!|#SPILL!|#CALC!",options:{useRegex:true,maxResults:100},summary:"formula error scan"}); console.log(errors.ndjson);
for (const name of ["Summary","Sensitivity","Validation"]) { const img=await wb.render({sheetName:name,autoCrop:"all",scale:1,format:"png"}); await fs.writeFile(root+`results/${name.toLowerCase()}_preview.png`,new Uint8Array(await img.arrayBuffer())); }
