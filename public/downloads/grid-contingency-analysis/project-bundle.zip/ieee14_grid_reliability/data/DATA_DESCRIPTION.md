# Data description

## Source model

The project loads `pandapower.networks.case14()`. Pandapower's case is a conversion of the MATPOWER `case14` data, which in turn was converted from the IEEE Common Data Format archive. The model is a 100 MVA-base transmission test case with 14 buses, 15 lines, five transformers, 11 loads, four PV generators, and one external-grid/slack source.

The source data is loaded from the installed package at run time; no reference-repository code or copied case file is embedded here.

## Bus data

Each bus has a nominal voltage, voltage magnitude limits, and solved voltage magnitude/angle. The project assigns the power-flow categories from active controls:

- **Slack:** voltage magnitude and angle are specified; active and reactive output close the system balance.
- **PV:** active power and voltage magnitude are specified; the solver finds reactive power and voltage angle.
- **PQ:** active and reactive net demand are specified; the solver finds voltage magnitude and angle.

## Branch data and the thermal-rating limitation

The canonical MATPOWER IEEE 14-bus case sets every branch `rateA` to zero, meaning the archive did not supply continuous MVA ratings. Pandapower converts those missing limits to effectively non-binding values. Treating the resulting native loading percentages as real ratings would be misleading.

For this portfolio stress test only, the code creates a rating for each branch after the validated base solve:

`study_rating_MVA = ceil_to_5_MVA(max(40 MVA, 1.25 x base_case_terminal_MVA))`

The terminal MVA is the larger magnitude at the two branch ends. This gives every branch at least 25% base-case headroom, subject to a 40 MVA floor, and makes the assumption easy to replace. These are **synthetic scenario ratings**, not IEEE, manufacturer, or utility ratings.

## Outputs

- `base_case_buses.csv`: solved voltage, angle, injections, bus type, limits, and breach amounts.
- `base_case_generators.csv`: slack and PV generator P/Q outputs and voltage setpoints.
- `base_case_branches.csv`: terminal P/Q/S, losses, synthetic rating, and loading.
- `contingency_results.csv`: one ranked record for each of the 20 branch outages.
- `contingency_bus_results.csv`: bus-level results for every connected, converged outage.
- `contingency_branch_results.csv`: monitored-branch results for every connected, converged outage.
- `ptdf_matrix.csv`, `lodf_matrix.csv`, `dc_lodf_screening.csv`: lossless DC screening data.
- `dc_ac_comparison.csv`: branch-level DC estimate versus full AC result for selected outages.

## Primary references

- MATPOWER case14: https://matpower.org/docs/ref/matpower5.0/case14.html
- MATPOWER PTDF documentation: https://matpower.org/documentation/ref-manual/legacy/functions/makePTDF.html
- MATPOWER LODF documentation: https://matpower.org/documentation/ref-manual/legacy/functions/makeLODF.html
- Pandapower documentation: https://pandapower.readthedocs.io/

