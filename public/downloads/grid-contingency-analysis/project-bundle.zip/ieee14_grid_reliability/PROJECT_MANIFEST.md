# Deliverable manifest

## Start here

- `README.md` - teaching document, formulas, assumptions, results, run instructions, limitations.
- `notebooks/01_ieee14_contingency_demo.ipynb` - executed guided demonstration with tables and figures.
- `dashboard/grid_risk_dashboard.html` - self-contained interactive dashboard.
- `docs/IEEE14_Technical_Report.pdf` - publication-ready two-page brief.
- `portfolio/index.html` - static personal-portfolio page package.

## Executable project

- `src/gridrisk/config.py` - all thresholds, weights, tolerances, and reproducibility settings.
- `src/gridrisk/network.py` - IEEE case loader, bus types, branch catalog, synthetic study ratings.
- `src/gridrisk/powerflow.py` - AC solve, result extraction, losses, balance, two-solver validation.
- `src/gridrisk/contingency.py` - topology/islanding checks and complete N-1 engine.
- `src/gridrisk/severity.py` - explicit score components.
- `src/gridrisk/dc_screening.py` - independent PTDF/LODF formulation and AC comparison.
- `src/gridrisk/visualization.py` - publication-quality static figures and network diagrams.
- `src/gridrisk/reporting.py` - dashboard and static portfolio-page generators.
- `scripts/run_analysis.py` - one-command complete pipeline.
- `scripts/build_notebook.py` - reproducible executed notebook builder.
- `scripts/build_report.py` - reproducible two-page PDF builder.
- `tests/test_study.py` - seven automated engineering checks.
- `requirements.txt`, `environment.yml`, `pyproject.toml` - portable environment/package definitions.

## Data and results

- `data/DATA_DESCRIPTION.md` - field definitions, provenance, and rating caveat.
- `results/contingency_results.csv` - required ranked one-row-per-outage result.
- `results/contingency_bus_results.csv` - detailed solved bus results.
- `results/contingency_branch_results.csv` - detailed monitored-branch results.
- `results/base_case_*.csv` - base buses, generators, and branches.
- `results/ptdf_matrix.csv`, `results/lodf_matrix.csv` - computed factor matrices.
- `results/dc_lodf_screening.csv`, `results/dc_ac_comparison*.csv` - screening and validation.
- `results/validation_summary.json` - machine-readable numerical checks.
- `results/figures/` - six publication-quality PNG charts/network visuals.

## Career package

- `docs/CAREER_AND_INTERVIEW.md` - two truthful resume bullets, 30-second explanation, five interview questions/answers.
- `portfolio/assets/` - web-ready copies of the key figures.

