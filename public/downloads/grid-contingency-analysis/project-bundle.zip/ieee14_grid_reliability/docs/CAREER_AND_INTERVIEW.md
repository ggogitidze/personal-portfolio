# Portfolio and interview material

## Two truthful resume bullets

- Built a modular Python/pandapower N-1 reliability study for the IEEE 14-bus system, validating an AC base case with Newton-Raphson and fast-decoupled solvers before automating 20 line/transformer outages, islanding detection, voltage checks, and scenario-based thermal screening.
- Implemented and independently cross-checked PTDF/LODF matrices, compared DC screening with full AC outage flows (1.17 MW mean absolute error on five selected connected cases), and delivered tested CSV outputs, network visualizations, an interactive dashboard, and a portable technical report.

Do not replace “scenario-based thermal screening” with “utility thermal limits.” The case does not provide actual ratings.

## 30-second recruiter explanation

“I combined my software background with power-system analysis by building an N-1 reliability study for the IEEE 14-bus grid. I first validated the AC base case with two solvers and a power-balance check. Then I automatically tripped every line and transformer, detected islanding, measured voltage and scenario-based thermal violations, and ranked each event with a score whose components are fully visible. Finally, I implemented PTDF/LODF screening and tested it against the full AC results, showing both where the fast approximation works and where it cannot replace AC analysis.”

## Five interview questions and answers

### 1. Why is a slack bus necessary?

Power-flow losses are unknown until voltages and flows are solved, so scheduled generation and load cannot balance exactly beforehand. The slack bus provides the angle reference and its solved P/Q absorbs the remaining real and reactive mismatch. The mathematical role must correspond to a credible regulating source in an operational model.

### 2. Why did the base case have voltage violations?

The source case encodes a 1.06 p.u. upper limit while PV setpoints include 1.07 and 1.09 p.u. The solution therefore flags buses 6, 7, and 8. I kept the inconsistency visible. In a real study, I would confirm whether the limits or setpoints are the intended criteria.

### 3. Are the overloads real equipment overloads?

No. MATPOWER case14 says MVA limits were not provided and records rateA as zero. I created a transparent stress-test rating with 25% base-case headroom, a 40 MVA floor, and 5 MVA rounding. Replacing those ratings is the first requirement for real planning work.

### 4. Why can LODF fail even when active-flow predictions are good?

LODF is based on a linear, lossless DC model. It ignores reactive power, voltage-magnitude changes, resistance, reactive limits, and nonlinear convergence. Full AC is required for voltage and reactive-security conclusions. A bridge outage makes the denominator singular because the network islands.

### 5. How did you validate the project?

I required two AC algorithms to agree, checked generation minus demand minus losses, tested the exact contingency count and missing data, unit-tested voltage and thermal boundaries, verified stable ranking, and compared my independent PTDF/LODF matrices with PYPOWER to near machine precision. Every summary remains traceable to bus- and branch-level results.

