from __future__ import annotations

from copy import deepcopy

import networkx as nx
import numpy as np
import pandas as pd
import pandapower as pp

from .config import StudyConfig
from .network import branch_catalog
from .powerflow import collect_branch_results, collect_bus_results, solve_ac
from .severity import score_contingency


def _active_graph(net) -> nx.Graph:
    graph = nx.Graph()
    active_buses = net.bus.index[net.bus.in_service].astype(int).tolist()
    graph.add_nodes_from(active_buses)
    for _, row in net.line[net.line.in_service].iterrows():
        graph.add_edge(int(row.from_bus), int(row.to_bus))
    for _, row in net.trafo[net.trafo.in_service].iterrows():
        graph.add_edge(int(row.hv_bus), int(row.lv_bus))
    return graph


def topology_status(net) -> dict:
    graph = _active_graph(net)
    components = list(nx.connected_components(graph))
    slack_buses = set(net.ext_grid.loc[net.ext_grid.in_service, "bus"].astype(int))
    supplied = set().union(*(c for c in components if c & slack_buses)) if components else set()
    unsupplied = set(graph.nodes) - supplied
    unsupplied_load = float(
        net.load.loc[
            net.load.in_service & net.load.bus.astype(int).isin(unsupplied), "p_mw"
        ].sum()
    )
    return {
        "islanded": len(components) > 1,
        "component_count": len(components),
        "unsupplied_bus_indices": sorted(unsupplied),
        "unsupplied_bus_count": len(unsupplied),
        "unsupplied_load_mw": unsupplied_load,
    }


def _set_branch_out(net, element_type: str, element_index: int) -> None:
    table = net.line if element_type == "line" else net.trafo
    table.at[element_index, "in_service"] = False


def run_contingency(
    base_net,
    branch_row,
    ratings: pd.DataFrame,
    base_loss_mw: float,
    config: StudyConfig,
) -> tuple[dict, pd.DataFrame, pd.DataFrame]:
    net = deepcopy(base_net)
    _set_branch_out(net, branch_row.element_type, int(branch_row.element_index))
    topo = topology_status(net)
    total_load_mw = float(base_net.load.loc[base_net.load.in_service, "p_mw"].sum())

    converged = False
    error = ""
    buses = pd.DataFrame()
    branches = pd.DataFrame()
    post_loss = None

    if not topo["islanded"]:
        try:
            solve_ac(net, config, "nr")
            converged = bool(net.converged)
            if converged:
                buses = collect_bus_results(net, config)
                branches = collect_branch_results(net, ratings)
                branches = branches[branches.branch_id != branch_row.branch_id].copy()
                post_loss = float(branches.p_loss_mw.sum())
        except (pp.LoadflowNotConverged, FloatingPointError, ValueError) as exc:
            error = f"{type(exc).__name__}: {exc}"
    else:
        error = "Topology check found more than one connected component"

    score = score_contingency(
        config=config,
        islanded=bool(topo["islanded"]),
        converged=converged,
        unsupplied_load_mw=float(topo["unsupplied_load_mw"]),
        total_load_mw=total_load_mw,
        bus_results=buses if converged else None,
        branch_results=branches if converged else None,
        base_loss_mw=base_loss_mw,
        post_loss_mw=post_loss,
    )

    summary = {
        "branch_id": branch_row.branch_id,
        "branch_name": branch_row.name,
        "element_type": branch_row.element_type,
        "element_index": int(branch_row.element_index),
        "from_bus": int(branch_row.from_bus),
        "to_bus": int(branch_row.to_bus),
        "converged": converged,
        "islanded": bool(topo["islanded"]),
        "component_count": int(topo["component_count"]),
        "unsupplied_bus_count": int(topo["unsupplied_bus_count"]),
        "unsupplied_buses": ",".join(
            str(int(base_net.bus.at[i, "bus_number"]))
            for i in topo["unsupplied_bus_indices"]
        ),
        "unsupplied_load_mw": float(topo["unsupplied_load_mw"]),
        "min_vm_pu": float(buses.vm_pu.min()) if converged else np.nan,
        "max_vm_pu": float(buses.vm_pu.max()) if converged else np.nan,
        "voltage_violation_count": int(buses.voltage_violation.sum()) if converged else 0,
        "voltage_breach_sum_pu": float(
            buses.v_lower_breach_pu.sum() + buses.v_upper_breach_pu.sum()
        ) if converged else np.nan,
        "max_loading_percent": float(branches.loading_percent.max()) if converged else np.nan,
        "thermal_violation_count": int(
            (branches.loading_percent > config.thermal_limit_percent).sum()
        ) if converged else 0,
        "losses_mw": post_loss if post_loss is not None else np.nan,
        "error": error,
        **score,
    }
    if converged:
        buses.insert(0, "contingency_id", branch_row.branch_id)
        branches.insert(0, "contingency_id", branch_row.branch_id)
    return summary, buses, branches


def rank_contingencies(results: pd.DataFrame) -> pd.DataFrame:
    ranked = results.sort_values(
        ["severity_score", "branch_id"], ascending=[False, True], kind="mergesort"
    ).reset_index(drop=True)
    ranked.insert(0, "rank", np.arange(1, len(ranked) + 1, dtype=int))
    return ranked


def run_all_contingencies(base: dict, config: StudyConfig) -> dict:
    catalog = branch_catalog(base["net"])
    summaries, bus_frames, branch_frames = [], [], []
    for row in catalog.itertuples(index=False):
        summary, buses, branches = run_contingency(
            base["net"], row, base["ratings"], base["balance"]["losses_mw"], config
        )
        summaries.append(summary)
        if not buses.empty:
            bus_frames.append(buses)
        if not branches.empty:
            branch_frames.append(branches)
    summary_df = rank_contingencies(pd.DataFrame(summaries))
    bus_df = pd.concat(bus_frames, ignore_index=True) if bus_frames else pd.DataFrame()
    branch_df = pd.concat(branch_frames, ignore_index=True) if branch_frames else pd.DataFrame()
    return {"summary": summary_df, "bus_results": bus_df, "branch_results": branch_df}

