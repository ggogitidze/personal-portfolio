from __future__ import annotations

import numpy as np
import pandas as pd

from .network import branch_catalog


def build_dc_factors(solved_net) -> dict:
    """Build a transparent lossless DC PTDF/LODF model from pandapower's ppc data."""
    ppc = solved_net._ppc
    branch = ppc["branch"]
    nb = int(ppc["bus"].shape[0])
    nl = int(branch.shape[0])
    f = branch[:, 0].astype(int)
    t = branch[:, 1].astype(int)
    x = branch[:, 3].astype(float)
    tap = branch[:, 8].astype(float).copy()
    tap[tap == 0] = 1.0
    if np.any(np.isclose(x, 0.0)):
        raise ValueError("DC factor model requires non-zero branch reactance")

    incidence = np.zeros((nl, nb), dtype=float)
    incidence[np.arange(nl), f] = 1.0
    incidence[np.arange(nl), t] = -1.0
    susceptance = 1.0 / (x * tap)
    bf = susceptance[:, None] * incidence
    bbus = incidence.T @ bf

    slack_pp_bus = int(ppc["bus"][ppc["bus"][:, 1] == 3, 0][0])
    nonslack = np.array([i for i in range(nb) if i != slack_pp_bus], dtype=int)
    ptdf = np.zeros((nl, nb), dtype=float)
    ptdf[:, nonslack] = bf[:, nonslack] @ np.linalg.inv(
        bbus[np.ix_(nonslack, nonslack)]
    )

    endpoint_ptdf = ptdf[:, f] - ptdf[:, t]
    denominator = 1.0 - np.diag(endpoint_ptdf)
    lodf = np.full((nl, nl), np.nan, dtype=float)
    bridge_mask = np.isclose(denominator, 0.0, atol=1e-10)
    for k in range(nl):
        if not bridge_mask[k]:
            lodf[:, k] = endpoint_ptdf[:, k] / denominator[k]
            lodf[k, k] = -1.0

    catalog = branch_catalog(solved_net)
    if len(catalog) != nl:
        raise AssertionError("pandapower-to-ppc branch mapping changed")
    return {
        "ptdf": ptdf,
        "lodf": lodf,
        "bridge_mask": bridge_mask,
        "catalog": catalog,
        "slack_bus_ppc": slack_pp_bus,
    }


def screen_outages(base_branches: pd.DataFrame, factors: dict) -> pd.DataFrame:
    catalog = factors["catalog"]
    lodf = factors["lodf"]
    base_by_id = base_branches.set_index("branch_id")
    base_flow = base_by_id.loc[catalog.branch_id, "p_from_mw"].to_numpy(float)
    ratings = base_by_id.loc[catalog.branch_id, "rating_mva"].to_numpy(float)
    rows = []
    for k, outage in catalog.iterrows():
        if factors["bridge_mask"][k]:
            rows.append(
                {
                    "branch_id": outage.branch_id,
                    "dc_screenable": False,
                    "dc_max_loading_percent": np.nan,
                    "dc_overload_count": np.nan,
                    "dc_reason": "bridge/islanding denominator",
                }
            )
            continue
        predicted = base_flow + lodf[:, k] * base_flow[k]
        loading = 100.0 * np.abs(predicted) / ratings
        loading[k] = np.nan
        rows.append(
            {
                "branch_id": outage.branch_id,
                "dc_screenable": True,
                "dc_max_loading_percent": float(np.nanmax(loading)),
                "dc_overload_count": int(np.nansum(loading > 100.0)),
                "dc_reason": "",
            }
        )
    return pd.DataFrame(rows)


def compare_dc_ac(
    base_branches: pd.DataFrame,
    factors: dict,
    ac_branch_results: pd.DataFrame,
    contingency_ids: list[str],
) -> pd.DataFrame:
    catalog = factors["catalog"]
    catalog_idx = {bid: i for i, bid in enumerate(catalog.branch_id)}
    base_by_id = base_branches.set_index("branch_id")
    base_flow = base_by_id.loc[catalog.branch_id, "p_from_mw"].to_numpy(float)
    rows = []
    for outage_id in contingency_ids:
        k = catalog_idx[outage_id]
        if factors["bridge_mask"][k]:
            continue
        predicted = base_flow + factors["lodf"][:, k] * base_flow[k]
        ac_case = ac_branch_results[ac_branch_results.contingency_id == outage_id]
        ac_map = ac_case.set_index("branch_id")["p_from_mw"]
        for m, monitored_id in enumerate(catalog.branch_id):
            if monitored_id == outage_id or monitored_id not in ac_map.index:
                continue
            ac_flow = float(ac_map.loc[monitored_id])
            dc_flow = float(predicted[m])
            rows.append(
                {
                    "contingency_id": outage_id,
                    "monitored_branch_id": monitored_id,
                    "ac_p_from_mw": ac_flow,
                    "dc_lodf_p_from_mw": dc_flow,
                    "absolute_error_mw": abs(dc_flow - ac_flow),
                    "absolute_flow_error_mw": abs(abs(dc_flow) - abs(ac_flow)),
                }
            )
    frame = pd.DataFrame(rows)
    if not frame.empty:
        frame["signed_error_mw"] = frame.dc_lodf_p_from_mw - frame.ac_p_from_mw
    return frame

