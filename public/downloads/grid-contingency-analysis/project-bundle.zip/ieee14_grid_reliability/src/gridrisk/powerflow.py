from __future__ import annotations

from copy import deepcopy

import numpy as np
import pandas as pd
import pandapower as pp

from .config import StudyConfig
from .network import branch_catalog, build_study_ratings, bus_type_table


def solve_ac(net, config: StudyConfig, algorithm: str = "nr"):
    pp.runpp(
        net,
        algorithm=algorithm,
        calculate_voltage_angles=True,
        init="flat",
        tolerance_mva=config.nr_tolerance_mva,
        max_iteration=config.max_iteration,
        enforce_q_lims=False,
        check_connectivity=True,
        numba=False,
    )
    return net


def collect_bus_results(net, config: StudyConfig) -> pd.DataFrame:
    types = bus_type_table(net).set_index("bus_index")
    result = net.res_bus[["vm_pu", "va_degree", "p_mw", "q_mvar"]].copy()
    result.index.name = "bus_index"
    result = result.join(types)
    result["v_lower_breach_pu"] = (result.min_vm_pu - result.vm_pu).clip(lower=0)
    result["v_upper_breach_pu"] = (result.vm_pu - result.max_vm_pu).clip(lower=0)
    result["voltage_violation"] = (
        result.v_lower_breach_pu.gt(0) | result.v_upper_breach_pu.gt(0)
    )
    return result.reset_index()


def collect_generator_results(net) -> pd.DataFrame:
    rows = []
    for idx, row in net.ext_grid.iterrows():
        rows.append(
            {
                "source": "slack",
                "element_index": int(idx),
                "bus": int(net.bus.at[row.bus, "bus_number"]),
                "p_mw": float(net.res_ext_grid.at[idx, "p_mw"]),
                "q_mvar": float(net.res_ext_grid.at[idx, "q_mvar"]),
                "vm_pu": float(row.vm_pu),
            }
        )
    for idx, row in net.gen.iterrows():
        rows.append(
            {
                "source": "PV generator",
                "element_index": int(idx),
                "bus": int(net.bus.at[row.bus, "bus_number"]),
                "p_mw": float(net.res_gen.at[idx, "p_mw"]),
                "q_mvar": float(net.res_gen.at[idx, "q_mvar"]),
                "vm_pu": float(net.res_gen.at[idx, "vm_pu"]),
            }
        )
    return pd.DataFrame(rows)


def collect_branch_results(net, ratings: pd.DataFrame | None = None) -> pd.DataFrame:
    catalog = branch_catalog(net)
    rows = []
    for row in catalog.itertuples(index=False):
        if row.element_type == "line":
            r = net.res_line.loc[row.element_index]
            p_from, q_from = r.p_from_mw, r.q_from_mvar
            p_to, q_to = r.p_to_mw, r.q_to_mvar
            p_loss, q_loss = r.pl_mw, r.ql_mvar
        else:
            r = net.res_trafo.loc[row.element_index]
            p_from, q_from = r.p_hv_mw, r.q_hv_mvar
            p_to, q_to = r.p_lv_mw, r.q_lv_mvar
            p_loss, q_loss = r.pl_mw, r.ql_mvar
        s_from = float(np.hypot(p_from, q_from))
        s_to = float(np.hypot(p_to, q_to))
        rows.append(
            {
                **row._asdict(),
                "p_from_mw": float(p_from),
                "q_from_mvar": float(q_from),
                "p_to_mw": float(p_to),
                "q_to_mvar": float(q_to),
                "p_loss_mw": float(p_loss),
                "q_loss_mvar": float(q_loss),
                "s_from_mva": s_from,
                "s_to_mva": s_to,
                "base_mva": max(s_from, s_to),
            }
        )
    frame = pd.DataFrame(rows)
    if ratings is not None:
        frame = frame.merge(
            ratings[["branch_id", "rating_mva", "rating_basis"]],
            on="branch_id",
            how="left",
            validate="one_to_one",
        )
        frame["loading_percent"] = 100.0 * frame.base_mva / frame.rating_mva
    return frame


def active_power_balance(net, branch_results: pd.DataFrame) -> dict:
    generation = float(net.res_ext_grid.p_mw.sum() + net.res_gen.p_mw.sum())
    demand = float(net.load.loc[net.load.in_service, "p_mw"].sum())
    losses = float(branch_results.p_loss_mw.sum())
    residual = generation - demand - losses
    return {
        "generation_mw": generation,
        "demand_mw": demand,
        "losses_mw": losses,
        "balance_residual_mw": residual,
    }


def run_base_case(net, config: StudyConfig) -> dict:
    nr_net = solve_ac(deepcopy(net), config, "nr")
    if not nr_net.converged:
        raise RuntimeError("Newton-Raphson base case did not converge")

    raw_branches = collect_branch_results(nr_net)
    ratings = build_study_ratings(raw_branches, config)
    branches = collect_branch_results(nr_net, ratings)
    buses = collect_bus_results(nr_net, config)
    generators = collect_generator_results(nr_net)
    balance = active_power_balance(nr_net, branches)

    # A second AC algorithm provides an independent numerical cross-check.
    fdbx_net = solve_ac(deepcopy(net), config, "fdbx")
    if not fdbx_net.converged:
        raise RuntimeError("Fast-decoupled validation solution did not converge")
    vm_delta = np.abs(nr_net.res_bus.vm_pu.to_numpy() - fdbx_net.res_bus.vm_pu.to_numpy())
    va_delta = np.abs(
        nr_net.res_bus.va_degree.to_numpy() - fdbx_net.res_bus.va_degree.to_numpy()
    )
    validation = {
        "nr_converged": bool(nr_net.converged),
        "fdbx_converged": bool(fdbx_net.converged),
        "max_vm_difference_pu": float(vm_delta.max()),
        "max_angle_difference_deg": float(va_delta.max()),
        "power_balance_residual_mw": float(balance["balance_residual_mw"]),
        "vm_crosscheck_pass": bool(vm_delta.max() < 1e-6),
        "angle_crosscheck_pass": bool(va_delta.max() < 1e-4),
        "power_balance_pass": bool(abs(balance["balance_residual_mw"]) < 1e-6),
    }
    if not all(
        validation[key]
        for key in ("vm_crosscheck_pass", "angle_crosscheck_pass", "power_balance_pass")
    ):
        raise RuntimeError(f"Base-case validation failed: {validation}")

    return {
        "net": nr_net,
        "buses": buses,
        "generators": generators,
        "branches": branches,
        "ratings": ratings,
        "balance": balance,
        "validation": validation,
    }
