from __future__ import annotations

import pandas as pd

from .config import StudyConfig


def voltage_breach_sum(bus_results: pd.DataFrame) -> float:
    return float(
        bus_results["v_lower_breach_pu"].sum()
        + bus_results["v_upper_breach_pu"].sum()
    )


def thermal_exceedance_sum(branch_results: pd.DataFrame, limit_percent: float) -> float:
    return float((branch_results.loading_percent - limit_percent).clip(lower=0).sum())


def score_contingency(
    *,
    config: StudyConfig,
    islanded: bool,
    converged: bool,
    unsupplied_load_mw: float,
    total_load_mw: float,
    bus_results: pd.DataFrame | None,
    branch_results: pd.DataFrame | None,
    base_loss_mw: float,
    post_loss_mw: float | None,
) -> dict:
    islanding = config.islanding_penalty if islanded else 0.0
    nonconvergence = config.nonconvergence_penalty if not converged else 0.0
    unsupplied = (
        config.unsupplied_load_weight * unsupplied_load_mw / total_load_mw
        if total_load_mw > 0
        else 0.0
    )
    voltage = (
        config.voltage_breach_weight * voltage_breach_sum(bus_results)
        if bus_results is not None
        else 0.0
    )
    thermal = (
        config.thermal_exceedance_weight
        * thermal_exceedance_sum(branch_results, config.thermal_limit_percent)
        if branch_results is not None
        else 0.0
    )
    loss = 0.0
    if post_loss_mw is not None and base_loss_mw > 0:
        pct_increase = max(0.0, 100.0 * (post_loss_mw - base_loss_mw) / base_loss_mw)
        loss = config.loss_increase_weight * pct_increase
    score = islanding + nonconvergence + unsupplied + voltage + thermal + loss
    return {
        "islanding_component": islanding,
        "nonconvergence_component": nonconvergence,
        "unsupplied_component": unsupplied,
        "voltage_component": voltage,
        "thermal_component": thermal,
        "loss_component": loss,
        "severity_score": score,
    }

