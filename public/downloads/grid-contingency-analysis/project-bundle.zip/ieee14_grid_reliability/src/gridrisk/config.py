from dataclasses import dataclass


@dataclass(frozen=True)
class StudyConfig:
    """All engineering assumptions in one auditable object."""

    voltage_fallback_min_pu: float = 0.94
    voltage_fallback_max_pu: float = 1.06
    thermal_limit_percent: float = 100.0
    rating_headroom: float = 1.25
    rating_floor_mva: float = 40.0
    rating_rounding_mva: float = 5.0
    nr_tolerance_mva: float = 1e-8
    max_iteration: int = 30

    # Severity: status terms dominate; remaining terms are continuous.
    islanding_penalty: float = 1000.0
    nonconvergence_penalty: float = 750.0
    unsupplied_load_weight: float = 100.0
    voltage_breach_weight: float = 1000.0
    thermal_exceedance_weight: float = 1.0
    loss_increase_weight: float = 0.05

    random_seed: int = 14

