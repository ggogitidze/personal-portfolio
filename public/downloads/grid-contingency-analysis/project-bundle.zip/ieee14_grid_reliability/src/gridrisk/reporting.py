from __future__ import annotations

import json
import shutil
from pathlib import Path

import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
from plotly.subplots import make_subplots


def _fmt(value, digits=2):
    return "N/A" if pd.isna(value) else f"{value:.{digits}f}"


def write_dashboard(base: dict, outages: dict, dc_screen: pd.DataFrame, path: Path):
    summary = outages["summary"].copy()
    top = summary.head(5)
    fig = make_subplots(
        rows=2, cols=2,
        subplot_titles=("Base Bus Voltages", "Top 10 Severity Scores", "Maximum Loading by Outage", "Voltage Range by Outage"),
        specs=[[{"type": "bar"}, {"type": "bar"}], [{"type": "scatter"}, {"type": "scatter"}]],
        vertical_spacing=0.16,
    )
    fig.add_trace(go.Bar(x=base["buses"].bus_number, y=base["buses"].vm_pu, name="Voltage", marker_color="#1976D2"), 1, 1)
    fig.add_hline(y=1.06, line_dash="dash", line_color="#C62828", row=1, col=1)
    fig.add_hline(y=0.94, line_dash="dash", line_color="#F9A825", row=1, col=1)
    rank10 = summary.head(10).sort_values("severity_score")
    fig.add_trace(go.Bar(x=rank10.severity_score, y=rank10.branch_name, orientation="h", name="Severity", marker_color="#00897B"), 1, 2)
    conv = summary[summary.converged]
    fig.add_trace(go.Scatter(x=conv["rank"], y=conv.max_loading_percent, mode="markers+lines", name="Max loading %", marker_color="#F9A825"), 2, 1)
    fig.add_hline(y=100, line_dash="dash", line_color="#C62828", row=2, col=1)
    fig.add_trace(go.Scatter(x=conv["rank"], y=conv.min_vm_pu, mode="markers", name="Min V", marker_color="#1976D2"), 2, 2)
    fig.add_trace(go.Scatter(x=conv["rank"], y=conv.max_vm_pu, mode="markers", name="Max V", marker_color="#C62828"), 2, 2)
    fig.update_layout(height=850, template="plotly_white", title="IEEE 14-Bus Grid-Risk Dashboard", legend_orientation="h")
    plot_html = fig.to_html(full_html=False, include_plotlyjs=True)

    top_rows = "".join(
        f"<tr><td>{int(r.rank)}</td><td>{r.branch_name}</td><td>{r.severity_score:.2f}</td>"
        f"<td>{'Islanding' if r.islanded else ('Converged' if r.converged else 'Non-convergent')}</td>"
        f"<td>{_fmt(r.max_loading_percent)}%</td><td>{int(r.voltage_violation_count)}</td></tr>"
        for r in top.itertuples(index=False)
    )
    base_v = int(base["buses"].voltage_violation.sum())
    base_t = int((base["branches"].loading_percent > 100).sum())
    island_count = int(summary.islanded.sum())
    nonconv_count = int((~summary.converged & ~summary.islanded).sum())
    html = f"""<!doctype html><html><head><meta charset='utf-8'><title>IEEE 14-Bus Grid-Risk Dashboard</title>
<style>body{{font-family:Inter,Arial,sans-serif;margin:0;background:#f5f7fa;color:#17324D}}main{{max-width:1180px;margin:auto;padding:28px}}.cards{{display:grid;grid-template-columns:repeat(5,1fr);gap:12px}}.card{{background:white;border-radius:10px;padding:16px;box-shadow:0 2px 10px #0001}}.metric{{font-size:28px;font-weight:700;color:#1976D2}}table{{width:100%;border-collapse:collapse;background:white}}th,td{{padding:10px;border-bottom:1px solid #dde5ec;text-align:left}}th{{background:#17324D;color:white}}.note{{background:#fff8e1;border-left:5px solid #F9A825;padding:12px;margin:18px 0}}@media(max-width:800px){{.cards{{grid-template-columns:1fr 1fr}}}}</style></head><body><main>
<h1>IEEE 14-Bus N-1 Contingency Analysis</h1><p>Full AC outage analysis with transparent synthetic thermal ratings and DC/LODF screening.</p>
<div class='cards'><div class='card'><div class='metric'>259.0 MW</div>Base load</div><div class='card'><div class='metric'>{base['balance']['losses_mw']:.2f} MW</div>Base losses</div><div class='card'><div class='metric'>{base_v}</div>Base voltage violations</div><div class='card'><div class='metric'>{base_t}</div>Base thermal violations</div><div class='card'><div class='metric'>{island_count}</div>Islanding outages</div></div>
<div class='note'><strong>Interpretation guardrail:</strong> the canonical case omits branch ratings. Thermal percentages use a documented study rating: 25% base-case MVA headroom, rounded up to 5 MVA, with a 40 MVA floor. They are scenario results, not utility equipment ratings.</div>
{plot_html}<h2>Top five contingencies</h2><table><thead><tr><th>Rank</th><th>Outage</th><th>Score</th><th>Status</th><th>Max loading</th><th>Voltage violations</th></tr></thead><tbody>{top_rows}</tbody></table>
<p>Additional non-islanding non-convergent cases: {nonconv_count}. See CSV files for bus- and branch-level detail.</p></main></body></html>"""
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(html, encoding="utf-8")


def write_portfolio_page(base: dict, outages: dict, comparison: pd.DataFrame, project_root: Path):
    portfolio = project_root / "portfolio"
    assets = portfolio / "assets"
    assets.mkdir(parents=True, exist_ok=True)
    for name in ["network_base.png", "contingency_severity_top10.png", "dc_ac_comparison.png", "base_voltage_profile.png"]:
        shutil.copy2(project_root / "results" / "figures" / name, assets / name)
    top = outages["summary"].iloc[0]
    mae = float(comparison.absolute_error_mw.mean()) if not comparison.empty else float("nan")
    html = f"""<!doctype html><html><head><meta charset='utf-8'><meta name='viewport' content='width=device-width,initial-scale=1'><title>IEEE 14-Bus Grid Risk</title><link rel='stylesheet' href='styles.css'></head><body>
<header><div class='eyebrow'>POWER SYSTEMS · PYTHON · RELIABILITY</div><h1>IEEE 14-Bus N-1 Contingency Analysis and Grid-Risk Dashboard</h1><p>I built a reproducible full-AC outage study, ranked all 20 single-branch contingencies, detected islanding, and tested a fast DC/LODF screen against AC results.</p></header>
<main><section class='metrics'><article><strong>20</strong><span>branches tested</span></article><article><strong>{int(outages['summary'].converged.sum())}</strong><span>AC-converged outages</span></article><article><strong>{int(outages['summary'].islanded.sum())}</strong><span>islanding case</span></article><article><strong>{base['balance']['losses_mw']:.2f} MW</strong><span>base real losses</span></article></section>
<section><h2>What the study found</h2><p>The most severe outage was <b>{top.branch_name}</b>, which islands bus {top.unsupplied_buses}. Among solved contingencies, the ranking combines voltage-limit breaches, thermal exceedance, loss increase, and failure-state penalties. The base AC solution was cross-checked with a second solver before contingencies ran.</p><img src='assets/contingency_severity_top10.png' alt='Top contingency severity ranking'></section>
<section class='split'><div><h2>Network model</h2><p>The test grid contains 14 buses, 15 lines, five transformers, five voltage-controlled sources including the slack, and 259 MW of load. Slack, PV, and PQ buses are treated according to which voltage and power variables are specified.</p></div><img src='assets/network_base.png' alt='IEEE 14-bus network'></section>
<section><h2>Fast screening versus full AC</h2><p>PTDFs map balanced bus injections to line-flow changes. LODFs use those sensitivities to estimate how pre-outage flow redistributes after a branch trip. Across the selected comparison set, mean signed-flow absolute error was {mae:.2f} MW; the bridge outage is deliberately not screened because its LODF denominator identifies islanding.</p><img src='assets/dc_ac_comparison.png' alt='DC LODF estimates versus full AC branch flows'></section>
<section class='note'><h2>Engineering honesty</h2><p>The source case does not provide continuous branch ratings. I therefore use clearly labeled synthetic study ratings for a reproducible stress test; no result is presented as an actual utility limit. The model is a teaching and portfolio study, not an operating decision tool.</p></section>
<section><h2>Downloads</h2><ul><li><a href='../results/contingency_results.csv'>Contingency results (CSV)</a></li><li><a href='../notebooks/01_ieee14_contingency_demo.ipynb'>Demonstration notebook</a></li><li><a href='../docs/IEEE14_Technical_Report.pdf'>Two-page technical report</a></li><li><a href='../dashboard/grid_risk_dashboard.html'>Interactive dashboard</a></li></ul></section></main>
<footer>Giorgi Gogitidze · M.S. Electrical Engineering / B.S. Computer Science</footer></body></html>"""
    (portfolio / "index.html").write_text(html, encoding="utf-8")
    css = """*{box-sizing:border-box}body{margin:0;font-family:Inter,Arial,sans-serif;color:#17324D;background:#f6f8fb;line-height:1.6}header,main,footer{max-width:1080px;margin:auto;padding:32px}header{padding-top:72px}.eyebrow{letter-spacing:.14em;color:#00897B;font-weight:700}h1{font-size:clamp(2.2rem,5vw,4.5rem);line-height:1.05;margin:.25em 0}h2{font-size:1.9rem}section{background:#fff;margin:24px 0;padding:28px;border-radius:16px;box-shadow:0 5px 24px #17324D12}.metrics{display:grid;grid-template-columns:repeat(4,1fr);gap:16px;background:transparent;box-shadow:none;padding:0}.metrics article{background:#17324D;color:white;border-radius:12px;padding:20px}.metrics strong{display:block;font-size:1.8rem;color:#80CBC4}.metrics span{font-size:.9rem}.split{display:grid;grid-template-columns:1fr 1fr;gap:24px;align-items:center}img{width:100%;height:auto;border-radius:10px}.note{border-left:6px solid #F9A825}a{color:#1976D2}footer{text-align:center;color:#607D8B}@media(max-width:760px){.metrics,.split{grid-template-columns:1fr 1fr}.split img{grid-column:1/-1}}"""
    (portfolio / "styles.css").write_text(css, encoding="utf-8")


def write_json(data: dict, path: Path):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, indent=2), encoding="utf-8")
