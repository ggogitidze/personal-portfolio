from __future__ import annotations

from pathlib import Path

import matplotlib.pyplot as plt
import networkx as nx
import numpy as np
import pandas as pd
from matplotlib.colors import Normalize

from .config import StudyConfig
from .network import branch_catalog


COLORS = {
    "navy": "#17324D",
    "blue": "#1976D2",
    "teal": "#00897B",
    "amber": "#F9A825",
    "red": "#C62828",
    "gray": "#607D8B",
    "light": "#EEF3F7",
}

BUS_POSITIONS = {
    1: (0.0, 3.0), 2: (1.5, 3.0), 3: (3.1, 3.2), 4: (3.0, 1.9),
    5: (1.4, 1.6), 6: (3.1, 0.2), 7: (4.3, 1.4), 8: (4.5, 2.7),
    9: (5.2, 0.8), 10: (6.3, 0.9), 11: (5.1, -0.2), 12: (3.8, -1.0),
    13: (5.1, -1.0), 14: (6.5, -0.4),
}


def _save(fig, path: Path):
    path.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(path, dpi=220, bbox_inches="tight", facecolor="white")
    plt.close(fig)


def plot_voltage_profile(buses: pd.DataFrame, path: Path):
    fig, ax = plt.subplots(figsize=(9, 4.5))
    colors = [COLORS["red"] if v else COLORS["blue"] for v in buses.voltage_violation]
    ax.bar(buses.bus_number, buses.vm_pu, color=colors, width=0.72)
    ax.axhline(buses.min_vm_pu.iloc[0], color=COLORS["amber"], ls="--", lw=1.5, label="Lower limit")
    ax.axhline(buses.max_vm_pu.iloc[0], color=COLORS["red"], ls="--", lw=1.5, label="Upper limit")
    ax.set_ylim(0.92, 1.11)
    ax.set_xticks(buses.bus_number)
    ax.set_xlabel("Bus")
    ax.set_ylabel("Voltage magnitude (p.u.)")
    ax.set_title("Base-Case Voltage Profile")
    ax.legend(frameon=False, ncol=2)
    ax.grid(axis="y", alpha=0.2)
    _save(fig, path)


def plot_branch_loading(branches: pd.DataFrame, path: Path):
    ordered = branches.sort_values("loading_percent")
    fig, ax = plt.subplots(figsize=(9, 6))
    colors = np.where(ordered.loading_percent > 100, COLORS["red"], COLORS["teal"])
    ax.barh(ordered.name, ordered.loading_percent, color=colors)
    ax.axvline(100, color=COLORS["red"], ls="--", lw=1.5, label="Study rating")
    ax.set_xlabel("Loading (% of synthetic study rating)")
    ax.set_title("Base-Case Branch Loading")
    ax.grid(axis="x", alpha=0.2)
    ax.legend(frameon=False)
    _save(fig, path)


def plot_contingency_ranking(summary: pd.DataFrame, path: Path, top_n: int = 10):
    top = summary.head(top_n).sort_values("severity_score")
    fig, ax = plt.subplots(figsize=(9, 5.5))
    colors = [COLORS["red"] if x else COLORS["blue"] for x in top.islanded]
    ax.barh(top.branch_name, top.severity_score, color=colors)
    ax.set_xlabel("Severity score (dimensionless study index)")
    ax.set_title(f"Top {min(top_n, len(top))} N-1 Contingencies")
    ax.grid(axis="x", alpha=0.2)
    for y, value in enumerate(top.severity_score):
        ax.text(value + max(top.severity_score) * 0.01, y, f"{value:.1f}", va="center", fontsize=8)
    _save(fig, path)


def plot_dc_ac_comparison(comparison: pd.DataFrame, path: Path):
    fig, ax = plt.subplots(figsize=(6.5, 6))
    if comparison.empty:
        ax.text(0.5, 0.5, "No screenable comparison cases", ha="center", va="center")
    else:
        for cid, group in comparison.groupby("contingency_id"):
            ax.scatter(group.ac_p_from_mw, group.dc_lodf_p_from_mw, s=28, alpha=0.75, label=cid)
        bounds = [
            min(comparison.ac_p_from_mw.min(), comparison.dc_lodf_p_from_mw.min()),
            max(comparison.ac_p_from_mw.max(), comparison.dc_lodf_p_from_mw.max()),
        ]
        pad = 0.05 * (bounds[1] - bounds[0])
        ax.plot([bounds[0] - pad, bounds[1] + pad], [bounds[0] - pad, bounds[1] + pad],
                ls="--", color=COLORS["gray"], label="Perfect agreement")
        ax.set_xlim(bounds[0] - pad, bounds[1] + pad)
        ax.set_ylim(bounds[0] - pad, bounds[1] + pad)
        ax.legend(frameon=False, fontsize=8)
    ax.set_xlabel("Full AC post-outage P from (MW)")
    ax.set_ylabel("DC/LODF estimate (MW)")
    ax.set_title("DC Screening vs. Full AC Results")
    ax.grid(alpha=0.2)
    _save(fig, path)


def plot_network(
    net,
    buses: pd.DataFrame,
    path: Path,
    *,
    title: str,
    outaged_branch_id: str | None = None,
    unsupplied_bus_numbers: set[int] | None = None,
):
    unsupplied_bus_numbers = unsupplied_bus_numbers or set()
    catalog = branch_catalog(net)
    graph = nx.Graph()
    graph.add_nodes_from(buses.bus_number.astype(int))

    fig, ax = plt.subplots(figsize=(9, 6.5))
    for row in catalog.itertuples(index=False):
        style = "--" if row.element_type == "trafo" else "-"
        color = COLORS["red"] if row.branch_id == outaged_branch_id else COLORS["gray"]
        width = 3.2 if row.branch_id == outaged_branch_id else 1.5
        x = [BUS_POSITIONS[row.from_bus][0], BUS_POSITIONS[row.to_bus][0]]
        y = [BUS_POSITIONS[row.from_bus][1], BUS_POSITIONS[row.to_bus][1]]
        ax.plot(x, y, style, color=color, lw=width, alpha=0.9, zorder=1)

    bus_map = buses.set_index("bus_number")
    v = np.array([bus_map.at[b, "vm_pu"] if b in bus_map.index else np.nan for b in graph.nodes])
    colors = ["#B0BEC5" if b in unsupplied_bus_numbers else val for b, val in zip(graph.nodes, v)]
    numeric_mask = [not isinstance(c, str) for c in colors]
    numeric_values = [c if not isinstance(c, str) else 1.0 for c in colors]
    nodes = nx.draw_networkx_nodes(
        graph, BUS_POSITIONS, node_color=numeric_values, cmap="RdYlGn", vmin=0.94, vmax=1.10,
        node_size=620, edgecolors=COLORS["navy"], linewidths=1.3, ax=ax
    )
    if any(not flag for flag in numeric_mask):
        nx.draw_networkx_nodes(
            graph, BUS_POSITIONS,
            nodelist=[b for b in graph.nodes if b in unsupplied_bus_numbers],
            node_color="#B0BEC5", node_size=620, edgecolors=COLORS["red"], linewidths=2, ax=ax
        )
    nx.draw_networkx_labels(graph, BUS_POSITIONS, labels={b: str(b) for b in graph.nodes},
                            font_weight="bold", font_color=COLORS["navy"], ax=ax)
    sm = plt.cm.ScalarMappable(cmap="RdYlGn", norm=Normalize(0.94, 1.10))
    sm.set_array([])
    fig.colorbar(sm, ax=ax, fraction=0.035, pad=0.02, label="Voltage (p.u.)")
    ax.set_title(title)
    ax.text(0.01, 0.01, "Solid: line   Dashed: transformer   Red: outaged branch",
            transform=ax.transAxes, fontsize=9, color=COLORS["gray"])
    ax.axis("off")
    _save(fig, path)


def create_all_charts(base: dict, outages: dict, comparison: pd.DataFrame, output_dir: Path):
    output_dir.mkdir(parents=True, exist_ok=True)
    plot_voltage_profile(base["buses"], output_dir / "base_voltage_profile.png")
    plot_branch_loading(base["branches"], output_dir / "base_branch_loading.png")
    plot_contingency_ranking(outages["summary"], output_dir / "contingency_severity_top10.png")
    plot_dc_ac_comparison(comparison, output_dir / "dc_ac_comparison.png")
    plot_network(base["net"], base["buses"], output_dir / "network_base.png", title="IEEE 14-Bus Base Case")
    worst = outages["summary"].iloc[0]
    unsupplied = {int(x) for x in str(worst.unsupplied_buses).split(",") if x}
    plot_network(
        base["net"], base["buses"], output_dir / "network_most_severe.png",
        title=f"Most Severe Contingency: {worst.branch_name}",
        outaged_branch_id=worst.branch_id,
        unsupplied_bus_numbers=unsupplied,
    )

