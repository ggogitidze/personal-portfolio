from __future__ import annotations

import math
from dataclasses import asdict

import numpy as np
import pandas as pd
import pandapower.networks as pn

from .config import StudyConfig


def load_ieee14():
    """Return pandapower's MATPOWER-derived IEEE 14-bus case with stable labels."""
    net = pn.case14()
    net.name = "IEEE 14-Bus N-1 Reliability Study"
    net.bus["bus_number"] = net.bus["name"].astype(int)

    for idx, row in net.line.iterrows():
        f = int(net.bus.at[row.from_bus, "bus_number"])
        t = int(net.bus.at[row.to_bus, "bus_number"])
        net.line.at[idx, "name"] = f"L{idx + 1:02d} {f}-{t}"
    for idx, row in net.trafo.iterrows():
        f = int(net.bus.at[row.hv_bus, "bus_number"])
        t = int(net.bus.at[row.lv_bus, "bus_number"])
        net.trafo.at[idx, "name"] = f"T{idx + 1:02d} {f}-{t}"
    return net


def bus_type_table(net) -> pd.DataFrame:
    """Classify buses by power-flow controls, not by original case integer codes."""
    slack_buses = set(net.ext_grid.loc[net.ext_grid.in_service, "bus"].astype(int))
    pv_buses = set(net.gen.loc[net.gen.in_service, "bus"].astype(int)) - slack_buses
    records = []
    for idx, bus in net.bus.iterrows():
        bus_type = "Slack" if idx in slack_buses else ("PV" if idx in pv_buses else "PQ")
        records.append(
            {
                "bus_index": int(idx),
                "bus_number": int(bus.bus_number),
                "bus_type": bus_type,
                "vn_kv": float(bus.vn_kv),
                "min_vm_pu": float(bus.min_vm_pu),
                "max_vm_pu": float(bus.max_vm_pu),
            }
        )
    return pd.DataFrame(records)


def branch_catalog(net) -> pd.DataFrame:
    records: list[dict] = []
    for idx, row in net.line.iterrows():
        records.append(
            {
                "branch_id": f"line_{idx}",
                "element_type": "line",
                "element_index": int(idx),
                "name": row["name"],
                "from_bus_index": int(row.from_bus),
                "to_bus_index": int(row.to_bus),
                "from_bus": int(net.bus.at[row.from_bus, "bus_number"]),
                "to_bus": int(net.bus.at[row.to_bus, "bus_number"]),
            }
        )
    for idx, row in net.trafo.iterrows():
        records.append(
            {
                "branch_id": f"trafo_{idx}",
                "element_type": "trafo",
                "element_index": int(idx),
                "name": row["name"],
                "from_bus_index": int(row.hv_bus),
                "to_bus_index": int(row.lv_bus),
                "from_bus": int(net.bus.at[row.hv_bus, "bus_number"]),
                "to_bus": int(net.bus.at[row.lv_bus, "bus_number"]),
            }
        )
    catalog = pd.DataFrame(records)
    catalog["ppc_order"] = np.arange(len(catalog), dtype=int)
    return catalog


def _round_up(value: float, increment: float) -> float:
    return increment * math.ceil(value / increment)


def build_study_ratings(branch_results: pd.DataFrame, config: StudyConfig) -> pd.DataFrame:
    """Create explicit scenario ratings because canonical case14 has no rateA ratings."""
    ratings = branch_results[["branch_id", "base_mva"]].copy()
    ratings["rating_mva"] = ratings["base_mva"].map(
        lambda s: _round_up(
            max(config.rating_floor_mva, config.rating_headroom * float(s)),
            config.rating_rounding_mva,
        )
    )
    ratings["rating_basis"] = (
        f"synthetic: ceil(max({config.rating_floor_mva:.0f}, "
        f"{config.rating_headroom:.2f} x base_MVA) / {config.rating_rounding_mva:.0f})"
    )
    return ratings


def study_metadata(net, config: StudyConfig) -> dict:
    return {
        "case": "IEEE 14-bus (pandapower case14, converted from MATPOWER case14)",
        "buses": int(len(net.bus)),
        "generators_including_slack": int(len(net.gen) + len(net.ext_grid)),
        "loads": int(len(net.load)),
        "lines": int(len(net.line)),
        "transformers": int(len(net.trafo)),
        "contingencies": int(len(net.line) + len(net.trafo)),
        "config": asdict(config),
    }

