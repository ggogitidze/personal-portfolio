from copy import deepcopy

import numpy as np
import pandas as pd
import pytest

from gridrisk import StudyConfig, load_ieee14, run_all_contingencies, run_base_case
from gridrisk.contingency import rank_contingencies
from gridrisk.dc_screening import build_dc_factors
from gridrisk.severity import thermal_exceedance_sum
from pandapower.pypower.makeLODF import makeLODF
from pandapower.pypower.makePTDF import makePTDF


@pytest.fixture(scope="module")
def study():
    config = StudyConfig()
    base = run_base_case(load_ieee14(), config)
    outages = run_all_contingencies(base, config)
    return config, base, outages


def test_base_case_converges_and_balances(study):
    _, base, _ = study
    assert base["net"].converged
    assert base["validation"]["fdbx_converged"]
    assert abs(base["balance"]["balance_residual_mw"]) < 1e-6


def test_expected_contingency_count_and_no_missing_ids(study):
    _, base, outages = study
    expected = len(base["net"].line) + len(base["net"].trafo)
    assert expected == 20
    assert len(outages["summary"]) == expected
    assert outages["summary"].branch_id.notna().all()
    assert outages["summary"].branch_id.nunique() == expected


def test_voltage_limit_logic(study):
    _, base, _ = study
    b = base["buses"].set_index("bus_number")
    assert not bool(b.at[1, "voltage_violation"])  # equality with upper limit is allowed
    assert bool(b.at[8, "voltage_violation"])
    assert b.at[8, "v_upper_breach_pu"] == pytest.approx(0.03, abs=1e-9)


def test_thermal_limit_logic_is_strictly_greater_than_100():
    branches = pd.DataFrame({"loading_percent": [99.9, 100.0, 100.1, 117.0]})
    assert thermal_exceedance_sum(branches, 100.0) == pytest.approx(17.1)
    assert int((branches.loading_percent > 100.0).sum()) == 2


def test_ranking_is_reproducible(study):
    _, _, outages = study
    original = outages["summary"][["branch_id", "severity_score"]].copy()
    shuffled = original.sample(frac=1.0, random_state=14).reset_index(drop=True)
    assert rank_contingencies(original).branch_id.tolist() == rank_contingencies(shuffled).branch_id.tolist()


def test_lodf_bridge_and_diagonal(study):
    _, base, _ = study
    factors = build_dc_factors(base["net"])
    assert factors["bridge_mask"].sum() == 1
    for k in np.where(~factors["bridge_mask"])[0]:
        assert factors["lodf"][k, k] == pytest.approx(-1.0)


def test_dc_factors_match_pypower_reference(study):
    _, base, _ = study
    factors = build_dc_factors(base["net"])
    ppc = base["net"]._ppc
    reference_ptdf = makePTDF(ppc["baseMVA"], ppc["bus"], ppc["branch"])
    with np.errstate(divide="ignore", invalid="ignore"):
        reference_lodf = makeLODF(ppc["branch"], reference_ptdf)
    finite = np.isfinite(reference_lodf) & np.isfinite(factors["lodf"])
    assert np.max(np.abs(reference_ptdf - factors["ptdf"])) < 1e-12
    assert np.max(np.abs(reference_lodf[finite] - factors["lodf"][finite])) < 1e-12
