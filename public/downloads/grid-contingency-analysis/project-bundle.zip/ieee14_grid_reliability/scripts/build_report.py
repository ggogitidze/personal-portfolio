from pathlib import Path
import textwrap

import pandas as pd
from reportlab.lib import colors
from reportlab.lib.pagesizes import letter
from reportlab.lib.utils import ImageReader
from reportlab.pdfgen import canvas


ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "docs" / "IEEE14_Technical_Report.pdf"
OUT.parent.mkdir(parents=True, exist_ok=True)
summary = pd.read_csv(ROOT / "results" / "contingency_results.csv")

W, H = letter
NAVY = colors.HexColor("#17324D")
BLUE = colors.HexColor("#1976D2")
TEAL = colors.HexColor("#00897B")
LIGHT = colors.HexColor("#EEF3F7")
GRAY = colors.HexColor("#455A64")


def wrapped(c, text, x, y, width_chars=105, size=8.4, leading=10.5, color=GRAY):
    c.setFillColor(color)
    c.setFont("Helvetica", size)
    for paragraph in text.split("\n"):
        lines = textwrap.wrap(paragraph, width=width_chars) or [""]
        for line in lines:
            c.drawString(x, y, line)
            y -= leading
        y -= 2
    return y


def heading(c, text, x, y):
    c.setFillColor(NAVY)
    c.setFont("Helvetica-Bold", 11.5)
    c.drawString(x, y, text)
    return y - 15


def footer(c, page):
    c.setStrokeColor(colors.HexColor("#CFD8DC"))
    c.line(38, 31, W - 38, 31)
    c.setFillColor(GRAY)
    c.setFont("Helvetica", 7)
    c.drawString(38, 20, "IEEE 14-Bus N-1 Contingency Analysis | Portfolio technical brief")
    c.drawRightString(W - 38, 20, f"Page {page} of 2")


c = canvas.Canvas(str(OUT), pagesize=letter)
c.setTitle("IEEE 14-Bus N-1 Contingency Analysis and Grid-Risk Dashboard")
c.setAuthor("Giorgi Gogitidze")
c.setSubject("AC contingency analysis, grid reliability, and DC/LODF screening")

# Page 1
c.setFillColor(TEAL)
c.setFont("Helvetica-Bold", 8)
c.drawString(38, 758, "POWER SYSTEM RELIABILITY STUDY")
c.setFillColor(NAVY)
c.setFont("Helvetica-Bold", 19)
c.drawString(38, 731, "IEEE 14-Bus N-1 Contingency Analysis")
c.setFont("Helvetica-Bold", 15)
c.drawString(38, 710, "and Grid-Risk Dashboard")
c.setFillColor(GRAY)
c.setFont("Helvetica", 8)
c.drawString(38, 694, "Giorgi Gogitidze | M.S. Electrical Engineering / B.S. Computer Science")

y = heading(c, "Objective and model", 38, 670)
y = wrapped(c, "A reproducible Python/pandapower workflow solves the 14-bus, 20-branch benchmark; validates the AC base case; trips every line and transformer; detects islanding; checks voltage and scenario thermal criteria; and ranks events with a traceable score. The network supplies 259.0 MW through 15 lines and five transformers.", 38, y)

# metric cards
card_y = y - 2
metrics = [("Base losses", "13.393 MW"), ("Outages", "20"), ("AC converged", "19"), ("Islands", "1")]
for i, (label, value) in enumerate(metrics):
    x = 38 + i * 134
    c.setFillColor(LIGHT)
    c.roundRect(x, card_y - 42, 124, 40, 5, fill=1, stroke=0)
    c.setFillColor(BLUE)
    c.setFont("Helvetica-Bold", 13)
    c.drawString(x + 8, card_y - 19, value)
    c.setFillColor(GRAY)
    c.setFont("Helvetica", 7.2)
    c.drawString(x + 8, card_y - 33, label)
y = card_y - 58

y = heading(c, "Validation gate", 38, y)
y = wrapped(c, "Newton-Raphson and fast-decoupled AC both converged. Maximum voltage disagreement was 7.12e-10 p.u.; maximum angle disagreement was 3.74e-08 degree. Generation - demand - real branch losses closed to 4.97e-14 MW. The outage engine runs only after these checks pass.", 38, y)
y = heading(c, "Criteria and transparent score", 38, y)
y = wrapped(c, "Voltage uses the case limits (0.94-1.06 p.u.). The source case supplies no branch rateA values, so thermal percentages use a disclosed stress-test rating: ceil-to-5(max(40 MVA, 1.25 x base terminal MVA)). These are not utility equipment limits.", 38, y)
y = wrapped(c, "Severity = 1000(islanding) + 750(no valid full-system AC solution) + 100(unsupplied-load fraction) + 1000(total voltage breach p.u.) + summed overload percentage points + 0.05(positive loss increase percent).", 38, y)

y = heading(c, "Highest-ranked outages", 38, y)
cols = [38, 78, 163, 245, 333, 421, 510]
headers = ["Rank", "Outage", "Status", "Max loading", "V violations", "Loss MW", "Score"]
c.setFillColor(NAVY)
c.rect(38, y - 14, 536, 16, fill=1, stroke=0)
c.setFillColor(colors.white)
c.setFont("Helvetica-Bold", 6.8)
for x, h in zip(cols, headers):
    c.drawString(x + 3, y - 9, h)
y -= 15
for idx, r in summary.head(5).iterrows():
    if idx % 2 == 1:
        c.setFillColor(LIGHT)
        c.rect(38, y - 13, 536, 15, fill=1, stroke=0)
    c.setFillColor(GRAY)
    c.setFont("Helvetica", 6.8)
    values = [str(int(r["rank"])), r.branch_name, "Island" if r.islanded else "Solved", "-" if pd.isna(r.max_loading_percent) else f"{r.max_loading_percent:.1f}%", str(int(r.voltage_violation_count)), "-" if pd.isna(r.losses_mw) else f"{r.losses_mw:.2f}", f"{r.severity_score:.1f}"]
    for x, value in zip(cols, values):
        c.drawString(x + 3, y - 8, value)
    y -= 15

img = ImageReader(str(ROOT / "results" / "figures" / "contingency_severity_top10.png"))
c.drawImage(img, 80, 50, width=452, height=250, preserveAspectRatio=True, anchor="c")
footer(c, 1)
c.showPage()

# Page 2
c.setFillColor(TEAL)
c.setFont("Helvetica-Bold", 8)
c.drawString(38, 758, "SCREENING, VALIDATION, AND INTERPRETATION")
c.setFillColor(NAVY)
c.setFont("Helvetica-Bold", 19)
c.drawString(38, 731, "DC/LODF Screening After Full AC Analysis")
y = 706
y = wrapped(c, "The lossless DC model forms PTDFs from the reduced nodal susceptance matrix. For outage k, LODF[m,k] = h[m,k] / (1-h[k,k]) and F'm = Fm + LODF[m,k]Fk. Transformer 7-8 is a bridge, producing a singular denominator; the screen marks it unscreenable rather than returning a false estimate.", 38, y)

img = ImageReader(str(ROOT / "results" / "figures" / "dc_ac_comparison.png"))
c.drawImage(img, 50, 360, width=300, height=285, preserveAspectRatio=True, anchor="c")

c.setFillColor(LIGHT)
c.roundRect(370, 458, 198, 174, 7, fill=1, stroke=0)
c.setFillColor(NAVY)
c.setFont("Helvetica-Bold", 11)
c.drawString(383, 611, "Selected-case comparison")
text_y = 591
text_y = wrapped(c, "Five highest-ranked connected outages\nOverall MAE: 1.174 MW\nPTDF reference difference: 2.0e-15\nLODF reference difference: 6.5e-15", 383, text_y, width_chars=31, size=8.2, leading=13)
text_y = wrapped(c, "The largest discrepancy occurs after the heavy line 1-2 outage, where AC loss and voltage effects matter more.", 383, text_y - 3, width_chars=33, size=7.7, leading=10)

y = 342
y = heading(c, "Where the approximation succeeds and fails", 38, y)
y = wrapped(c, "DC/LODF efficiently estimates active-flow redistribution for connected, moderate-angle cases. It cannot assess reactive power, voltage limits, real losses, generator Q limits, nonlinear convergence, or valid behavior after islanding. Full AC results remain authoritative.", 38, y)
y = heading(c, "Verification", 38, y)
y = wrapped(c, "Seven automated tests verify base convergence and MW balance, exactly 20 unique contingencies, no missing IDs, voltage/thermal boundary logic, deterministic ranking, bridge handling and LODF diagonals, and agreement between the independent PTDF/LODF implementation and PYPOWER.", 38, y)
y = heading(c, "Limitations and next steps", 38, y)
y = wrapped(c, "Replace synthetic ratings with normal/emergency utility ratings; reconcile voltage criteria with PV setpoints; enforce generator reactive limits and PV-to-PQ switching; add seasonal operating cases, remedial actions, and production-tool benchmarking. This teaching model supports method demonstration, not grid operation.", 38, y)
y = heading(c, "Primary references", 38, y)
y = wrapped(c, "MATPOWER case14: matpower.org/docs/ref/matpower5.0/case14.html\nMATPOWER PTDF/LODF: matpower.org/documentation/ref-manual/legacy/functions/makePTDF.html and makeLODF.html\nPandapower: pandapower.readthedocs.io", 38, y, size=7.4, leading=9)
footer(c, 2)
c.save()
print(OUT)
