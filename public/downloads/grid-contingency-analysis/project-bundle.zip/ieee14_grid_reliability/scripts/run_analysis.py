from __future__ import annotations

import json
import sys
from pathlib import Path

import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from gridrisk import StudyConfig, load_ieee14, run_all_contingencies, run_base_case
from gridrisk.dc_screening import build_dc_factors, compare_dc_ac, screen_outages
from gridrisk.network import bus_type_table, study_metadata
from gridrisk.reporting import write_dashboard, write_json, write_portfolio_page
from gridrisk.visualization import create_all_charts
from pandapower.pypower.makeLODF import makeLODF as pypower_make_lodf
from pandapower.pypower.makePTDF import makePTDF as pypower_make_ptdf


def main():
    config = StudyConfig()
    source_net = load_ieee14()
    base = run_base_case(source_net, config)
    outages = run_all_contingencies(base, config)

    factors = build_dc_factors(base["net"])
    ppc = base["net"]._ppc
    reference_ptdf = pypower_make_ptdf(ppc["baseMVA"], ppc["bus"], ppc["branch"])
    with np.errstate(divide="ignore", invalid="ignore"):
        reference_lodf = pypower_make_lodf(ppc["branch"], reference_ptdf)
    finite_lodf = np.isfinite(reference_lodf) & np.isfinite(factors["lodf"])
    ptdf_max_difference = float(np.max(np.abs(reference_ptdf - factors["ptdf"])))
    lodf_max_difference = float(
        np.max(np.abs(reference_lodf[finite_lodf] - factors["lodf"][finite_lodf]))
    )
    dc_screen = screen_outages(base["branches"], factors)
    selected = outages["summary"].query("converged").head(5).branch_id.tolist()
    comparison = compare_dc_ac(
        base["branches"], factors, outages["branch_results"], selected
    )

    results = ROOT / "results"
    results.mkdir(parents=True, exist_ok=True)
    base["buses"].to_csv(results / "base_case_buses.csv", index=False)
    base["generators"].to_csv(results / "base_case_generators.csv", index=False)
    base["branches"].to_csv(results / "base_case_branches.csv", index=False)
    outages["summary"].to_csv(results / "contingency_results.csv", index=False)
    outages["bus_results"].to_csv(results / "contingency_bus_results.csv", index=False)
    outages["branch_results"].to_csv(results / "contingency_branch_results.csv", index=False)
    dc_screen.to_csv(results / "dc_lodf_screening.csv", index=False)
    comparison.to_csv(results / "dc_ac_comparison.csv", index=False)
    pd.DataFrame(factors["ptdf"]).to_csv(results / "ptdf_matrix.csv", index=False)
    pd.DataFrame(factors["lodf"]).to_csv(results / "lodf_matrix.csv", index=False)

    comparison_summary = (
        comparison.groupby("contingency_id")
        .agg(
            mean_absolute_error_mw=("absolute_error_mw", "mean"),
            max_absolute_error_mw=("absolute_error_mw", "max"),
            mean_absolute_flow_error_mw=("absolute_flow_error_mw", "mean"),
        )
        .reset_index()
    )
    comparison_summary.to_csv(results / "dc_ac_comparison_summary.csv", index=False)

    validation_payload = {
        "metadata": study_metadata(base["net"], config),
        "base_case_validation": base["validation"],
        "active_power_balance": base["balance"],
        "contingency_checks": {
            "expected_count": int(len(base["branches"])),
            "actual_count": int(len(outages["summary"])),
            "missing_branch_ids": int(outages["summary"].branch_id.isna().sum()),
            "unique_branch_ids": int(outages["summary"].branch_id.nunique()),
        },
        "selected_dc_ac_cases": selected,
        "dc_ac_overall_mae_mw": float(comparison.absolute_error_mw.mean()),
        "dc_factor_crosscheck": {
            "ptdf_max_abs_difference": ptdf_max_difference,
            "lodf_max_abs_difference_non_bridge": lodf_max_difference,
            "pass": bool(ptdf_max_difference < 1e-12 and lodf_max_difference < 1e-12),
        },
    }
    write_json(validation_payload, results / "validation_summary.json")
    create_all_charts(base, outages, comparison, results / "figures")
    write_dashboard(base, outages, dc_screen, ROOT / "dashboard" / "grid_risk_dashboard.html")
    write_portfolio_page(base, outages, comparison, ROOT)

    print(json.dumps(validation_payload, indent=2))
    print("\nTop five contingencies:")
    print(outages["summary"].head(5)[["rank", "branch_name", "severity_score", "converged", "islanded"]].to_string(index=False))


if __name__ == "__main__":
    main()
