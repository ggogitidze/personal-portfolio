from pathlib import Path
import base64
import contextlib
import io

import nbformat as nbf
from nbclient import NotebookClient


ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "notebooks" / "01_ieee14_contingency_demo.ipynb"
OUT.parent.mkdir(parents=True, exist_ok=True)

nb = nbf.v4.new_notebook()
nb["metadata"]["kernelspec"] = {
    "display_name": "Python 3", "language": "python", "name": "python3"
}
nb["metadata"]["language_info"] = {"name": "python", "version": "3.12"}


def md(text):
    return nbf.v4.new_markdown_cell(text)


def code(text):
    return nbf.v4.new_code_cell(text)


nb["cells"] = [
    md("""# IEEE 14-Bus N-1 Contingency Analysis

This executed notebook is the guided demonstration layer. Reusable implementation lives in `src/gridrisk`; the notebook calls those functions rather than hiding engineering logic in one long file.

**Learning goals:** identify slack/PV/PQ buses, validate a full AC base case, inspect losses/loading, run every single-branch outage, understand severity, and compare DC/LODF screening with AC results."""),
    code("""from pathlib import Path
import sys
import pandas as pd
from IPython.display import display, Image

ROOT = Path.cwd()
if not (ROOT / 'src').exists():
    ROOT = ROOT.parent
sys.path.insert(0, str(ROOT / 'src'))

from gridrisk import StudyConfig, load_ieee14, run_base_case, run_all_contingencies
from gridrisk.network import bus_type_table
from gridrisk.dc_screening import build_dc_factors, screen_outages, compare_dc_ac
pd.set_option('display.max_columns', 50)"""),
    md("""## 1. Load the system and identify bus types

- **Slack:** specified voltage magnitude/angle; solved P/Q closes system balance.
- **PV:** specified active power and voltage magnitude; solved Q/angle.
- **PQ:** specified active/reactive power; solved voltage magnitude/angle."""),
    code("""config = StudyConfig()
net = load_ieee14()
print(net)
display(bus_type_table(net))"""),
    md("""## 2. Solve and validate the AC base case

The Newton-Raphson solution is checked against fast-decoupled AC. The MW balance enforces `generation - demand - real branch losses = 0`. No outage study is accepted if this gate fails."""),
    code("""base = run_base_case(net, config)
display(pd.Series(base['validation'], name='value').to_frame())
display(pd.Series(base['balance'], name='MW').to_frame())"""),
    code("""display(base['buses'][['bus_number','bus_type','vm_pu','va_degree','min_vm_pu','max_vm_pu','voltage_violation']])
display(base['generators'])
display(base['branches'][['branch_id','name','p_from_mw','q_from_mvar','p_loss_mw','base_mva','rating_mva','loading_percent']])"""),
    md("""### What to notice

The source case's 1.06 p.u. upper limit is lower than some PV setpoints, so buses 6, 7, and 8 are flagged. Thermal ratings are synthetic study limits because canonical case14 does not provide `rateA`; see `data/DATA_DESCRIPTION.md`."""),
    md("""## 3. Run all N-1 branch outages

For each branch, the code checks graph connectivity before solving AC. A component without the slack is unsupplied. Connected cases are scored from islanding, non-convergence, unsupplied load, voltage breach, thermal exceedance, and positive loss increase."""),
    code("""outages = run_all_contingencies(base, config)
cols = ['rank','branch_name','converged','islanded','unsupplied_buses','min_vm_pu','max_vm_pu','max_loading_percent','thermal_violation_count','severity_score']
display(outages['summary'][cols])"""),
    code("""display(outages['summary'].head(5)[['rank','branch_name','severity_score','islanding_component','nonconvergence_component','unsupplied_component','voltage_component','thermal_component','loss_component']])"""),
    md("""## 4. PTDF and LODF screening

PTDF maps balanced bus transfers to active branch-flow changes. For outage `k`, LODF estimates `F'_m = F_m + LODF[m,k] F_k`. A bridge creates a zero denominator and is intentionally unscreenable."""),
    code("""factors = build_dc_factors(base['net'])
dc_screen = screen_outages(base['branches'], factors)
display(dc_screen)
display(factors['catalog'].loc[factors['bridge_mask'], ['branch_id','name']])"""),
    code("""selected = outages['summary'].query('converged').head(5).branch_id.tolist()
comparison = compare_dc_ac(base['branches'], factors, outages['branch_results'], selected)
display(comparison.groupby('contingency_id').agg(mean_absolute_error_mw=('absolute_error_mw','mean'), max_absolute_error_mw=('absolute_error_mw','max')))
print('Overall selected-case MAE:', comparison.absolute_error_mw.mean(), 'MW')"""),
    md("""## 5. Interpretation

DC screening is strong for connected active-flow redistribution, but cannot determine reactive sufficiency, voltage breaches, losses, or nonlinear convergence. Direct AC analysis remains authoritative; PTDF/LODF is the acceleration and explanation layer."""),
    code("""for name in ['network_base.png','contingency_severity_top10.png','dc_ac_comparison.png']:
    display(Image(filename=str(ROOT / 'results' / 'figures' / name), width=760))"""),
    md("""## Limitations and next steps

Replace synthetic ratings with utility ratings; confirm voltage criteria; enforce generator Q limits and PV-to-PQ switching; add operating scenarios, emergency criteria, remedial actions, and production-tool benchmarking. Do not use this teaching case for operating decisions."""),
]

nbf.write(nb, OUT)
try:
    client = NotebookClient(
        nb, timeout=240, kernel_name="python3", resources={"metadata": {"path": str(ROOT)}}
    )
    client.execute()
except Exception as exc:
    # Managed containers may block the local TCP sockets used by Jupyter kernels.
    # Execute the same cells in-process and store standards-compliant outputs.
    namespace = {"__name__": "__main__"}
    execution_count = 1
    for cell in nb.cells:
        if cell.cell_type != "code":
            continue
        outputs = []

        def captured_display(obj):
            if hasattr(obj, "filename") and getattr(obj, "filename", None):
                image_path = Path(obj.filename)
                if image_path.exists():
                    payload = base64.b64encode(image_path.read_bytes()).decode("ascii")
                    outputs.append(nbf.v4.new_output("display_data", data={"image/png": payload}))
                    return
            if hasattr(obj, "to_html"):
                outputs.append(
                    nbf.v4.new_output(
                        "display_data",
                        data={"text/plain": repr(obj), "text/html": obj.to_html()},
                    )
                )
            else:
                outputs.append(nbf.v4.new_output("display_data", data={"text/plain": repr(obj)}))

        stream = io.StringIO()
        try:
            with contextlib.redirect_stdout(stream):
                exec(compile(cell.source, "<notebook-cell>", "exec"), namespace)
            namespace["display"] = captured_display
            text = stream.getvalue()
            if text:
                outputs.insert(0, nbf.v4.new_output("stream", name="stdout", text=text))
        except Exception as cell_exc:
            outputs.append(
                nbf.v4.new_output(
                    "error",
                    ename=type(cell_exc).__name__,
                    evalue=str(cell_exc),
                    traceback=[f"{type(cell_exc).__name__}: {cell_exc}"],
                )
            )
            raise
        cell.outputs = outputs
        cell.execution_count = execution_count
        execution_count += 1
    nb.metadata["execution_fallback"] = (
        f"Executed in-process because a managed-environment Jupyter kernel could not start: {type(exc).__name__}"
    )
nbf.write(nb, OUT)
print(OUT)
