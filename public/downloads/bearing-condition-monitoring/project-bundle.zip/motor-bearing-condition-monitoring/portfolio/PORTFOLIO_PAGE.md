# Portfolio-page package

## Hero image recommendation

Use `docs/figures/07_portfolio_hero.png`: a clean normal-versus-outer-race envelope-spectrum comparison at 3 HP. It communicates the central engineering insight immediately: demodulation converts impact-excited resonance into interpretable BPFO harmonics.

## 40-word summary

Built a physics-grounded Python pipeline that diagnoses seeded motor-bearing faults from CWRU vibration data. It combines calibrated FFTs, bearing kinematics, envelope demodulation, statistical features, cross-load validation, automated tests, and a leakage-aware classifier while clearly documenting deployment limitations and sensor considerations.

## Problem

Detect and interpret rolling-element bearing faults from accelerometer data without treating condition monitoring as a black-box classification problem. The design must distinguish normal, inner-race, outer-race, and ball conditions while remaining explainable across changes in motor load and speed.

## Method

I selected eight official CWRU drive-end records covering four conditions at 0 and 3 HP. The pipeline verifies downloads, removes DC offset, standardizes signals to 12 kHz, calculates five time-domain indicators, applies a correctly scaled Hann-windowed FFT, predicts fault frequencies from bearing geometry and measured RPM, and performs fixed-band Hilbert-envelope analysis. A cross-load experiment and a simple logistic-regression baseline test robustness only after physical interpretation.

## Key equations

\[
x_c[n]=x[n]-\bar{x},\qquad
x_{\mathrm{RMS}}=\sqrt{\frac{1}{N}\sum_{n=0}^{N-1}x_c^2[n]},\qquad
\Delta f=\frac{f_s}{N}=1\ \mathrm{Hz}
\]

\[
\mathrm{BPFO}=\frac n2 f_r\left(1-\frac dD\cos\theta\right),\qquad
\mathrm{BPFI}=\frac n2 f_r\left(1+\frac dD\cos\theta\right)
\]

\[
z[n]=x_{\mathrm{BP}}[n]+j\mathcal{H}\{x_{\mathrm{BP}}[n]\},\qquad e[n]=|z[n]|
\]

## Results

- Median BPFO envelope prominence: 40.0 dB at 0 HP and 36.1 dB at 3 HP.
- Median BPFI envelope prominence: 34.8 dB at 0 HP and 35.0 dB at 3 HP.
- Median BSF envelope prominence: 5.8 dB at 0 HP and 9.9 dB at 3 HP.
- Exploratory bidirectional cross-load logistic regression: 82.5% over 40 held-out windows; reported as a limited comparison, not production performance.

## Engineering interpretation

The race-fault repetition rates remain prominent despite the load-dependent speed shift, showing why measured RPM and kinematic overlays matter. The weaker ball-fault evidence demonstrates a realistic diagnostic hierarchy rather than a uniformly easy benchmark. Statistical features flag impulsiveness; envelope-frequency evidence identifies the likely component.

## Limitations

CWRU uses seeded laboratory faults and one recording per class/load in this subset. Normal and fault files have different source rates. Public pages do not establish absolute acceleration calibration. Real deployment must address mounting, orientation, variable speed/load, sensor drift, coexisting faults, thresholds, persistence, and maintenance confirmation.

## Download links

- [Executed demonstration notebook](../notebooks/Motor_Bearing_Condition_Monitoring.ipynb)
- [Feature results CSV](../results/feature_results.csv)
- [Two-page technical report](../docs/technical_report.pdf)
- [Complete reproducible project archive](../../Motor_Bearing_Condition_Monitoring_MVP.zip)

## Two resume bullets

- Built a reproducible Python/SciPy vibration-diagnostics pipeline for eight CWRU motor-bearing records, implementing amplitude-correct FFTs, bearing kinematics, 2-5 kHz Hilbert-envelope demodulation, five condition indicators, checksum-verified acquisition, and automated numerical tests.
- Validated fault evidence across 0 and 3 HP: measured 35-40 dB median envelope prominence for race-fault frequencies and evaluated a leakage-aware cross-load classifier (82.5% exploratory accuracy), with explicit laboratory-to-field deployment limitations.

## 30-second recruiter explanation

I built a motor-bearing condition-monitoring project that connects mechanical fault physics to Python signal processing. Instead of starting with machine learning, I calculated the expected bearing frequencies from geometry and measured speed, then used a calibrated FFT and Hilbert-envelope analysis to reveal impact repetition rates. I tested the method across two motor loads, automated data verification and unit tests, and added a small classifier only as a clearly limited comparison. The result shows both EE signal-processing judgment and software reliability.

## Five interviewer questions and answers

### 1. Why was the raw FFT not enough?

A defect creates brief impacts that excite a higher-frequency structural resonance. The raw FFT often shows resonance energy and unrelated machine components rather than a strong line at the low defect repetition rate. Bandpass filtering and Hilbert-envelope demodulation recover the amplitude-modulation frequency associated with BPFO, BPFI, or BSF.

### 2. How did you scale the single-sided FFT correctly?

I de-meaned the signal, applied a periodic Hann window, divided the RFFT magnitude by the window's coherent sum, and doubled all positive-frequency bins except DC and the Nyquist bin. A unit test uses a bin-centered sinusoid to verify both peak location and recovered amplitude.

### 3. Why use one-second windows?

At 12 kHz, one second gives 12,000 samples and exactly 1 Hz bin spacing, fine enough to separate the roughly 100-160 Hz bearing families. It also gives multiple non-overlapping windows per record for stability checks. I do not treat those windows as independent machines.

### 4. How did you avoid machine-learning leakage?

I did not randomly split adjacent windows from the same record. The model trains on all 0 HP source records and tests on separate 3 HP records, then reverses direction. This is still a small benchmark, but it avoids the most direct same-record leakage.

### 5. What would you change for a factory deployment?

I would establish per-asset baselines; record tachometer, load, and process state; validate sensor placement and anti-alias filtering; use order tracking for variable speed; implement persistent alarms and sensor-health checks; and correlate detections with inspections. Thresholds would be commissioned from field data rather than transferred directly from CWRU.
