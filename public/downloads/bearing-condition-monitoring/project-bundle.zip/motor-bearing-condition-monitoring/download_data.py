#!/usr/bin/env python3
"""Download and SHA-256 verify the eight-file CWRU MVP subset."""

from __future__ import annotations

import argparse
import hashlib
from pathlib import Path
from urllib.request import Request, urlopen


BASE = "https://engineering.case.edu/sites/default/files"
FILES = {
    "97.mat": "16bf48babcf1c7ac224bc1a81cd9eafdb27e42d5cf559761907e067e8eeadf3c",
    "100.mat": "88a5990cb541320e91505a1d72139e1993500ffe6e292a451011667f4138ca78",
    "105.mat": "f80b0ea04fd06b372a0eaec7c056543ea37e4bb4727a5b173d2a5bacd2aa9cab",
    "108.mat": "d415f0e65128bfa0b118c2051c988fb0dc6ce3e4c8aa45fdc5ad1d0967462e7d",
    "118.mat": "b00628f8dd8d1d930af77fa465d1e5cdb385fe259489053f91f3680bda7f640e",
    "121.mat": "52f686e984ba8e9b04a047a57416271cdb322cee57ee105dce58926a24b966cb",
    "130.mat": "35a095307d0971477049b343a1b5981dde465a58fb7f233ad89b035068c1717d",
    "133.mat": "53f076cb0d905cf46bffaee7736abce8224ffed777deed03c0c863d762a90c71",
}


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", type=Path, default=Path(__file__).parent / "data" / "raw")
    parser.add_argument("--force", action="store_true")
    args = parser.parse_args()
    args.output.mkdir(parents=True, exist_ok=True)

    for filename, expected in FILES.items():
        target = args.output / filename
        if target.exists() and not args.force and sha256(target) == expected:
            print(f"verified {filename}")
            continue
        request = Request(f"{BASE}/{filename}", headers={"User-Agent": "cwru-bearing-portfolio/1.0"})
        with urlopen(request, timeout=120) as response, target.open("wb") as output:
            while block := response.read(1024 * 1024):
                output.write(block)
        actual = sha256(target)
        if actual != expected:
            target.unlink(missing_ok=True)
            raise RuntimeError(f"Checksum mismatch for {filename}: {actual}")
        print(f"downloaded and verified {filename}")


if __name__ == "__main__":
    main()

