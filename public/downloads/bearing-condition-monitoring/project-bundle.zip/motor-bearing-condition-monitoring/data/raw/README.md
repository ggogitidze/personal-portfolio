# Raw CWRU files

Run `python download_data.py` from the project root to populate this directory with the eight checksum-verified MATLAB records. Raw files are intentionally excluded from the portable project archive.

