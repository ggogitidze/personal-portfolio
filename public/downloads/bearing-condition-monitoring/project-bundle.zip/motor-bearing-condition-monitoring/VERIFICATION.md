# Verification record

Verified in the Work environment on 2026-09-22:

- Official eight-file CWRU subset downloaded and SHA-256 verified.
- End-to-end `run_analysis.py` completed without errors.
- 40 feature rows and seven PNG figures reproduced.
- 13 automated tests passed, covering selected record length, analysis sampling rate, offset removal, segmentation, FFT peak location and amplitude, Nyquist endpoint, and feature values.
- Every notebook code cell was exported in order and executed successfully in one shared Python process.
- Standard Jupyter kernel execution was attempted but the managed environment prohibited local kernel transport. The notebook remains normally executable on a laptop with Jupyter.
- `technical_report.pdf` contains exactly two US-letter pages and was rendered to PNG for visual inspection; title clipping, table-header contrast, and font kerning were corrected before packaging.

