# Data dictionary

## Selected records

All files come from the Case Western Reserve University Bearing Data Center. The project uses drive-end (`DE`) acceleration only. The public CWRU pages identify accelerometer channels but do not state an absolute calibration unit, so plots use **CWRU amplitude units** rather than claiming `g` or `m/s^2`.

| File | CWRU label | Condition | Fault diameter | Outer-race position | Load | Recorded RPM | Source rate | Analysis rate |
|---|---|---|---:|---|---:|---:|---:|---:|
| `97.mat` | Normal_0 | Normal | n/a | n/a | 0 HP | 1796 | 48 kHz | 12 kHz |
| `100.mat` | Normal_3 | Normal | n/a | n/a | 3 HP | 1725 | 48 kHz | 12 kHz |
| `105.mat` | IR007_0 | Inner race | 0.007 in | n/a | 0 HP | 1797 | 12 kHz | 12 kHz |
| `108.mat` | IR007_3 | Inner race | 0.007 in | n/a | 3 HP | 1721 | 12 kHz | 12 kHz |
| `118.mat` | B007_0 | Ball | 0.007 in | n/a | 0 HP | 1796 | 12 kHz | 12 kHz |
| `121.mat` | B007_3 | Ball | 0.007 in | n/a | 3 HP | 1722 | 12 kHz | 12 kHz |
| `130.mat` | OR007@6_0 | Outer race | 0.007 in | 6 o'clock/load-zone center | 0 HP | 1796 | 12 kHz | 12 kHz |
| `133.mat` | OR007@6_3 | Outer race | 0.007 in | 6 o'clock/load-zone center | 3 HP | 1725 | 12 kHz | 12 kHz |

Normal records are anti-alias downsampled from 48 kHz to 12 kHz using polyphase resampling. This standardization enables a shared frequency axis but does not erase the acquisition-domain difference; that remains a documented limitation.

## MATLAB variables

| Pattern | Meaning | Used? |
|---|---|---|
| `X###_DE_time` | Drive-end accelerometer time series | Yes |
| `X###_FE_time` | Fan-end accelerometer time series | No |
| `X###_BA_time` | Base accelerometer time series, when present | No |
| `X###RPM` | Measured motor speed in revolutions per minute | Yes |

## `results/feature_results.csv`

Each row represents one non-overlapping one-second window. Five windows are retained per record, yielding 40 rows.

| Column group | Unit / definition |
|---|---|
| `record_id`, `segment_index` | Source record and zero-based window number |
| `condition`, `load_hp` | Ground-truth seeded condition and operating load |
| `rpm` | Measured rev/min from the MAT file |
| `source_fs_hz`, `analysis_fs_hz` | Original and standardized sample rates in Hz |
| `rms`, `std`, `peak_to_peak` | CWRU amplitude units |
| `crest_factor`, `kurtosis` | Dimensionless; kurtosis uses Pearson convention (Gaussian = 3) |
| `shaft_hz`, `ftf_hz`, `bpfo_hz`, `bpfi_hz`, `bsf_hz` | Theoretical frequencies under ideal no-slip kinematics |
| `raw_*_prominence_db` | Raw-spectrum peak near theoretical frequency relative to a local median floor |
| `envelope_*_prominence_db` | Same evidence measure after 2-5 kHz bandpass and Hilbert demodulation |
| `diagnostic_frequency` | Expected kinematic family for the known seeded fault |
| `diagnostic_envelope_prominence_db` | Envelope evidence at that expected family |

