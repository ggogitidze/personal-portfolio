"""Generate the polished demonstration notebook from reproducible source text."""

from pathlib import Path

import nbformat as nbf


ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "notebooks" / "Motor_Bearing_Condition_Monitoring.ipynb"
nb = nbf.v4.new_notebook()
nb["metadata"] = {
    "kernelspec": {"display_name": "Python 3", "language": "python", "name": "python3"},
    "language_info": {"name": "python", "version": "3"},
}

cells = []
cells.append(nbf.v4.new_markdown_cell("""# Motor Bearing Condition Monitoring from Vibration Signals

**A physics-first CWRU case study**

This notebook explains why bearing faults create impulsive vibration, derives the expected kinematic frequencies, implements calibrated spectral and envelope analysis, and tests robustness across 0 and 3 HP. Machine learning appears only after the physical evidence is established."""))

cells.append(nbf.v4.new_markdown_cell(r"""## 1. Physical model: impacts, resonance, and modulation

A localized pit does not generate a pure sinusoid. Each rolling contact with the defect produces a short impact. That impulse excites a higher-frequency structural resonance in the bearing/housing path, creating a decaying burst. A train of bursts is therefore an amplitude-modulated signal: the resonance is the carrier and the defect encounter rate is the modulation frequency.

- **BPFO:** balls pass a fixed outer-race point.
- **BPFI:** balls pass a rotating inner-race point.
- **BSF:** a ball defect returns to contact as the ball spins.
- **FTF:** cage rotation.

That is why we inspect the waveform and raw FFT, but use an envelope spectrum for localization."""))

cells.append(nbf.v4.new_markdown_cell("""## 2. Dataset and minimal controlled subset

CWRU used a 2 hp motor, dynamometer, torque transducer/encoder, and housing-mounted accelerometers. This MVP holds sensor location (drive end) and defect size (0.007 inch) fixed while varying condition and load. Eight files cover normal, inner-race, outer-race-at-6-o'clock, and ball conditions at 0 and 3 HP.

Normal drive-end records originate at 48 kHz and are anti-alias downsampled to 12 kHz. Fault records originate at 12 kHz. This is a known acquisition mismatch, not a hidden detail. CWRU's public pages do not establish an absolute acceleration calibration unit, so amplitude remains in CWRU units."""))

cells.append(nbf.v4.new_code_cell("""from pathlib import Path
import sys, json, subprocess
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from IPython.display import display, Image

ROOT = Path.cwd()
if not (ROOT / 'run_analysis.py').exists():
    ROOT = Path.cwd().parent
sys.path.insert(0, str(ROOT / 'src'))
sys.path.insert(0, str(ROOT))

from bearing_monitoring.config import RECORDS, RAW_DIR, TARGET_FS_HZ, ENVELOPE_BAND_HZ
from bearing_monitoring.io import load_cwru_record, segment_signal
from bearing_monitoring.features import time_features
from bearing_monitoring.bearing import fault_frequencies
from bearing_monitoring.spectral import single_sided_spectrum
from bearing_monitoring.envelope import envelope_spectrum

missing = [rid for rid in RECORDS if not (RAW_DIR / f'{rid}.mat').exists()]
if missing:
    subprocess.run([sys.executable, str(ROOT / 'download_data.py')], check=True)

from run_analysis import main as run_full_analysis
run_full_analysis()"""))

cells.append(nbf.v4.new_markdown_cell("""## 3. Reproducible loading and metadata

The loader finds channel names by pattern rather than hard-coding MATLAB variable prefixes. It verifies finite length, removes mean offset, and uses polyphase anti-alias resampling when the source rate differs from the 12 kHz analysis rate."""))

cells.append(nbf.v4.new_code_cell("""rows, records = [], {}
for rid, meta in RECORDS.items():
    rec = load_cwru_record(RAW_DIR / f'{rid}.mat', condition=meta['condition'], load_hp=meta['load_hp'], source_fs_hz=meta['source_fs_hz'])
    records[rid] = rec
    rows.append({'record': rid, 'condition': rec.condition, 'load_hp': rec.load_hp, 'rpm': rec.rpm,
                 'source_fs_hz': rec.source_fs_hz, 'analysis_fs_hz': rec.fs_hz, 'samples': len(rec.acceleration)})
metadata = pd.DataFrame(rows)
display(metadata)"""))

cells.append(nbf.v4.new_markdown_cell(r"""## 4. Time-domain inspection and condition indicators

Offset removal uses $x_c[n]=x[n]-\bar{x}$. RMS and standard deviation measure energy/spread; peak-to-peak and crest factor respond to large excursions; Pearson kurtosis measures tail impulsiveness (Gaussian = 3). These can flag abnormal behavior but cannot by themselves identify which bearing surface is damaged."""))

cells.append(nbf.v4.new_markdown_cell("""![Time-domain waveforms](../docs/figures/01_time_waveforms.png)"""))
cells.append(nbf.v4.new_code_cell("""features = pd.read_csv(ROOT / 'results/feature_results.csv')
display(features[['record_id','segment_index','condition','load_hp','rms','peak_to_peak','crest_factor','kurtosis']].head(12))"""))

cells.append(nbf.v4.new_markdown_cell(r"""## 5. Sampling, windowing, leakage, and FFT scaling

At $f_s=12{,}000$ Hz, Nyquist is 6 kHz. A one-second, 12,000-sample record gives $\Delta f=f_s/N=1$ Hz. Observing a signal for finite time is equivalent to multiplying by a rectangular window, whose spectrum spreads off-bin energy into sidelobes. A Hann window reduces sidelobes at the cost of a wider main lobe.

For a real signal, we compute the RFFT, divide magnitude by the window's coherent sum, and double positive-frequency bins except DC and Nyquist. This gives a peak-amplitude single-sided spectrum for a bin-centered sinusoid."""))

cells.append(nbf.v4.new_markdown_cell("""![Raw spectra with theoretical fault-frequency markers](../docs/figures/02_raw_spectra_with_fault_markers.png)"""))
cells.append(nbf.v4.new_code_cell("""print(f'Analysis rate: {TARGET_FS_HZ:.0f} Hz | Nyquist: {TARGET_FS_HZ/2:.0f} Hz | one-second FFT resolution: 1 Hz')"""))

cells.append(nbf.v4.new_markdown_cell(r"""## 6. Bearing kinematics

For $n$ rolling elements, ball diameter $d$, pitch diameter $D$, contact angle $\theta$, and shaft rate $f_r$:

$$\mathrm{BPFO}=\frac n2f_r(1-\frac dD\cos\theta),\quad \mathrm{BPFI}=\frac n2f_r(1+\frac dD\cos\theta)$$

$$\mathrm{BSF}=\frac D{2d}f_r[1-(\frac dD\cos\theta)^2],\quad \mathrm{FTF}=\frac12f_r(1-\frac dD\cos\theta)$$

The no-slip assumption is idealized; real data can shift slightly and show shaft-speed sidebands."""))

cells.append(nbf.v4.new_code_cell("""frequency_rows = []
for rid, rec in records.items():
    frequency_rows.append({'record': rid, 'condition': rec.condition, 'load_hp': rec.load_hp, 'rpm': rec.rpm, **fault_frequencies(rec.rpm)})
display(pd.DataFrame(frequency_rows).round(2))"""))

cells.append(nbf.v4.new_markdown_cell(r"""## 7. Bandpass filtering and Hilbert-envelope analysis

We apply a fourth-order zero-phase Butterworth bandpass from 2 to 5 kHz. The fixed band isolates impact-excited resonance while remaining below Nyquist. The analytic signal is

$$z[n]=x_{BP}[n]+j\mathcal{H}\{x_{BP}[n]\},\qquad e[n]=|z[n]|.$$

The FFT of the de-meaned envelope reveals the rate at which the resonance bursts repeat. A fixed band is transparent and avoids choosing a different favorable band for each fault."""))

cells.append(nbf.v4.new_markdown_cell("""![Envelope spectra](../docs/figures/03_envelope_spectra.png)"""))

cells.append(nbf.v4.new_markdown_cell("""## 8. Original experiment: cross-load robustness

The question is not merely whether a peak exists in one record. We ask whether each fault's expected envelope-frequency evidence persists when load changes from 0 to 3 HP and speed changes with it. Frequencies are recalculated from each record's measured RPM. Feature ratios are normalized to the normal record at the same load."""))

cells.append(nbf.v4.new_markdown_cell("""![Cross-load expected-frequency evidence](../docs/figures/05_cross_load_frequency_evidence.png)"""))
cells.append(nbf.v4.new_code_cell("""summary = json.loads((ROOT / 'results/analysis_summary.json').read_text())
display(pd.read_csv(ROOT / 'results/condition_load_summary.csv').round(3))
print(json.dumps(summary['median_expected_frequency_prominence_db'], indent=2))"""))

cells.append(nbf.v4.new_markdown_cell("""## 9. Secondary machine-learning comparison

A standardized logistic regression uses transparent statistics and three envelope-frequency prominence features. It trains on one load and tests on the other, then reverses direction. Adjacent windows from the same file never appear on opposite sides of a directional split. This is still exploratory: each class/load contains one physical source recording, so windows are repeated measurements, not independent machines."""))

cells.append(nbf.v4.new_markdown_cell("""![Cross-load classifier confusion matrix](../docs/figures/06_cross_load_ml_confusion_matrix.png)"""))
cells.append(nbf.v4.new_code_cell("""display(pd.Series(summary['ml'], name='value'))"""))

cells.append(nbf.v4.new_markdown_cell("""## 10. Conclusions and deployment limitations

- Race-fault BPFO/BPFI evidence is strong and stable across the two selected loads.
- Ball-fault BSF evidence is weaker and load-sensitive; the project reports that honestly.
- Time statistics indicate impulsiveness, while kinematic envelope peaks provide component-level interpretation.
- CWRU uses isolated EDM faults on a laboratory rig. Natural faults, multiple sources, structural transfer paths, and variable speed complicate field data.
- A deployed system needs calibrated sensors, controlled mounting/orientation, anti-alias filtering, tachometer/load context, order tracking when speed varies, sensor-health checks, persistent alarms, site-specific baselines, and maintenance confirmation.
- The normal/fault acquisition-history difference and small number of independent source recordings limit any accuracy claim."""))

nb["cells"] = cells
nbf.write(nb, OUT)
print(OUT)
