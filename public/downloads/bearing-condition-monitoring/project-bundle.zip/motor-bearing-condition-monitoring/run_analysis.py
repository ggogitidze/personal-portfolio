#!/usr/bin/env python3
"""Run the complete physics-first CWRU bearing-monitoring MVP."""

from __future__ import annotations

import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / "src"))

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import seaborn as sns
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score, confusion_matrix
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler

from bearing_monitoring.bearing import fault_frequencies
from bearing_monitoring.config import (
    CONDITION_ORDER,
    DISPLAY_NAMES,
    ENVELOPE_BAND_HZ,
    FIGURES_DIR,
    RAW_DIR,
    RECORDS,
    RESULTS_DIR,
    SEGMENT_SECONDS,
    SEGMENTS_PER_RECORD,
    TARGET_FS_HZ,
)
from bearing_monitoring.envelope import envelope_spectrum
from bearing_monitoring.features import time_features
from bearing_monitoring.io import load_cwru_record, segment_signal
from bearing_monitoring.spectral import peak_prominence_db, single_sided_spectrum


COLORS = {
    "normal": "#4C78A8",
    "outer_race": "#F58518",
    "inner_race": "#E45756",
    "ball": "#54A24B",
}
FAULT_KEY = {"outer_race": "bpfo", "inner_race": "bpfi", "ball": "bsf"}


def set_style() -> None:
    sns.set_theme(style="whitegrid", context="talk")
    plt.rcParams.update({
        "figure.dpi": 120,
        "savefig.dpi": 220,
        "font.family": "DejaVu Sans",
        "axes.titleweight": "bold",
        "axes.spines.top": False,
        "axes.spines.right": False,
    })


def load_records():
    records = {}
    for record_id, meta in RECORDS.items():
        records[record_id] = load_cwru_record(
            RAW_DIR / f"{record_id}.mat",
            condition=meta["condition"],
            load_hp=meta["load_hp"],
            source_fs_hz=meta["source_fs_hz"],
            target_fs_hz=TARGET_FS_HZ,
        )
    return records


def build_feature_table(records) -> pd.DataFrame:
    rows = []
    for record_id, record in records.items():
        frequencies = fault_frequencies(record.rpm)
        segments = segment_signal(record.acceleration, record.fs_hz, SEGMENT_SECONDS, SEGMENTS_PER_RECORD)
        for segment_index, segment in enumerate(segments):
            features = time_features(segment)
            raw_f, raw_a = single_sided_spectrum(segment, record.fs_hz)
            env_f, env_a, _ = envelope_spectrum(segment, record.fs_hz, ENVELOPE_BAND_HZ)
            row = {
                "record_id": record_id,
                "segment_index": segment_index,
                "condition": record.condition,
                "load_hp": record.load_hp,
                "rpm": record.rpm,
                "source_fs_hz": record.source_fs_hz,
                "analysis_fs_hz": record.fs_hz,
                "segment_seconds": SEGMENT_SECONDS,
                **features,
                **{f"{key}_hz": value for key, value in frequencies.items()},
            }
            for key in ("bpfo", "bpfi", "bsf"):
                row[f"raw_{key}_prominence_db"] = peak_prominence_db(raw_f, raw_a, frequencies[key])
                row[f"envelope_{key}_prominence_db"] = peak_prominence_db(env_f, env_a, frequencies[key])
            target_key = FAULT_KEY.get(record.condition)
            row["diagnostic_frequency"] = target_key or "none"
            row["diagnostic_envelope_prominence_db"] = row.get(f"envelope_{target_key}_prominence_db", np.nan)
            rows.append(row)
    return pd.DataFrame(rows)


def plot_time_waveforms(records) -> None:
    fig, axes = plt.subplots(4, 2, figsize=(14, 12), sharex=True, sharey="row")
    for row, condition in enumerate(CONDITION_ORDER):
        for col, load in enumerate((0, 3)):
            record = next(r for r in records.values() if r.condition == condition and r.load_hp == load)
            samples = int(0.25 * record.fs_hz)
            t = np.arange(samples) / record.fs_hz
            axes[row, col].plot(t, record.acceleration[:samples], color=COLORS[condition], linewidth=0.8)
            axes[row, col].set_title(f"{DISPLAY_NAMES[condition]} - {load} HP, {record.rpm:.0f} rpm")
            axes[row, col].set_ylabel("Acceleration\n[CWRU units]")
    for ax in axes[-1, :]:
        ax.set_xlabel("Time [s]")
    fig.suptitle("Time-domain vibration: impacts increase impulsiveness", y=1.01, fontsize=20, fontweight="bold")
    fig.tight_layout()
    fig.savefig(FIGURES_DIR / "01_time_waveforms.png", bbox_inches="tight")
    plt.close(fig)


def plot_raw_spectra(records) -> None:
    fig, axes = plt.subplots(2, 2, figsize=(14, 9), sharex=True)
    marker_colors = {"bpfo": COLORS["outer_race"], "bpfi": COLORS["inner_race"], "bsf": COLORS["ball"]}
    for ax, condition in zip(axes.flat, CONDITION_ORDER):
        record = next(r for r in records.values() if r.condition == condition and r.load_hp == 0)
        segment = segment_signal(record.acceleration, record.fs_hz, SEGMENT_SECONDS, 1)[0]
        freq, amp = single_sided_spectrum(segment, record.fs_hz)
        mask = freq <= 1000
        ax.plot(freq[mask], 20 * np.log10(amp[mask] + 1e-12), color=COLORS[condition], linewidth=0.9)
        ff = fault_frequencies(record.rpm)
        for key in ("bpfo", "bpfi", "bsf"):
            ax.axvline(ff[key], color=marker_colors[key], linestyle="--", linewidth=1.2, alpha=0.9, label=key.upper())
        ax.set_title(f"{DISPLAY_NAMES[condition]} - 0 HP")
        ax.set_ylabel("Amplitude [dB re 1 CWRU unit]")
        ax.legend(fontsize=9, ncol=3, loc="upper right")
    for ax in axes[-1, :]:
        ax.set_xlabel("Frequency [Hz]")
    fig.suptitle("Hann-windowed, coherent-gain-corrected single-sided spectra", y=1.01, fontsize=20, fontweight="bold")
    fig.tight_layout()
    fig.savefig(FIGURES_DIR / "02_raw_spectra_with_fault_markers.png", bbox_inches="tight")
    plt.close(fig)


def plot_envelope_spectra(records) -> None:
    fig, axes = plt.subplots(4, 2, figsize=(14, 12), sharex=True, sharey="row")
    for row, condition in enumerate(CONDITION_ORDER):
        for col, load in enumerate((0, 3)):
            record = next(r for r in records.values() if r.condition == condition and r.load_hp == load)
            segment = segment_signal(record.acceleration, record.fs_hz, SEGMENT_SECONDS, 1)[0]
            freq, amp, _ = envelope_spectrum(segment, record.fs_hz, ENVELOPE_BAND_HZ)
            mask = freq <= 500
            axes[row, col].plot(freq[mask], 20 * np.log10(amp[mask] + 1e-12), color=COLORS[condition], linewidth=0.9)
            ff = fault_frequencies(record.rpm)
            key = FAULT_KEY.get(condition)
            if key:
                for harmonic in (1, 2, 3):
                    target = harmonic * ff[key]
                    if target <= 500:
                        axes[row, col].axvline(target, color="black", linestyle="--", linewidth=1.1, alpha=0.75)
                axes[row, col].text(0.98, 0.90, f"{key.upper()} harmonics", transform=axes[row, col].transAxes, ha="right", va="top", fontsize=10)
            axes[row, col].set_title(f"{DISPLAY_NAMES[condition]} - {load} HP")
            axes[row, col].set_ylabel("Envelope amp.\n[dB re 1 unit]")
    for ax in axes[-1, :]:
        ax.set_xlabel("Envelope frequency [Hz]")
    fig.suptitle("2-5 kHz bandpass + Hilbert envelope spectrum", y=1.01, fontsize=20, fontweight="bold")
    fig.tight_layout()
    fig.savefig(FIGURES_DIR / "03_envelope_spectra.png", bbox_inches="tight")
    plt.close(fig)


def plot_feature_ratios(features: pd.DataFrame) -> None:
    columns = ["rms", "peak_to_peak", "crest_factor", "kurtosis"]
    med = features.groupby(["load_hp", "condition"])[columns].median()
    rows = []
    for load in (0, 3):
        normal = med.loc[(load, "normal")]
        for condition in CONDITION_ORDER:
            ratios = med.loc[(load, condition)] / normal
            rows.append({"case": f"{DISPLAY_NAMES[condition]} - {load} HP", **ratios.to_dict()})
    table = pd.DataFrame(rows).set_index("case")
    log2_ratio = np.log2(table.clip(lower=1e-6))
    fig, ax = plt.subplots(figsize=(10, 7))
    sns.heatmap(log2_ratio, annot=table, fmt=".2f", cmap="vlag", center=0, linewidths=0.5, ax=ax, cbar_kws={"label": "log2(feature / same-load normal)"})
    ax.set_title("Median feature ratios normalized within each load")
    ax.set_xlabel("Condition indicator")
    ax.set_ylabel("")
    fig.tight_layout()
    fig.savefig(FIGURES_DIR / "04_feature_ratios_cross_load.png", bbox_inches="tight")
    plt.close(fig)


def plot_frequency_evidence(features: pd.DataFrame) -> None:
    faults = features[features["condition"] != "normal"].copy()
    fig, ax = plt.subplots(figsize=(11, 6))
    sns.barplot(
        data=faults,
        x="condition",
        y="diagnostic_envelope_prominence_db",
        hue="load_hp",
        order=["outer_race", "inner_race", "ball"],
        errorbar="sd",
        palette=["#72B7B2", "#B279A2"],
        ax=ax,
    )
    ax.axhline(6, color="black", linestyle="--", linewidth=1, label="6 dB reference")
    ax.set_xticks(range(3), ["Outer race / BPFO", "Inner race / BPFI", "Ball / BSF"])
    ax.set_xlabel("")
    ax.set_ylabel("Expected-frequency prominence [dB]")
    ax.set_title("Cross-load robustness of envelope-frequency evidence")
    handles, labels = ax.get_legend_handles_labels()
    ax.legend(handles, labels, title="Motor load [HP]")
    fig.tight_layout()
    fig.savefig(FIGURES_DIR / "05_cross_load_frequency_evidence.png", bbox_inches="tight")
    plt.close(fig)


def cross_load_ml(features: pd.DataFrame) -> tuple[dict, np.ndarray, list[str]]:
    feature_columns = [
        "rms", "peak_to_peak", "crest_factor", "kurtosis",
        "envelope_bpfo_prominence_db", "envelope_bpfi_prominence_db", "envelope_bsf_prominence_db",
    ]
    labels = CONDITION_ORDER
    all_true, all_pred = [], []
    directional = {}
    for train_load, test_load in ((0, 3), (3, 0)):
        train = features[features["load_hp"] == train_load]
        test = features[features["load_hp"] == test_load]
        model = make_pipeline(StandardScaler(), LogisticRegression(max_iter=3000, C=1.0, random_state=7))
        model.fit(train[feature_columns], train["condition"])
        pred = model.predict(test[feature_columns])
        directional[f"{train_load}_to_{test_load}_accuracy"] = float(accuracy_score(test["condition"], pred))
        all_true.extend(test["condition"].tolist())
        all_pred.extend(pred.tolist())
    cm = confusion_matrix(all_true, all_pred, labels=labels)
    metrics = {
        **directional,
        "combined_cross_load_accuracy": float(accuracy_score(all_true, all_pred)),
        "test_windows_total": len(all_true),
        "warning": "Exploratory only: one source recording per class/load; windows are not independent machines.",
    }
    return metrics, cm, labels


def plot_confusion(cm: np.ndarray, labels: list[str], metrics: dict) -> None:
    fig, ax = plt.subplots(figsize=(8.6, 6.5))
    sns.heatmap(cm, annot=True, fmt="d", cmap="Blues", cbar=False, square=True, ax=ax,
                xticklabels=[DISPLAY_NAMES[x] for x in labels], yticklabels=[DISPLAY_NAMES[x] for x in labels])
    ax.set_xlabel("Predicted condition")
    ax.set_ylabel("True condition")
    ax.tick_params(axis="x", labelrotation=18, labelsize=12)
    ax.tick_params(axis="y", labelrotation=0, labelsize=12)
    ax.set_title(f"Exploratory cross-load classifier\ncombined accuracy = {metrics['combined_cross_load_accuracy']:.1%}")
    fig.tight_layout()
    fig.savefig(FIGURES_DIR / "06_cross_load_ml_confusion_matrix.png", bbox_inches="tight")
    plt.close(fig)


def plot_portfolio_hero(records) -> None:
    """Create a clean normal-versus-fault envelope comparison for the website."""
    fig, axes = plt.subplots(1, 2, figsize=(14, 5.5), sharey=True)
    for ax, condition in zip(axes, ("normal", "outer_race")):
        record = next(r for r in records.values() if r.condition == condition and r.load_hp == 3)
        segment = segment_signal(record.acceleration, record.fs_hz, SEGMENT_SECONDS, 1)[0]
        freq, amp, _ = envelope_spectrum(segment, record.fs_hz, ENVELOPE_BAND_HZ)
        mask = freq <= 500
        ax.plot(freq[mask], 20 * np.log10(amp[mask] + 1e-12), color=COLORS[condition], linewidth=1.25)
        if condition == "outer_race":
            bpfo = fault_frequencies(record.rpm)["bpfo"]
            for harmonic in (1, 2, 3, 4):
                if harmonic * bpfo <= 500:
                    ax.axvline(harmonic * bpfo, color="#222222", linestyle="--", linewidth=1.2)
            ax.text(0.97, 0.92, "BPFO harmonics", transform=ax.transAxes, ha="right", va="top", fontsize=12)
        ax.set_title(f"{DISPLAY_NAMES[condition]} bearing", fontsize=17)
        ax.set_xlabel("Envelope frequency [Hz]")
    axes[0].set_ylabel("Envelope amplitude [dB re 1 unit]")
    fig.suptitle("Bearing impacts revealed by envelope demodulation", fontsize=21, fontweight="bold", y=1.02)
    fig.text(0.5, -0.01, "CWRU drive-end vibration, 3 HP | 2-5 kHz bandpass | 1 Hz resolution", ha="center", fontsize=12)
    fig.tight_layout()
    fig.savefig(FIGURES_DIR / "07_portfolio_hero.png", bbox_inches="tight")
    plt.close(fig)


def write_summary(features: pd.DataFrame, ml_metrics: dict) -> dict:
    feature_medians = features.groupby(["condition", "load_hp"])[
        ["rms", "peak_to_peak", "crest_factor", "kurtosis", "diagnostic_envelope_prominence_db"]
    ].median().reset_index()
    feature_medians.to_csv(RESULTS_DIR / "condition_load_summary.csv", index=False)

    evidence = (
        features[features["condition"] != "normal"]
        .groupby(["condition", "load_hp"])["diagnostic_envelope_prominence_db"]
        .median()
        .round(3)
        .to_dict()
    )
    summary = {
        "records": len(RECORDS),
        "segments": int(len(features)),
        "target_fs_hz": TARGET_FS_HZ,
        "fft_resolution_hz": 1.0 / SEGMENT_SECONDS,
        "envelope_band_hz": list(ENVELOPE_BAND_HZ),
        "median_expected_frequency_prominence_db": {f"{condition}_{load}hp": value for (condition, load), value in evidence.items()},
        "ml": ml_metrics,
    }
    (RESULTS_DIR / "analysis_summary.json").write_text(json.dumps(summary, indent=2) + "\n", encoding="utf-8")
    return summary


def main() -> None:
    RESULTS_DIR.mkdir(parents=True, exist_ok=True)
    FIGURES_DIR.mkdir(parents=True, exist_ok=True)
    set_style()
    records = load_records()
    features = build_feature_table(records)
    features.to_csv(RESULTS_DIR / "feature_results.csv", index=False)

    plot_time_waveforms(records)
    plot_raw_spectra(records)
    plot_envelope_spectra(records)
    plot_feature_ratios(features)
    plot_frequency_evidence(features)
    ml_metrics, cm, labels = cross_load_ml(features)
    plot_confusion(cm, labels, ml_metrics)
    plot_portfolio_hero(records)
    summary = write_summary(features, ml_metrics)
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
