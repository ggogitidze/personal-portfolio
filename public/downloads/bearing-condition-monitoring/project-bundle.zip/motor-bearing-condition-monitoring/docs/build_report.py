"""Create the two-page technical report PDF."""

from __future__ import annotations

import json
from pathlib import Path

import pandas as pd
from reportlab.lib import colors
from reportlab.lib.enums import TA_LEFT
from reportlab.lib.pagesizes import letter
from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.lib.units import inch
from reportlab.platypus import (
    BaseDocTemplate,
    Frame,
    Image,
    PageBreak,
    PageTemplate,
    Paragraph,
    Spacer,
    Table,
    TableStyle,
)


ROOT = Path(__file__).resolve().parents[1]
OUTPUT = ROOT / "docs" / "technical_report.pdf"
SUMMARY = json.loads((ROOT / "results" / "analysis_summary.json").read_text())
MEDIANS = pd.read_csv(ROOT / "results" / "condition_load_summary.csv")

NAVY = colors.HexColor("#16324F")
BLUE = colors.HexColor("#4C78A8")
ORANGE = colors.HexColor("#F58518")
LIGHT = colors.HexColor("#EDF3F8")
MID = colors.HexColor("#607487")
GREEN = colors.HexColor("#2A7F62")

pdfmetrics.registerFont(TTFont("DejaVu", "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf"))
pdfmetrics.registerFont(TTFont("DejaVu-Bold", "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf"))


def footer(canvas, doc):
    canvas.saveState()
    canvas.setStrokeColor(colors.HexColor("#D8E1E8"))
    canvas.line(0.58 * inch, 0.48 * inch, 7.92 * inch, 0.48 * inch)
    canvas.setFont("DejaVu", 8)
    canvas.setFillColor(MID)
    canvas.drawString(0.58 * inch, 0.30 * inch, "Motor Bearing Condition Monitoring | CWRU physics-first portfolio project")
    canvas.drawRightString(7.92 * inch, 0.30 * inch, f"{doc.page}")
    canvas.restoreState()


styles = getSampleStyleSheet()
styles.add(ParagraphStyle(name="ReportTitle", parent=styles["Title"], fontName="DejaVu-Bold", fontSize=21, leading=25, textColor=NAVY, alignment=TA_LEFT, spaceAfter=5))
styles.add(ParagraphStyle(name="Subtitle", parent=styles["Normal"], fontName="DejaVu", fontSize=10.2, leading=14, textColor=MID, spaceAfter=10))
styles.add(ParagraphStyle(name="H1x", parent=styles["Heading1"], fontName="DejaVu-Bold", fontSize=13, leading=16, textColor=NAVY, spaceBefore=8, spaceAfter=5))
styles.add(ParagraphStyle(name="H2x", parent=styles["Heading2"], fontName="DejaVu-Bold", fontSize=9.5, leading=12, textColor=BLUE, spaceBefore=4, spaceAfter=3))
styles.add(ParagraphStyle(name="TableHead", parent=styles["BodyText"], fontName="DejaVu-Bold", fontSize=8.2, leading=10, textColor=colors.white))
styles.add(ParagraphStyle(name="Bodyx", parent=styles["BodyText"], fontName="DejaVu", fontSize=8.3, leading=11.2, textColor=colors.HexColor("#243746"), spaceAfter=5))
styles.add(ParagraphStyle(name="Smallx", parent=styles["BodyText"], fontName="DejaVu", fontSize=7.3, leading=9.2, textColor=MID, spaceAfter=3))
styles.add(ParagraphStyle(name="Metric", parent=styles["BodyText"], fontName="DejaVu-Bold", fontSize=17, leading=19, textColor=NAVY, alignment=1))
styles.add(ParagraphStyle(name="MetricLabel", parent=styles["BodyText"], fontName="DejaVu", fontSize=7.5, leading=9, textColor=MID, alignment=1))


doc = BaseDocTemplate(
    str(OUTPUT), pagesize=letter,
    leftMargin=0.58 * inch, rightMargin=0.58 * inch,
    topMargin=0.52 * inch, bottomMargin=0.58 * inch,
    title="Motor Bearing Condition Monitoring from Vibration Signals",
    author="Giorgi Gogitidze",
)
frame = Frame(doc.leftMargin, doc.bottomMargin, doc.width, doc.height, id="normal")
doc.addPageTemplates(PageTemplate(id="report", frames=frame, onPage=footer))


def P(text, style="Bodyx"):
    return Paragraph(text, styles[style])


story = [
    P("Motor Bearing Condition Monitoring<br/>from Vibration Signals", "ReportTitle"),
    P("Physics-grounded condition monitoring with the Case Western Reserve University bearing dataset", "Subtitle"),
]

metric_data = [
    [P("8", "Metric"), P("40", "Metric"), P("1 Hz", "Metric"), P("82.5%", "Metric")],
    [P("source records", "MetricLabel"), P("one-second windows", "MetricLabel"), P("FFT bin spacing", "MetricLabel"), P("exploratory cross-load ML", "MetricLabel")],
]
metrics_table = Table(metric_data, colWidths=[doc.width / 4] * 4, rowHeights=[0.30 * inch, 0.27 * inch])
metrics_table.setStyle(TableStyle([
    ("BACKGROUND", (0, 0), (-1, -1), LIGHT),
    ("BOX", (0, 0), (-1, -1), 0.5, colors.HexColor("#CFDCE6")),
    ("INNERGRID", (0, 0), (-1, -1), 0.5, colors.HexColor("#CFDCE6")),
    ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
    ("LEFTPADDING", (0, 0), (-1, -1), 4), ("RIGHTPADDING", (0, 0), (-1, -1), 4),
]))
story += [metrics_table, Spacer(1, 7)]

story += [P("Problem and physical mechanism", "H1x")]
story += [P("A localized race or rolling-element defect produces a short impact when it enters contact in the loaded zone. The impact excites a higher-frequency structural resonance, creating a decaying burst. Repeated bursts form an amplitude-modulated signal: the resonance is the carrier and the defect encounter rate is the modulation frequency. Time statistics can flag impulsiveness; a Hilbert-envelope spectrum can recover the component-specific repetition rate.")]

method_left = """<b>Dataset scope</b><br/>Eight official drive-end records: normal, 0.007-inch inner-race, ball, and outer-race faults at 0 and 3 HP. The outer-race fault is centered at 6 o'clock in the load zone. Five balanced one-second windows are retained per record."""
method_right = """<b>Processing chain</b><br/>SHA-256 verification -> DC removal -> anti-alias rate standardization -> time features -> Hann-windowed amplitude-correct RFFT -> bearing kinematics -> fixed 2-5 kHz bandpass -> Hilbert envelope -> cross-load evaluation."""
method_table = Table([[P(method_left), P(method_right)]], colWidths=[doc.width / 2 - 4] * 2)
method_table.setStyle(TableStyle([
    ("BACKGROUND", (0, 0), (-1, -1), colors.HexColor("#F8FAFC")),
    ("BOX", (0, 0), (-1, -1), 0.5, colors.HexColor("#D8E1E8")),
    ("INNERGRID", (0, 0), (-1, -1), 0.5, colors.HexColor("#D8E1E8")),
    ("VALIGN", (0, 0), (-1, -1), "TOP"),
    ("LEFTPADDING", (0, 0), (-1, -1), 8), ("RIGHTPADDING", (0, 0), (-1, -1), 8),
    ("TOPPADDING", (0, 0), (-1, -1), 7), ("BOTTOMPADDING", (0, 0), (-1, -1), 4),
]))
story += [method_table, Spacer(1, 6)]

hero = Image(str(ROOT / "docs" / "figures" / "07_portfolio_hero.png"), width=7.25 * inch, height=2.85 * inch)
story += [hero, P("Figure 1. Envelope demodulation suppresses carrier complexity and exposes BPFO harmonics in the outer-race case. Amplitude is reported in CWRU units because public dataset pages do not establish absolute calibration.", "Smallx")]

story += [PageBreak()]
story += [P("Method validity, results, and<br/>deployment judgment", "ReportTitle")]

story += [P("Key equations and sampling constraints", "H1x")]
equation_data = [
    [P("Indicator", "TableHead"), P("Definition / engineering meaning", "TableHead")],
    [P("Frequency resolution"), P("Delta f = f_s / N = 12,000 / 12,000 = 1 Hz. Nyquist = 6 kHz.")],
    [P("Race frequencies"), P("BPFO = (n/2) f_r [1 - (d/D) cos(theta)]; BPFI uses the plus sign.")],
    [P("Ball and cage"), P("BSF = (D/2d) f_r [1 - ((d/D) cos(theta))^2]; FTF = 0.5 f_r [1 - (d/D) cos(theta)].")],
    [P("Envelope"), P("z[n] = x_BP[n] + j H{x_BP[n]}; e[n] = |z[n]|. FFT{e[n] - mean(e)} reveals impact repetition.")],
]
eq_table = Table(equation_data, colWidths=[1.35 * inch, doc.width - 1.35 * inch])
eq_table.setStyle(TableStyle([
    ("BACKGROUND", (0, 0), (-1, 0), NAVY), ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
    ("ROWBACKGROUNDS", (0, 1), (-1, -1), [colors.white, LIGHT]),
    ("GRID", (0, 0), (-1, -1), 0.4, colors.HexColor("#CCD8E2")),
    ("VALIGN", (0, 0), (-1, -1), "TOP"),
    ("LEFTPADDING", (0, 0), (-1, -1), 6), ("RIGHTPADDING", (0, 0), (-1, -1), 6),
    ("TOPPADDING", (0, 0), (-1, -1), 4), ("BOTTOMPADDING", (0, 0), (-1, -1), 4),
]))
story += [eq_table]

story += [P("Cross-load experiment", "H1x")]
e = SUMMARY["median_expected_frequency_prominence_db"]
result_data = [
    [P("Fault / expected family", "TableHead"), P("0 HP median", "TableHead"), P("3 HP median", "TableHead"), P("Interpretation", "TableHead")],
    [P("Outer race / BPFO"), P(f"{e['outer_race_0hp']:.1f} dB"), P(f"{e['outer_race_3hp']:.1f} dB"), P("Strong at both loads")],
    [P("Inner race / BPFI"), P(f"{e['inner_race_0hp']:.1f} dB"), P(f"{e['inner_race_3hp']:.1f} dB"), P("Stable across load")],
    [P("Ball / BSF"), P(f"{e['ball_0hp']:.1f} dB"), P(f"{e['ball_3hp']:.1f} dB"), P("Weaker, load-sensitive")],
]
result_table = Table(result_data, colWidths=[1.65 * inch, 1.15 * inch, 1.15 * inch, doc.width - 3.95 * inch])
result_table.setStyle(TableStyle([
    ("BACKGROUND", (0, 0), (-1, 0), BLUE), ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
    ("GRID", (0, 0), (-1, -1), 0.4, colors.HexColor("#CCD8E2")),
    ("ROWBACKGROUNDS", (0, 1), (-1, -1), [colors.white, colors.HexColor("#F8FAFC")]),
    ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
    ("LEFTPADDING", (0, 0), (-1, -1), 6), ("RIGHTPADDING", (0, 0), (-1, -1), 6),
    ("TOPPADDING", (0, 0), (-1, -1), 4), ("BOTTOMPADDING", (0, 0), (-1, -1), 4),
]))
story += [result_table]
story += [P("The load change shifts shaft speed, so theoretical frequencies are recalculated from each file's measured RPM. Race-fault evidence remains strong; BSF is near the 6 dB reference at 0 HP and improves at 3 HP. The bidirectional load-held-out logistic regression reaches 82.5%, but this is not a production accuracy claim: one recording represents each class/load.", "Bodyx")]

limitations = [
    "EDM-seeded, isolated laboratory faults do not represent natural progression or multiple simultaneous defects.",
    "Normal and fault records have different source sampling histories; resampling creates a common grid, not identical acquisition chains.",
    "Ideal no-slip kinematics require tolerance for slip and shaft-speed sidebands in field data.",
    "Sensor mounting, orientation, dynamic range, anti-aliasing, cabling, and structural transfer paths affect repeatability.",
    "Production alarms require asset-specific baselines, speed/load context, persistence logic, sensor-health checks, and maintenance confirmation.",
]
story += [P("Reliability and deployment considerations", "H1x")]
for item in limitations:
    story.append(P(f"<font color='#2A7F62'>-</font> {item}", "Bodyx"))

story += [P("Verification and sources", "H1x")]
story += [P("Automated tests verify selected signal lengths, the 12 kHz analysis rate, FFT peak location and amplitude, Nyquist endpoint, segmentation, and feature calculations. Sources: CWRU Bearing Data Center, Apparatus & Procedures, Bearing Information, and official data tables at engineering.case.edu/bearingdatacenter. Analysis and code are independently authored; advanced methods are intentionally outside the MVP.", "Smallx")]

doc.build(story)
print(OUTPUT)
