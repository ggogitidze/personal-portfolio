# Motor Bearing Condition Monitoring from Vibration Signals

A physics-first portfolio project using the Case Western Reserve University (CWRU) bearing dataset. The objective is not to chase a classifier score. It is to connect bearing mechanics, sampling, spectral estimation, resonance, demodulation, and condition indicators into one reproducible diagnostic workflow.

## Result in one paragraph

The MVP analyzes eight drive-end recordings: normal, inner-race, outer-race, and ball conditions at 0 and 3 HP. All faults are the smallest 0.007-inch seeded defect. After standardizing to 12 kHz and evaluating five one-second windows per record, 2-5 kHz Hilbert-envelope spectra showed median expected-frequency prominence of **36.1-40.0 dB for BPFO**, **34.8-35.0 dB for BPFI**, and **5.8-9.9 dB for BSF**. A deliberately secondary logistic-regression comparison achieved **82.5% combined cross-load accuracy**, but it is exploratory because each class/load has only one source recording.

## Why bearing defects create vibration signatures

A localized defect causes a short impact whenever rolling contact encounters it in the loaded zone. The impact excites a structural resonance of the bearing, housing, and sensor mounting path. The measured waveform is therefore not a clean sinusoid at a fault frequency; it is a series of high-frequency ringing bursts. Their repetition rate follows bearing kinematics.

For rolling-element count \(n\), ball diameter \(d\), pitch diameter \(D\), contact angle \(\theta\), and shaft rate \(f_r\):

\[
\mathrm{BPFO}=\frac{n}{2}f_r\left(1-\frac{d}{D}\cos\theta\right),\qquad
\mathrm{BPFI}=\frac{n}{2}f_r\left(1+\frac{d}{D}\cos\theta\right)
\]

\[
\mathrm{BSF}=\frac{D}{2d}f_r\left[1-\left(\frac{d}{D}\cos\theta\right)^2\right],\qquad
\mathrm{FTF}=\frac12f_r\left(1-\frac{d}{D}\cos\theta\right)
\]

The raw FFT can emphasize the excited resonance instead of the repetition rate. A bandpass isolates a resonance band; the analytic signal from the Hilbert transform then provides its amplitude envelope. The envelope spectrum reveals the impact repetition rate and harmonics.

## Dataset and scope

CWRU's test stand used a 2 hp motor, torque transducer/encoder, dynamometer, and magnetically mounted accelerometers at the drive- and fan-end housings. EDM seeded single-point inner-race, outer-race, and rolling-element faults. The official source documents 0-3 HP loads, roughly 1797-1720 rpm operation, and 12 kHz/48 kHz acquisition.

This project selects:

- `97`, `100`: normal at 0 and 3 HP;
- `105`, `108`: 0.007-inch inner-race fault;
- `118`, `121`: 0.007-inch ball fault;
- `130`, `133`: 0.007-inch outer-race fault at 6 o'clock, centered in the load zone.

The drive-end 6205-2RS JEM SKF geometry is nine balls, 0.3126-inch ball diameter, 1.537-inch pitch diameter, and nominal zero contact angle. See [DATA_DICTIONARY.md](DATA_DICTIONARY.md) for the complete mapping.

## Signal-processing decisions

1. **Offset removal.** Every record and analysis window is de-meaned so DC does not dominate the spectrum or inflate amplitude statistics.
2. **Rate standardization.** Normal baselines are anti-alias downsampled from 48 kHz to 12 kHz. Fault files are already 12 kHz. The final Nyquist frequency is 6 kHz.
3. **One-second windows.** Each FFT contains 12,000 samples, giving \(\Delta f=f_s/N=1\) Hz resolution. Five non-overlapping windows per record keep class/load counts balanced.
4. **Hann window.** Finite observation cuts cause spectral leakage when a sinusoid does not complete an integer number of cycles. The Hann taper reduces sidelobes. Coherent-gain correction restores bin-centered tone amplitude; the one-sided spectrum doubles non-DC/non-Nyquist bins.
5. **Envelope band.** A fixed 2-5 kHz band is below the 6 kHz Nyquist limit and captures impact-excited content in this controlled dataset. Keeping it fixed prevents post-hoc tuning by condition.
6. **Physical evidence.** The expected frequency is calculated from each record's measured RPM, not a nominal speed. Peak prominence is measured against a local median spectral floor.

## Reproduce the project

```bash
python -m venv .venv
source .venv/bin/activate          # Windows: .venv\Scripts\activate
pip install -r requirements.txt
pip install -e .
python download_data.py
python run_analysis.py
pytest -q
jupyter lab notebooks/Motor_Bearing_Condition_Monitoring.ipynb
```

The acquisition script downloads only the eight official `.mat` files and verifies fixed SHA-256 hashes. Raw data are excluded from the packaged portfolio archive to keep it small; rerunning the script recreates them.

## Repository layout

```text
motor-bearing-condition-monitoring/
├── download_data.py               # official URLs + SHA-256 verification
├── run_analysis.py                # end-to-end reproducible analysis
├── requirements.txt
├── DATA_DICTIONARY.md
├── src/bearing_monitoring/        # loading, features, kinematics, FFT, envelope
├── tests/                         # signal length/rate, FFT, feature tests
├── notebooks/                     # executed tutorial notebook
├── results/                       # feature CSV and verified summary
├── docs/figures/                  # seven publication-quality figures
├── docs/technical_report.pdf      # two-page technical report
└── portfolio/PORTFOLIO_PAGE.md    # web copy, resume bullets, interview Q&A
```

## Engineering interpretation

- RMS, peak-to-peak, crest factor, and kurtosis indicate severity/impulsiveness but do not identify the failed component.
- Race faults create stable repetition evidence across both loads in this controlled subset.
- The ball fault is weaker and more load-sensitive, consistent with a defect whose contact orientation and load path change as the ball circulates.
- Envelope analysis materially clarifies the component-specific frequency families; the raw FFT alone is not a reliable fault-localization method.
- A model can summarize engineered features, but the test must separate source recordings or operating conditions. Randomly splitting neighboring windows would overstate generalization.

## Limitations and deployment considerations

- CWRU faults are EDM seeded, isolated, and tested on a laboratory rig; natural faults evolve differently and may coexist with imbalance, looseness, gears, and variable speed.
- The MVP has one source record per class/load. Forty windows are not forty independent machines.
- Normal and fault records have different source sampling histories; resampling creates a common analysis grid but not a perfectly matched acquisition chain.
- Absolute acceleration calibration is not documented on the public pages used here, so amplitude is reported in CWRU units.
- Bearing-frequency formulas assume ideal rolling without slip. Field diagnostics should allow frequency tolerance and shaft-speed sidebands.
- Sensor mounting, orientation, location, dynamic range, anti-alias filtering, cable noise, and sample-clock quality can change the measured signature.
- A production system needs baselines from the actual asset, speed/load context, alarm persistence, sensor-health checks, and validation against maintenance findings.

## Sources and originality

- CWRU Bearing Data Center: <https://engineering.case.edu/bearingdatacenter>
- Apparatus and procedures: <https://engineering.case.edu/bearingdatacenter/apparatus-and-procedures>
- Bearing geometry: <https://engineering.case.edu/bearingdatacenter/bearing-information>
- Selected file tables: <https://engineering.case.edu/bearingdatacenter/download-data-file>
- The user-supplied reference repository was reviewed for expected depth and documentation structure only. This project uses an independently written, deliberately smaller MVP with no copied implementation and excludes kurtograms, EMD, VMD, wavelets, and deep learning.
