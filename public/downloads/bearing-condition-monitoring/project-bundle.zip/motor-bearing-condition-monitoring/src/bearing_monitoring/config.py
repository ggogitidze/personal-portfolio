"""Dataset manifest and analysis constants."""

from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parents[2]
RAW_DIR = PROJECT_ROOT / "data" / "raw"
RESULTS_DIR = PROJECT_ROOT / "results"
FIGURES_DIR = PROJECT_ROOT / "docs" / "figures"

TARGET_FS_HZ = 12_000.0
SEGMENT_SECONDS = 1.0
SEGMENTS_PER_RECORD = 5
ENVELOPE_BAND_HZ = (2_000.0, 5_000.0)

# The official normal-baseline DE records are 48 kHz; selected fault files are
# from the official 12 kHz drive-end table. All are standardized to 12 kHz.
RECORDS = {
    "97": {"condition": "normal", "load_hp": 0, "source_fs_hz": 48_000.0, "label": "Normal 0 HP"},
    "100": {"condition": "normal", "load_hp": 3, "source_fs_hz": 48_000.0, "label": "Normal 3 HP"},
    "105": {"condition": "inner_race", "load_hp": 0, "source_fs_hz": 12_000.0, "label": "Inner race 0 HP"},
    "108": {"condition": "inner_race", "load_hp": 3, "source_fs_hz": 12_000.0, "label": "Inner race 3 HP"},
    "118": {"condition": "ball", "load_hp": 0, "source_fs_hz": 12_000.0, "label": "Ball 0 HP"},
    "121": {"condition": "ball", "load_hp": 3, "source_fs_hz": 12_000.0, "label": "Ball 3 HP"},
    "130": {"condition": "outer_race", "load_hp": 0, "source_fs_hz": 12_000.0, "label": "Outer race 0 HP"},
    "133": {"condition": "outer_race", "load_hp": 3, "source_fs_hz": 12_000.0, "label": "Outer race 3 HP"},
}

CONDITION_ORDER = ["normal", "outer_race", "inner_race", "ball"]
DISPLAY_NAMES = {
    "normal": "Normal",
    "outer_race": "Outer race",
    "inner_race": "Inner race",
    "ball": "Ball",
}

