"""Bearing kinematics under the ideal no-slip approximation."""

from __future__ import annotations

from dataclasses import dataclass
from math import cos, radians


@dataclass(frozen=True)
class BearingGeometry:
    rolling_elements: int = 9
    ball_diameter_in: float = 0.3126
    pitch_diameter_in: float = 1.537
    contact_angle_deg: float = 0.0


def fault_frequencies(rpm: float, geometry: BearingGeometry = BearingGeometry()) -> dict[str, float]:
    """Return FTF, BPFO, BPFI, and BSF in hertz."""
    fr = rpm / 60.0
    ratio = geometry.ball_diameter_in / geometry.pitch_diameter_in
    c = cos(radians(geometry.contact_angle_deg))
    n = geometry.rolling_elements
    return {
        "shaft": fr,
        "ftf": 0.5 * fr * (1.0 - ratio * c),
        "bpfo": 0.5 * n * fr * (1.0 - ratio * c),
        "bpfi": 0.5 * n * fr * (1.0 + ratio * c),
        "bsf": (1.0 / (2.0 * ratio)) * fr * (1.0 - (ratio * c) ** 2),
    }

