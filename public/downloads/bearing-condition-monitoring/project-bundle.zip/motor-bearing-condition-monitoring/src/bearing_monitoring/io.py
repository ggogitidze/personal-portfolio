"""Robust loading and standardization of selected CWRU MATLAB records."""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
import re

import numpy as np
from scipy.io import loadmat
from scipy.signal import resample_poly


@dataclass(frozen=True)
class SignalRecord:
    record_id: str
    condition: str
    load_hp: int
    rpm: float
    source_fs_hz: float
    fs_hz: float
    acceleration: np.ndarray


def _one_key(data: dict, pattern: str) -> str:
    keys = [key for key in data if re.fullmatch(pattern, key)]
    if len(keys) != 1:
        raise ValueError(f"Expected one key matching {pattern!r}; found {keys}")
    return keys[0]


def load_cwru_record(
    path: Path,
    *,
    condition: str,
    load_hp: int,
    source_fs_hz: float,
    target_fs_hz: float = 12_000.0,
) -> SignalRecord:
    """Load drive-end acceleration, de-mean, and anti-alias resample if needed.

    CWRU's public pages identify accelerometer channels but do not state a
    calibration unit. Values are therefore retained as "CWRU amplitude units"
    instead of being mislabeled as g or m/s^2.
    """
    path = Path(path)
    data = loadmat(path)
    de_key = _one_key(data, r"X\d+_DE_time")
    rpm_key = _one_key(data, r"X\d+RPM")
    x = np.asarray(data[de_key], dtype=float).reshape(-1)
    rpm = float(np.asarray(data[rpm_key]).squeeze())

    if x.size < int(target_fs_hz):
        raise ValueError(f"{path.name}: signal is shorter than one target-rate second")
    if not np.all(np.isfinite(x)):
        raise ValueError(f"{path.name}: non-finite signal samples")

    x = x - np.mean(x)
    if source_fs_hz != target_fs_hz:
        ratio = source_fs_hz / target_fs_hz
        if not ratio.is_integer():
            raise ValueError("This MVP expects an integer downsampling ratio")
        x = resample_poly(x, up=1, down=int(ratio))
        x = x - np.mean(x)

    return SignalRecord(
        record_id=path.stem,
        condition=condition,
        load_hp=load_hp,
        rpm=rpm,
        source_fs_hz=source_fs_hz,
        fs_hz=target_fs_hz,
        acceleration=x,
    )


def segment_signal(x: np.ndarray, fs_hz: float, seconds: float, count: int) -> list[np.ndarray]:
    """Return equal, non-overlapping windows from the start of a recording."""
    n = int(round(fs_hz * seconds))
    if n <= 0 or len(x) < n * count:
        raise ValueError(f"Need {n * count} samples for {count} segments; found {len(x)}")
    return [np.asarray(x[i * n : (i + 1) * n], dtype=float) for i in range(count)]

