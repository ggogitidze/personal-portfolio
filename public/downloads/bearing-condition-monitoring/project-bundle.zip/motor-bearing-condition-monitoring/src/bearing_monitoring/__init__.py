"""Physics-grounded vibration diagnostics for the CWRU bearing dataset."""

from .bearing import BearingGeometry, fault_frequencies
from .features import time_features
from .spectral import single_sided_spectrum

__all__ = ["BearingGeometry", "fault_frequencies", "time_features", "single_sided_spectrum"]

