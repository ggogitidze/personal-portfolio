"""Amplitude-correct one-sided spectra and frequency evidence."""

from __future__ import annotations

import numpy as np
from scipy.signal import get_window


def single_sided_spectrum(
    x: np.ndarray,
    fs_hz: float,
    *,
    window: str | None = "hann",
) -> tuple[np.ndarray, np.ndarray]:
    """Return frequency and peak-amplitude spectrum for a real signal.

    Coherent-gain correction preserves the amplitude of a bin-centered tone.
    DC and (for even N) the Nyquist bin are not doubled.
    """
    x = np.asarray(x, dtype=float).reshape(-1)
    if x.size < 2 or fs_hz <= 0:
        raise ValueError("Need at least two samples and a positive sampling rate")
    x = x - np.mean(x)
    w = np.ones(x.size) if window is None else get_window(window, x.size, fftbins=True)
    coherent_sum = float(np.sum(w))
    if coherent_sum == 0:
        raise ValueError("Window has zero coherent gain")
    spectrum = np.abs(np.fft.rfft(x * w)) / coherent_sum
    if x.size % 2 == 0:
        spectrum[1:-1] *= 2.0
    else:
        spectrum[1:] *= 2.0
    freq = np.fft.rfftfreq(x.size, d=1.0 / fs_hz)
    return freq, spectrum


def peak_prominence_db(freq: np.ndarray, amplitude: np.ndarray, target_hz: float, *, tolerance_hz: float = 2.0, neighborhood_hz: float = 30.0) -> float:
    """Peak near target relative to local median amplitude, in dB."""
    freq = np.asarray(freq)
    amplitude = np.asarray(amplitude)
    target = np.abs(freq - target_hz) <= tolerance_hz
    local = (np.abs(freq - target_hz) <= neighborhood_hz) & ~target
    if not np.any(target) or not np.any(local):
        return float("nan")
    peak = float(np.max(amplitude[target]))
    floor = float(np.median(amplitude[local]))
    return float(20.0 * np.log10((peak + np.finfo(float).eps) / (floor + np.finfo(float).eps)))

