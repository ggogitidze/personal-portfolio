"""Transparent time-domain condition indicators."""

from __future__ import annotations

import numpy as np
from scipy.stats import kurtosis


def time_features(x: np.ndarray) -> dict[str, float]:
    """Compute standard vibration features on a de-meaned signal.

    Kurtosis uses the Pearson convention: a Gaussian process has kurtosis 3.
    Crest factor is max absolute amplitude divided by RMS.
    """
    x = np.asarray(x, dtype=float).reshape(-1)
    if x.size == 0 or not np.all(np.isfinite(x)):
        raise ValueError("Feature input must be non-empty and finite")
    centered = x - np.mean(x)
    rms = float(np.sqrt(np.mean(centered**2)))
    peak = float(np.max(np.abs(centered)))
    return {
        "rms": rms,
        "std": float(np.std(centered, ddof=0)),
        "peak_to_peak": float(np.ptp(centered)),
        "crest_factor": float(peak / rms) if rms > 0 else 0.0,
        "kurtosis": float(kurtosis(centered, fisher=False, bias=False)) if x.size > 3 and rms > 0 else 0.0,
    }

