"""Resonance-band filtering and Hilbert-envelope demodulation."""

from __future__ import annotations

import numpy as np
from scipy.signal import butter, hilbert, sosfiltfilt

from .spectral import single_sided_spectrum


def bandpass_filter(x: np.ndarray, fs_hz: float, low_hz: float, high_hz: float, order: int = 4) -> np.ndarray:
    """Zero-phase Butterworth bandpass; SOS form improves numerical stability."""
    nyquist = fs_hz / 2.0
    if not (0 < low_hz < high_hz < nyquist):
        raise ValueError(f"Band must satisfy 0 < low < high < Nyquist ({nyquist:g} Hz)")
    sos = butter(order, [low_hz, high_hz], btype="bandpass", fs=fs_hz, output="sos")
    return sosfiltfilt(sos, np.asarray(x, dtype=float))


def envelope_spectrum(x: np.ndarray, fs_hz: float, band_hz: tuple[float, float]) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    """Filter a resonance band, form its analytic envelope, and FFT the envelope."""
    filtered = bandpass_filter(x - np.mean(x), fs_hz, *band_hz)
    envelope = np.abs(hilbert(filtered))
    freq, amplitude = single_sided_spectrum(envelope - np.mean(envelope), fs_hz, window="hann")
    return freq, amplitude, envelope

