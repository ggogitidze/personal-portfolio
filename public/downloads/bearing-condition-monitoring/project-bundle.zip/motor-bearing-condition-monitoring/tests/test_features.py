import numpy as np

from bearing_monitoring.features import time_features


def test_feature_values_for_known_vector():
    x = np.array([-1.0, 1.0, -1.0, 1.0])
    f = time_features(x)
    assert np.isclose(f["rms"], 1.0)
    assert np.isclose(f["std"], 1.0)
    assert np.isclose(f["peak_to_peak"], 2.0)
    assert np.isclose(f["crest_factor"], 1.0)


def test_constant_signal_is_zero_after_offset_removal():
    f = time_features(np.ones(16) * 4.2)
    assert f["rms"] == 0.0
    assert f["crest_factor"] == 0.0

