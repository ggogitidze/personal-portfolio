import numpy as np

from bearing_monitoring.spectral import single_sided_spectrum


def test_fft_peak_location_and_amplitude():
    fs = 12_000.0
    n = 12_000
    tone_hz = 321.0
    amplitude = 2.5
    t = np.arange(n) / fs
    freq, spectrum = single_sided_spectrum(amplitude * np.sin(2 * np.pi * tone_hz * t), fs)
    index = int(np.argmax(spectrum))
    assert np.isclose(freq[index], tone_hz, atol=fs / n)
    assert np.isclose(spectrum[index], amplitude, rtol=0.01)


def test_frequency_axis_stops_at_nyquist():
    freq, _ = single_sided_spectrum(np.zeros(1000), 12_000.0)
    assert freq[-1] == 6_000.0

