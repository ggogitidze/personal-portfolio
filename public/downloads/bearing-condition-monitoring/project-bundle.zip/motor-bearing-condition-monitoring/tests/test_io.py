from pathlib import Path

import numpy as np
import pytest

from bearing_monitoring.config import RAW_DIR, RECORDS, TARGET_FS_HZ
from bearing_monitoring.io import load_cwru_record, segment_signal


@pytest.mark.parametrize("record_id", sorted(RECORDS))
def test_selected_record_length_and_sampling_frequency(record_id):
    meta = RECORDS[record_id]
    path = RAW_DIR / f"{record_id}.mat"
    if not path.exists():
        pytest.skip("Run download_data.py first")
    record = load_cwru_record(path, condition=meta["condition"], load_hp=meta["load_hp"], source_fs_hz=meta["source_fs_hz"])
    assert record.fs_hz == TARGET_FS_HZ
    assert len(record.acceleration) >= int(5 * TARGET_FS_HZ)
    assert abs(float(np.mean(record.acceleration))) < 1e-10


def test_segment_length():
    segments = segment_signal(np.arange(36_000), 12_000, seconds=1.0, count=3)
    assert len(segments) == 3
    assert all(len(segment) == 12_000 for segment in segments)

